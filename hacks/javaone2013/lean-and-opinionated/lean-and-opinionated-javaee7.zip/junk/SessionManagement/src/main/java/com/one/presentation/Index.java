/*
 *
 */
package com.one.presentation;

import com.one.business.sessions.boundary.SessionProvider;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Model
public class Index {

    @Inject
    SessionProvider sp;

    public String getSession() {
        return sp.getSessions();
    }
}
