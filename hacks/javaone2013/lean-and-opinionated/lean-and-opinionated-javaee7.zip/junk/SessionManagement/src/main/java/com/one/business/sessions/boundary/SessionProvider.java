/*
 *
 */
package com.one.business.sessions.boundary;

import com.one.business.sessions.control.Archiver;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class SessionProvider {

    @Inject
    Archiver ar;

    @PersistenceContext
    EntityManager em;

    public String getSessions() {
        return "java";
    }
}
