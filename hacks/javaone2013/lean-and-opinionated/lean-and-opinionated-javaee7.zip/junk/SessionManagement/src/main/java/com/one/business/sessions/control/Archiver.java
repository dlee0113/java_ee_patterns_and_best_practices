/*
 *
 */
package com.one.business.sessions.control;

/**
 *
 * @author adam-bien.com
 */
public class Archiver {

    public void archive(String content) {
        System.out.println("Content: " + content);
    }

}
