package pl.comarch.dragons.business;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author adam-bien.com
 */
@ApplicationPath("resources")
public class RESTConfiguration extends Application {

}
