package pl.comarch.dragons.business.observation.boundary;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import pl.comarch.dragons.business.observation.control.DragonNSA;
import pl.comarch.dragons.business.observation.entity.Dragon;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class DragonObserver {

    @Inject
    DragonNSA dragonNSA;

    public List<Dragon> allDragons() {
        List<Dragon> all = new ArrayList<>();
        final Dragon dragon = new Dragon("wawelski", 42, 2);
        dragonNSA.archive(dragon);
        all.add(dragon);
        return all;

    }
}
