package pl.comarch.dragons.business.observation.boundary;

import java.util.concurrent.TimeUnit;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;
import javax.ws.rs.container.TimeoutHandler;
import javax.ws.rs.core.Response;

@Stateless
@Path("dragons")
public class DragonsResource {

    @Inject
    DragonObserver observer;

    @GET
    public void all(@Suspended AsyncResponse response) {
        response.resume(observer.allDragons());
        response.setTimeout(30, TimeUnit.SECONDS);
        response.setTimeoutHandler(new TimeoutHandler() {

            @Override
            public void handleTimeout(AsyncResponse asyncResponse) {
                Response build = Response.status(204).build();
                asyncResponse.resume(build);
            }
        });
    }

    @GET
    @Path("{name}")
    public JsonObject dragon(@PathParam("name") String name) {
        return Json.createObjectBuilder().add("name", name).add("vc", 2).build();
    }

}
