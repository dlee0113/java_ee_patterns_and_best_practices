package pl.comarch.dragons.business.observation.control;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import pl.comarch.dragons.business.observation.entity.Dragon;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class DragonNSA {

    @Asynchronous
    public void archive(Dragon dragon) {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(DragonNSA.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
