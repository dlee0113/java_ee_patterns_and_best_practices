package pl.comarch.dragons.business.observation.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Dragon {

    private String name;
    private int fireClassification;
    private int virginCapacity;

    public Dragon() {
    }

    public Dragon(String name, int fireClassification, int virginCapacity) {
        this.name = name;
        this.fireClassification = fireClassification;
        this.virginCapacity = virginCapacity;
    }

}
