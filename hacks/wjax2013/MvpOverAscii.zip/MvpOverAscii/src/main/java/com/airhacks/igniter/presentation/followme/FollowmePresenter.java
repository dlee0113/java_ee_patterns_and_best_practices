package com.airhacks.igniter.presentation.followme;

/*
 * #%L
 * igniter
 * %%
 * Copyright (C) 2013 Adam Bien
 * %%
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * #L%
 */
import com.airhacks.igniter.business.flightcontrol.boundary.Tower;
import com.airhacks.igniter.presentation.another.AnotherView;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.binding.BooleanBinding;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.AnchorPane;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class FollowmePresenter implements Initializable {

    @FXML
    Label message;
    @Inject
    Tower tower;

    @FXML
    TextField sessionName;

    @FXML
    TextField confirmation;

    @FXML
    Label output;

    @Inject
    DelayedInput di;

    @FXML
    Button launch;

    @FXML
    TableView sessionsTable;

    @FXML
    TableColumn nameColumn;

    @FXML
    AnchorPane rightPane;

    String pilot;

    private ObservableList items;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.pilot = rb.getString("pilot");
        di.nameProperty().bind(sessionName.textProperty());
        BooleanBinding booleanBinding = sessionName.textProperty().isEqualTo(confirmation.textProperty());
        this.launch.disableProperty().bind(booleanBinding.not());
        this.items = sessionsTable.getItems();
        nameColumn.setCellValueFactory(new PropertyValueFactory("description"));
        nameColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        rightPane.getChildren().add(new AnotherView().getView());
    }

    public void launch() {
        this.items.add(new Session("javafx rocks " + System.currentTimeMillis()));
        message.setText(tower.readyToTakeoff(pilot));
    }

}
