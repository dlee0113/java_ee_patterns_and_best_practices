/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks.igniter.presentation.followme;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javax.annotation.PostConstruct;

/**
 *
 * @author adam-bien.com
 */
public class DelayedInput {

    private StringProperty name;

    @PostConstruct
    public void initialize() {
        System.out.println("hey joe");
        this.name = new SimpleStringProperty();
        this.name.addListener(new ChangeListener<String>() {

            @Override
            public void changed(ObservableValue<? extends String> ov, String t, String t1) {
                System.out.println("--- " + t1);
            }
        });
    }

    public StringProperty nameProperty() {
        return this.name;
    }
}
