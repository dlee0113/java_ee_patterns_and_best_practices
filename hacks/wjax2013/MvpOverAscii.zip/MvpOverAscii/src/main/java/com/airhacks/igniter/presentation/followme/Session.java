/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks.igniter.presentation.followme;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

/**
 *
 * @author adam-bien.com
 */
public class Session {

    private StringProperty description;

    public Session() {
        this.description = new SimpleStringProperty();
    }

    public Session(String description) {
        this();
        this.description.set(description);
        this.description.addListener(new ChangeListener<String>() {

            @Override
            public void changed(ObservableValue<? extends String> ov, String t, String t1) {
                System.out.println("Changing attached JPA entity: " + t1);
            }
        });
    }

    public StringProperty descriptionProperty() {
        return this.description;
    }

}
