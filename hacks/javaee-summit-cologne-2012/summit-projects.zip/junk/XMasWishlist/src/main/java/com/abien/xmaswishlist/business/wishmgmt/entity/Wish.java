package com.abien.xmaswishlist.business.wishmgmt.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Wish implements Serializable {
    
    @Id
    @GeneratedValue
    private long id;
    private String name;
    private int amount;

    public Wish() {
    }

    public Wish(String name, int amount) {
        this.name = name;
        this.amount = amount;
    }

    public long getId() {
        return id;
    }
    
    

    @Override
    public String toString() {
        return "Wish{" + "name=" + name + ", amount=" + amount + '}';
    }
    
    
    
}
