package com.abien.xmaswishlist.business.wishmgmt.control;

import com.abien.xmaswishlist.business.wishmgmt.entity.Wish;

/**
 *
 * @author adam-bien.com
 */
public class OptimisticValidator implements Validator{

    public boolean validate(Wish wish){
        return true;
    }
}
