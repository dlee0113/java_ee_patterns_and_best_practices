/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.xmaswishlist.business.wishmgmt.control;

import com.abien.xmaswishlist.business.wishmgmt.entity.Wish;

/**
 *
 * @author adam-bien.com
 */
public interface Validator {
     public boolean validate(Wish wish);
}
