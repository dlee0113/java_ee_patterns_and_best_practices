package com.abien.xmaswishlist.business.wishmgmt.boundary;

import com.abien.xmaswishlist.business.wishmgmt.entity.Wish;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Stateless
@Path("wishes")
@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML,"summit/hack"})
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
public class WishesResource {
    
    @Inject
    WishService ws;
    
    @GET
    public List<Wish> wishes(){
        List<Wish> wishes = new ArrayList<Wish>(){{
            add(new Wish("time", 42));
            add(new Wish("sleep", 21));
        }};
        return wishes;
    }
    
    @GET
    @Path("{id}")
    public Wish wish(@PathParam("id") int id){
        return new Wish("time", id);
    }
    
    @POST
    public Response create(Wish wish){
        System.out.println("Got it: " + wish);
        Wish output = this.ws.save(wish);
        URI uri = URI.create("/"+output.getId());
        return Response.created(uri).build();
    }
}
