/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.audit.boundary;

import com.abien.xmaswishlist.business.wishmgmt.entity.Wish;
import java.util.concurrent.Future;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class WishValidation {
    
    @Asynchronous
    public void verify(@Observes(during = TransactionPhase.AFTER_SUCCESS) Wish wish){
        System.out.println("-- on arrival: " + wish);
    }
    
}
