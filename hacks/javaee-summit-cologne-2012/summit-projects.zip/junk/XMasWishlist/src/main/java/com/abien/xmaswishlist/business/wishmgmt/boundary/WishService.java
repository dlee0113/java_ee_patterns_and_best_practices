package com.abien.xmaswishlist.business.wishmgmt.boundary;

import com.abien.xmaswishlist.business.wishmgmt.control.Validator;
import com.abien.xmaswishlist.business.wishmgmt.entity.Wish;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class WishService {
    
    @PersistenceContext
    EntityManager em;
    
    @Inject
    Instance<Validator> validators;
    
    @Inject
    Event<Wish> verification;
    
    @Inject
    private String message;
    
    public Wish save(Wish wish){
        verification.fire(wish);
        for (Validator validator : validators) {
            System.out.println( message + validator);
        }
        return em.merge(wish);
    }
}
