/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.xmaswishlist.configuration.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam-bien.com
 */
public class Configurator {
   
    @Produces
    public String getString(InjectionPoint ip){
        Class<?> declaringClass = ip.getMember().getDeclaringClass();
        String name = ip.getMember().getName();
        return declaringClass.getName() +  "." + name + "  ";
    }
}
