/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.xmastesting.pricing.control;

/**
 *
 * @author adam-bien.com
 */
public interface PriceCalculator {
    public int getPrice();
}
