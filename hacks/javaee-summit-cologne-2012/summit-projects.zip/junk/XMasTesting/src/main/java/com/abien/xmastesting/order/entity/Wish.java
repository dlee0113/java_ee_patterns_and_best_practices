/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.xmastesting.order.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author adam-bien.com
 */
@NamedQueries({
    @NamedQuery(name = Wish.findAll,query = "SELECT a from Wish a")
})
@Table(name = "summit_wish")
@Entity
public class Wish {
    private static final String PREFIX = "com.abien.xmastesting.order.entity.Wish.";
    public static final String findAll = PREFIX + "findAll";
    @Id
    @GeneratedValue
    private long id;
    private String name;

    public Wish(String name) {
        this.name = name;
    }

    public Wish() {
    }
    
    
}
