package com.abien.xmastesting.order.boundary;

import com.abien.xmastesting.order.control.HostValidator;
import com.abien.xmastesting.order.control.OrderFullfilment;
import com.abien.xmastesting.order.entity.Wish;
import javax.ejb.Stateless;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class OrderService {
     @Inject
     HostValidator hv;
     
     @Inject
     OrderFullfilment of;
     
     
     public void order(Wish wish){
        if(!hv.check(wish)){
            throw new IllegalArgumentException("Wrong type...");
        }
        of.order(wish);
     }
}
