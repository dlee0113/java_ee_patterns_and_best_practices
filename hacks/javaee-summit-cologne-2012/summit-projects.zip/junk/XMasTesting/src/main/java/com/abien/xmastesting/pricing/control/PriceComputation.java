/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.xmastesting.pricing.control;

import javax.enterprise.inject.Instance;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class PriceComputation {
   
    @Inject
    Instance<PriceCalculator> calculator;
    
    
    public int getPrice(){
        if(calculator.isUnsatisfied()){
            return 42;
        }
        if(calculator.isAmbiguous())
            throw new IllegalStateException("Too much");
        return calculator.get().getPrice();
    }
    
}
