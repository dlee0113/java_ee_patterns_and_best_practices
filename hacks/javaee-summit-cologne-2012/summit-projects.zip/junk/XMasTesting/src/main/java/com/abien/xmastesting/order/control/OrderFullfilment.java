/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.xmastesting.order.control;

import com.abien.xmastesting.order.entity.Wish;

/**
 *
 * @author adam-bien.com
 */
public class OrderFullfilment {

    public void order(Wish wish) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
