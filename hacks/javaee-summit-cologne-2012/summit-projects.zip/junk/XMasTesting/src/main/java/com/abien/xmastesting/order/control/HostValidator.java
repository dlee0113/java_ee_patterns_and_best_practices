package com.abien.xmastesting.order.control;

import com.abien.xmastesting.order.entity.Wish;

/**
 *
 * @author adam-bien.com
 */
public class HostValidator {

    public boolean check(Wish wish){
        return true;
    }
}
