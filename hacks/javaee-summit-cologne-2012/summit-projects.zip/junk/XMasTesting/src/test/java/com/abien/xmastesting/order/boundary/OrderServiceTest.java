/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.xmastesting.order.boundary;

import com.abien.xmastesting.order.control.HostValidator;
import com.abien.xmastesting.order.control.OrderFullfilment;
import com.abien.xmastesting.order.entity.Wish;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import static org.mockito.Mockito.*;

/**
 *
 * @author adam-bien.com
 */
public class OrderServiceTest {

    OrderService cut;

    @Before
    public void inject(){
        this.cut = new OrderService();
        this.cut.hv = mock(HostValidator.class);
        this.cut.of = mock(OrderFullfilment.class);
        //spy(new OrderFullfilment());
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void invalidWish() {
        Wish wish = new Wish();
        when(this.cut.hv.check(wish)).thenReturn(false);
        this.cut.order(wish);
    }

    @Test
    public void validWish() {
        Wish wish = new Wish();
        when(this.cut.hv.check(wish)).thenReturn(true);
        this.cut.order(wish);
        verify(this.cut.of).order(wish);
    }
}
