/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.xmastesting.pricing.control;

import javax.inject.Inject;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.junit.runner.RunWith;

/**
 *
 * @author adam-bien.com
 */
@RunWith(Arquillian.class)
public class PriceComputationTest {
    
    @Inject
    PriceComputation computation;
    
    @Deployment
    public static WebArchive createEmpty() {
        return ShrinkWrap.create(WebArchive.class).
                addClasses(PriceComputation.class,PriceCalculator.class).
                addAsWebInfResource(EmptyAsset.INSTANCE, "beans.xml");
    }

    @Deployment(name = "xmas")
    public static WebArchive createWithXMas() {
        return ShrinkWrap.create(WebArchive.class).
                addClasses(PriceComputation.class,PriceCalculator.class,XMasPricing.class).
                addAsWebInfResource(EmptyAsset.INSTANCE, "beans.xml");
    }
    
    @Test
    public void noPlugin() {
        assertThat(computation.getPrice(),is(42));
    }

    @Test
    public void xmasPlugin() {
        assertThat(computation.getPrice(),is(42));
    }
}
