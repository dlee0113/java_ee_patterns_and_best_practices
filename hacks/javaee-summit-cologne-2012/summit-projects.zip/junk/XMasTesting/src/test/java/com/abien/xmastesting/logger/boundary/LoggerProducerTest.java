/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.xmastesting.logger.boundary;

import javax.inject.Inject;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.junit.runner.RunWith;

/**
 *
 * @author adam-bien.com
 */
@RunWith(Arquillian.class)
public class LoggerProducerTest {
    
    @Inject
    LogInjectionTarget lit;
    
    @Deployment
    public static WebArchive create() {
        return ShrinkWrap.create(WebArchive.class).
                addClasses(LoggerProducer.class,LogInjectionTarget.class).
                addAsWebInfResource(EmptyAsset.INSTANCE, "beans.xml");
    }
    
    @Test
    public void logConfiguration() {
        assertNotNull(lit.log);
        assertThat(lit.getName(),is(lit.getClass().getName()));
    }
}
