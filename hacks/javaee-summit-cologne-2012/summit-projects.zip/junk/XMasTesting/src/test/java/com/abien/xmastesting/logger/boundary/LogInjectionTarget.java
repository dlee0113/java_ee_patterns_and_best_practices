/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.xmastesting.logger.boundary;

import java.util.logging.Logger;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class LogInjectionTarget {
    
    @Inject
    Logger log;
    
    public String getName(){
        return log.getName();
    }
    
}
