/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaee.summit;

import javax.ejb.Stateless;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;

/**
 *
 * @author adam-bien.com
 */
@Stateless
@Path("xmas")
public class XMasResource {
    
    @Context
    HttpServletRequest request;
    
    @GET
    @Produces("text/plain")
    public String user(){
        return "duke " + request;
    }
    
}
