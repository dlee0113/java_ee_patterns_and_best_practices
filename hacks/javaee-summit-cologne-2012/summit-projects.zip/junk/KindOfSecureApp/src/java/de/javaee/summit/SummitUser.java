package de.javaee.summit;

import com.sun.xml.rpc.encoding.soap.CollectionSerializer;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author adam-bien.com
 */
public class SummitUser {
    
    private String name;
    private List<String> permissions;

    public SummitUser(String name) {
        this.name = name;
        this.permissions = new ArrayList<String>();
    }

    public String getName() {
        return name;
    }

    
    @Override
    public String toString() {
        return "SummitUser{" + "name=" + name + ", permissions=" + permissions + '}';
    }

    
    
}
