/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaee.summit;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author adam-bien.com
 */
@ApplicationPath("resources")
public class RESTConfig extends Application {
    
}
