package de.javaee.summit;

import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Model
public class SecurityPresenter {

    @Inject
    SummitUser su;
    
    public boolean isVisible(String ...role){
        return true;
    }
}
