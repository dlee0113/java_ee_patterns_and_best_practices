package de.javaee.summit;

import javax.annotation.Resource;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;

/**
 *
 * @author adam-bien.com
 */
@Interceptors(Guard.class)
@DeclareRoles("admin")
@Stateless
public class Boundary {
    
    @Resource
    SessionContext sc;
    
    @AllowedFor("dukeextended") 
    public boolean hasRole(){
        return sc.isCallerInRole("admin");
    }
    
    @RolesAllowed("admin")
    public void guarded(){
    
    }
}
