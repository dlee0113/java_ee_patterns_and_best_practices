package de.javaee.summit;

import java.security.Principal;
import javax.enterprise.inject.Model;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Model
public class Index {
    
    @Inject
    SummitUser principal;
    
    @Inject
    Boundary boundary;
    
    public String getName(){
        return principal.toString() + boundary.hasRole();
    }
    
    public Object logout(){
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        return "index?redirect=true";
    }
    
}
