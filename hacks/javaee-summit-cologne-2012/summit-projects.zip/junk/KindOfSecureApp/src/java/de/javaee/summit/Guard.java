package de.javaee.summit;

import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam-bien.com
 */
public class Guard {

    @Inject
    Instance<SummitUser> su;
    
    @AroundInvoke
    public Object checkAccess(InvocationContext ic) throws Exception{
        AllowedFor annotation = ic.getMethod().getAnnotation(AllowedFor.class);
        if(annotation.value().equals(su.get().getName())){
            return ic.proceed();
        }
        throw new SecurityException("Hacker?");
    }
}
