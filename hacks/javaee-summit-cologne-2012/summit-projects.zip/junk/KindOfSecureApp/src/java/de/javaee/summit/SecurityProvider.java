package de.javaee.summit;

import java.security.Principal;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class SecurityProvider {

    @Inject
    private Principal principal;
    
    @Produces
    public SummitUser current(){
        return new SummitUser(principal.getName() + "extended");
    }
}
