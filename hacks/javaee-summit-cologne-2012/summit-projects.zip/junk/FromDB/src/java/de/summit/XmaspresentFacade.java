/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.summit;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class XmaspresentFacade extends AbstractFacade<Xmaspresent> {
    @PersistenceContext(unitName = "FromDBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public XmaspresentFacade() {
        super(Xmaspresent.class);
    }
    
}
