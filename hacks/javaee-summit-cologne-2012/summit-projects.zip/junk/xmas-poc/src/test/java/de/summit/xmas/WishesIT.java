/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.summit.xmas;

import com.sun.jersey.api.client.Client;
import javax.ws.rs.core.MediaType;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author adam-bien.com
 */
public class WishesIT {

    
    @Test
    public void getWish(){
        Wish wish = Client.create().
                           resource("http://localhost:8080/XMasWishlist/v1/wishes/1").
                           accept(MediaType.APPLICATION_XML).get(Wish.class);
        System.out.println("Got Wish: " + wish);
    }

    public WishesIT() {
    }
    
}
