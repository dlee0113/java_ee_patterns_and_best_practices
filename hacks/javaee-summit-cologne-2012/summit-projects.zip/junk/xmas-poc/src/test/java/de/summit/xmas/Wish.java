package de.summit.xmas;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Wish implements Serializable {
    
    private String name;
    private int amount;

    public Wish() {
    }

    public Wish(String name, int amount) {
        this.name = name;
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "Wish{" + "name=" + name + ", amount=" + amount + '}';
    }
    
    
    
}
