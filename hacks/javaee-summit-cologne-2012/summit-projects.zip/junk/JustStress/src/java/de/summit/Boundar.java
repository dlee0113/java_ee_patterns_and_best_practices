/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.summit;

import javax.ejb.Stateless;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class Boundar {
    
   public String something(){
        return System.currentTimeMillis() + " hey";
    }

}
