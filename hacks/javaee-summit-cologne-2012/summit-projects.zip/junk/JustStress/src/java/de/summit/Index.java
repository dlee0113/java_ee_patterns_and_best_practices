/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.summit;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.enterprise.inject.Model;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author adam-bien.com
 */
@Named
@SessionScoped
public class Index implements Serializable {
    
    @Inject
    Boundar boundar;
    
    public String getMessage(){
        return boundar.something();
    }
}
