package de.javaee.summit;

import java.io.Serializable;
import java.util.Set;
import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.enterprise.inject.Model;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

/**
 *
 * @author adam-bien.com
 */
@Named
@SessionScoped
public class Index implements Serializable {
    
    @Inject
    PresentFactory ns;
    
    @Inject
    Validator validator;
    

    private XMasPresent present;
    
    @PostConstruct
    public void init(){
        this.present = new XMasPresent();
    }

    public XMasPresent getPresent() {
        return present;
    }
    
    

    
    public Object save(){
        System.out.println("Saving: " + this.present);
        ns.save(present);
        Set<ConstraintViolation<XMasPresent>> violations = this.validator.validate(present, new Class[]{});
        if(!violations.isEmpty()){
            System.out.println("----Validation problem occured!: " + violations);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(violations.toString()));
        }
        return "confirmation";
    }
}
