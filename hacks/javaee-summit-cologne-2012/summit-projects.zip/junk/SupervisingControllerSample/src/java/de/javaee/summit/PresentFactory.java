package de.javaee.summit;

import java.io.Serializable;
import javax.ejb.Stateful;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.context.SessionScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

/**
 *
 * @author adam-bien.com
 */
@SessionScoped
@Stateful
@TransactionAttribute(TransactionAttributeType.NEVER)
public class PresentFactory implements Serializable {

    @PersistenceContext(type = PersistenceContextType.EXTENDED)
    EntityManager em;
    
    XMasPresent masPresent;
    
    public void save(XMasPresent masPresent){
        this.masPresent = em.merge(masPresent);
    }

    public XMasPresent getCurrentPresent() {
        return masPresent;
    }
    
    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public void save(){}
    
    public void undo(){
        this.em.refresh(this.masPresent);
    }
    
    
}

