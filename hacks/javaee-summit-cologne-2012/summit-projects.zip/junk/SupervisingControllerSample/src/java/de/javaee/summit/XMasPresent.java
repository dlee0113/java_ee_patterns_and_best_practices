package de.javaee.summit;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Size;

/**
 *
 * @author adam-bien.com
 */
@Entity
@ConsistentPresent
public class XMasPresent {

    @Id
    @GeneratedValue
    private long id;
    
    @Size(min = 2,max = 5)
    private String name;

    public XMasPresent() {
    }

    public XMasPresent(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "XMasPresent{" + "name=" + name + '}';
    }
    
    
}
