/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaee.summit;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 *
 * @author adam-bien.com
 */
public class ConsistentPresentValidator implements ConstraintValidator<ConsistentPresent, XMasPresent> {
    private ConsistentPresent annotation;
    
    @Override
    public void initialize(ConsistentPresent constraintAnnotation) {
        this.annotation = constraintAnnotation;
    }
    
    @Override
    public boolean isValid(XMasPresent value, ConstraintValidatorContext context) {
        return "duke".equalsIgnoreCase(value.getName());
    }
}
