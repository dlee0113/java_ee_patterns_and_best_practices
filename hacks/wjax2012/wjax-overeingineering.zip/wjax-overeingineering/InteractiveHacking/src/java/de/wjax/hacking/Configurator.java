package de.wjax.hacking;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam-bien.com
 */
public class Configurator {

    @Produces
    public String getString(InjectionPoint ip,Stages stages){
        String className = ip.getMember().getDeclaringClass().getName();
        String name = ip.getMember().getName();
        return className + "---- " +name + " " + stages;
    }
}
