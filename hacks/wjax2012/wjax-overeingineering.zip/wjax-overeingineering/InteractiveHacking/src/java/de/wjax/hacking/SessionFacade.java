/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.hacking;

import java.util.Date;
import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.TransactionSynchronizationRegistry;

/**
 *
 * @author adam-bien.com
 */
@Stateless
@Interceptors(CrossCuttingConcern.class)
public class SessionFacade {
    
    @Inject @Any
    Instance<MessageProvider> mp;
    
    @Resource
    TransactionSynchronizationRegistry tsr;
    
    @Inject
    Event<String> events;
    
    @Resource
    SessionContext sc;
    
    @Inject @Purpose(Purpose.Type.READ)
    EntityManager em;
    
    public String helloWorld(){
        String message ="";
        for (MessageProvider messageProvider : mp) {
            message += messageProvider.getMessage();
        }
        //sc.getRollbackOnly();
        events.fire(message);
        //sc.setRollbackOnly();
        HelloMessage entity = em.merge(new HelloMessage(message));
        return message + new Date();
    }
}
