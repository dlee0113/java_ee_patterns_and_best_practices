package de.wjax.hacking;

import java.util.logging.Logger;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author adam-bien.com
 */
@ApplicationPath("v1")
public class RESTConfiguration extends Application {
    
}
