/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.hacking;

/**
 *
 * @author adam-bien.com
 */
public class MessageProviderImpl2 implements MessageProvider{

    @Override
    public String getMessage() {
        return "from plugin";
    }
    
}
