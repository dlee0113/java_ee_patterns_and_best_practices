/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.hacking;

import javax.enterprise.inject.Produces;

/**
 *
 * @author adam-bien.com
 */
public class StageProvider {
    
    @Produces
    public Stages currentStage(){
        return Stages.DEV;
    }
}
