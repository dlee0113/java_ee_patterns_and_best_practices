/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.hacking;

import java.io.IOException;
import java.io.PrintWriter;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.servlet.AsyncContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author adam-bien.com
 */
@WebServlet(name = "Tunguska", urlPatterns = {"/Tunguska"},asyncSupported = true)
public class Tunguska extends HttpServlet {

    @Inject
    Event<AsyncContext> ac;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        AsyncContext startAsync = request.startAsync();
        ac.fire(startAsync);
    }

   
}
