package de.wjax.hacking;

import java.util.Date;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.DependsOn;
import javax.ejb.ScheduleExpression;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerConfig;
import javax.ejb.TimerService;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
public class ConfigurableTimer {
    
    @Resource
    TimerService ts;
    
    private Timer timer;
    
    @PostConstruct
    public void initialize(){
        ScheduleExpression expression = new ScheduleExpression();
        expression.hour("*").minute("*").second("*/2");
        TimerConfig tc = new TimerConfig();
        tc.setPersistent(true);
        this.timer = ts.createCalendarTimer(expression,tc);
    }
    
    @Timeout
    public void veryConfigurable(){
        System.out.println("Configurable: " + new Date());
    }
}
