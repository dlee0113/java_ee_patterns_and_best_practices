package de.wjax.hacking;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
@Entity
public class HelloMessage {
    
    @Id
    @GeneratedValue
    private long id;
    private String message;

    public HelloMessage() {
    }

    public HelloMessage(String message) {
        this.message = message;
    }
    
    
}
