package de.wjax.hacking;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class HelloWorldListener {

    @Asynchronous
    public void onHello(@Observes(during = TransactionPhase.AFTER_SUCCESS) String message){
        System.out.println("-######-- " + message);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(HelloWorldListener.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
   public void onFailure(@Observes(during = TransactionPhase.AFTER_FAILURE) String message){
        System.out.println("--LISTENER-- " + message);
   }

}
