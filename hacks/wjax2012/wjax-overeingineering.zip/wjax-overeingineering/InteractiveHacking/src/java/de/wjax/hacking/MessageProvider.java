package de.wjax.hacking;

/**
 *
 * @author adam-bien.com
 */
public interface MessageProvider {
    public String getMessage();
}
