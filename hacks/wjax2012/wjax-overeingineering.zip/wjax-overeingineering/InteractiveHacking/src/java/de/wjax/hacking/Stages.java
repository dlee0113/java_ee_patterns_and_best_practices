package de.wjax.hacking;
public enum Stages {

    DEV,TEST;
}
