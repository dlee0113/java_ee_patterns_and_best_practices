/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.hacking;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.enterprise.event.Observes;
import javax.servlet.AsyncContext;

/**
 *
 * @author adam-bien.com
 */
public class UFOListener {
 
    
    public void request(@Observes AsyncContext ac) {
        try {
            PrintWriter writer = ac.getResponse().getWriter();
            writer.println("From EJB");
            writer.flush();
            ac.complete();
        } catch (IOException ex) {
            Logger.getLogger(UFOListener.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
