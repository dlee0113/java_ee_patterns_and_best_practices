package de.wjax.hacking;

import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class MessageProviderImpl implements MessageProvider{

    @Inject
    String message;
    
    @Override
    public String getMessage() {
        return message;
    }
    
}
