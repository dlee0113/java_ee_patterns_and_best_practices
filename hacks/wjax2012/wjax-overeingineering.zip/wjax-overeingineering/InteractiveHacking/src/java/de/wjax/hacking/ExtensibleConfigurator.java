/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.hacking;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.Specializes;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam-bien.com
 */
public class ExtensibleConfigurator extends Configurator{

    @Override @Produces @Specializes
    public String getString(InjectionPoint ip, Stages stages) {
        return " configured from DB "; 
    }
    
    
}
