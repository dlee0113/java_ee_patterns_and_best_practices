package de.wjax.hacking;

import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author adam-bien.com
 */
public class EntityManagerProvider {

    @PersistenceContext
    EntityManager em;
    
    @Produces @Purpose(Purpose.Type.WRITE)
    public EntityManager exposeForWrite(){
        return em;
    }
    @Produces @Purpose(Purpose.Type.READ)
    public EntityManager exposeForRead(){
        return em;
    }
    
}
