/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.javaone.overengineering;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam-bien.com
 */
public class CallTracer {
    
    @AroundInvoke
    public Object trace(InvocationContext ic) throws Exception{
        System.out.println("---Traced: " + ic.getMethod());
        return ic.proceed();
    }
    
}
