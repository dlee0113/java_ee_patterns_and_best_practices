/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.javaone.overengineering;

import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.enterprise.event.Observes;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class ThreadStarter {
    
    @Asynchronous
    public void start(@Observes Runnable runnable){
        runnable.run();
    }
    
}
