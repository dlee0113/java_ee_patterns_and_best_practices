/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.javaone.overengineering;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Schedule;
import javax.ejb.ScheduleExpression;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerConfig;
import javax.ejb.TimerService;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
public class QuartzDisabler {

    @Resource
    TimerService ts;
    
    private Timer timer;
    
    @PostConstruct
    public void initialize(){
        ScheduleExpression se = new ScheduleExpression();
        se.second("*/2").minute("*").hour("*");
        TimerConfig tc = new TimerConfig();
        tc.setPersistent(true);
        this.timer = ts.createCalendarTimer(se,tc);
    }
    @Timeout
    public void doSomething(){
        System.out.println("Received: " + System.currentTimeMillis());
    }
    
}
