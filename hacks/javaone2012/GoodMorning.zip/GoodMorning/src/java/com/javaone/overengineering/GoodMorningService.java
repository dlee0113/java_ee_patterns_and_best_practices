/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.javaone.overengineering;

import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.Interceptors;

/**
 *
 * @author adam-bien.com
 */
@Stateless
@Interceptors(CallTracer.class)
public class GoodMorningService {
    @Inject 
    String message;

    @Inject 
    String another;
    
    @Inject @Any
    Instance<TimeProvider> provider;
    
    @Inject
    Event<String> events;
    
    @Inject
    Event<Runnable> runnables;
    
    public String message(){
        String message = "";
        
        for (TimeProvider timeProvider : provider) {
            message += timeProvider.getTime();
        }
        runnables.fire(new Runnable() {

            @Override
            public void run() {
                System.out.println("Heavy work");
            }
        });
        events.fire(message);
        return message;
    }
}
