/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.javaone.overengineering;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.enterprise.event.Observes;
import javax.inject.Singleton;
import javax.servlet.AsyncContext;

/**
 *
 * @author adam-bien.com
 */
@Singleton
public class CometService {
    
    
    public void onRequest(@Observes AsyncContext ac){
        try {
            ac.getResponse().getWriter().println("Seems to work : " +System.currentTimeMillis());
            ac.complete();
        } catch (Exception ex) {
            Logger.getLogger(CometService.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
