package com.javaone.overengineering;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Model;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author adam-bien.com
 */
@Model
public class Index {
   
    @Inject
    GoodMorningService gms;
    
    
    public String message(){
        return gms.message();
    }
}
