package com.javaone.overengineering;

/**
 *
 * @author adam-bien.com
 */
@Timer(Timer.Exactness.LOW)
public class TimerProviderImpl implements TimeProvider{

    @Override
    public String getTime() {
        return "too early";
    }

    
}
