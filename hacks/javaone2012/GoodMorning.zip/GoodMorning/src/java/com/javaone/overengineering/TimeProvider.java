package com.javaone.overengineering;

public interface TimeProvider {

    public String getTime();
    
}
