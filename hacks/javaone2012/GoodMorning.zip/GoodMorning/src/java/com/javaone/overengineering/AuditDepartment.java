/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.javaone.overengineering;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.enterprise.event.Observes;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class AuditDepartment {
   
    @Asynchronous
    public void message(@Observes String message){
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(AuditDepartment.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Got message: " + message);
    }
}
