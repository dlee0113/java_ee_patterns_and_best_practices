package com.javaone.overengineering;

import java.util.Date;

/**
 *
 * @author adam-bien.com
 */
@Timer(Timer.Exactness.HIGH)
public class ExactTimeProvider implements TimeProvider{

    @Override
    public String getTime() {
        return new Date().toString();
    }
    
}
