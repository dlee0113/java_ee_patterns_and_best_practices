package org.javaone.messenger.business.sender.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam-bien.com
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class JavaOneMessage implements Serializable{
    
    @Id
    @GeneratedValue
    private long id;
    
    private String message;

    public JavaOneMessage() {
    }

    public JavaOneMessage(String message) {
        this.message = message;
    }
    
    
}
