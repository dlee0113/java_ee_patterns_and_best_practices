/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.javaone.messenger.business.sender.control;

/**
 *
 * @author adam-bien.com
 */
public class CustomPrincipalProviderExtension {
    
}
