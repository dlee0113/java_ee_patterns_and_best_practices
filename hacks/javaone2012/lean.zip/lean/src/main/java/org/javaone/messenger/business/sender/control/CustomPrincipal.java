/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.javaone.messenger.business.sender.control;

import java.util.List;

/**
 *
 * @author adam-bien.com
 */
public class CustomPrincipal {
    
    
    private String name;
    private List<String> applicationSpecific;
    
    public CustomPrincipal(String name) {
        this.name = name;
    }
    
    
    
    
    
}
