package org.javaone.messenger.business.sender.control;

import java.util.Date;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.ScheduleExpression;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
public class Scheduler {
    
    @Resource
    TimerService ts;
    private Timer timer;
    
    @PostConstruct
    public void initialize(){
        ScheduleExpression expression = new ScheduleExpression();
        expression.minute("*").second("*/2").hour("*");
        this.timer = ts.createCalendarTimer(expression);
    }
    
    @Timeout
    public void configurableTimeout(){
        System.out.println("---- on timeout: " + new Date());
    }
}
