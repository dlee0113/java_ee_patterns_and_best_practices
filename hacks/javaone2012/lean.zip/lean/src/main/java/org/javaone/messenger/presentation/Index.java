package org.javaone.messenger.presentation;

import javax.enterprise.inject.Model;
import javax.inject.Inject;
import org.javaone.messenger.business.sender.boundary.MessagingService;

/**
 *
 * @author adam-bien.com
 */
@Model
public class Index {
    
    @Inject
    MessagingService ms;
    
    public String get(){
        ms.send("Message");
        return "done";
    }
    
    
}
