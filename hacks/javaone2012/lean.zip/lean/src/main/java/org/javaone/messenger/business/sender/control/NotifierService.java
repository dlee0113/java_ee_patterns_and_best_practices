/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.javaone.messenger.business.sender.control;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Singleton;
import javax.enterprise.event.Observes;
import javax.servlet.AsyncContext;
import javax.servlet.ServletResponse;

/**
 *
 * @author adam-bien.com
 */
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class NotifierService {
    
    public void onNewRequest(@Observes AsyncContext asyncContext){
        ServletResponse response = asyncContext.getResponse();
        try {
            response.getWriter().print("works!");
        } catch (IOException ex) {
            Logger.getLogger(NotifierService.class.getName()).log(Level.SEVERE, null, ex);
        }
        asyncContext.complete();
    }
}
