package org.javaone.messenger.business.sender.boundary;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.javaone.messenger.business.sender.entity.JavaOneMessage;

@Path("messages")
@Stateless
public class MessagesResource {
    @Inject
    MessagingService ms;
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String messages(@Context HttpHeaders headers){
        return ms.messages();
        //return Response.ok().entity(new JavaOneMessage("works!")).build();
    }
}
