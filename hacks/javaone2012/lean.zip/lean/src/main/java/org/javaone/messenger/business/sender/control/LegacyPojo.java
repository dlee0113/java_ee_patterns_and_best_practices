/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.javaone.messenger.business.sender.control;

/**
 *
 * @author adam-bien.com
 */
public class LegacyPojo {
    
    private String configuration;

    public LegacyPojo(String configuration) {
        this.configuration = configuration;
    }
    
    public void connect(){
        System.out.println("Connected");
    }
}
