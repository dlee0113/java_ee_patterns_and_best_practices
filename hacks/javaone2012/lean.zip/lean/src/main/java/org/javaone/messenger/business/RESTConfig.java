package org.javaone.messenger.business;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author adam-bien.com
 */
@ApplicationPath("resources")
public class RESTConfig extends Application{
    
}
