package org.javaone.messenger.business.sender.control;

import javax.ejb.Asynchronous;
import javax.ejb.Stateless;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class AsyncExecutor {

    @Asynchronous
    public void execute(Runnable runnable){
        runnable.run();
    }
}
