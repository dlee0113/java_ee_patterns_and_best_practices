package org.javaone.messenger.business.sender.boundary;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionManagement;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.javaone.messenger.business.sender.control.LegacyPojo;
import org.javaone.messenger.business.sender.control.MessageCreator;
import org.javaone.messenger.business.sender.entity.JavaOneMessage;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class MessagingService {
    
    
    @PersistenceContext
    EntityManager em;
    
    @Inject
    MessageCreator mc;
    
    @Inject
    Instance<LegacyPojo> lp;
    
    public void send(String message){
        em.persist(new JavaOneMessage(message));
    }
    
    public String messages(){
        String message = "";
        List<Future<JavaOneMessage>> results = new ArrayList<Future<JavaOneMessage>>();
        for (int i = 0; i < 10; i++) {
            Future<JavaOneMessage> result = mc.create();
            results.add(result);
        }
        
        for (Future<JavaOneMessage> future : results) {
            try {
                message += future.get().toString();
            } catch (InterruptedException ex) {
                Logger.getLogger(MessagingService.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ExecutionException ex) {
                Logger.getLogger(MessagingService.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return message;
    }
}
