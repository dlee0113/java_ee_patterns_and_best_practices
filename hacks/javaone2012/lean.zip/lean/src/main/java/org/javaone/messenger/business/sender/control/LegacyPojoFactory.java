/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.javaone.messenger.business.sender.control;

import javax.enterprise.inject.Produces;

/**
 *
 * @author adam-bien.com
 */
public class LegacyPojoFactory {
    @Produces
    public LegacyPojo create(){
        LegacyPojo lp = new LegacyPojo("something");
        lp.connect();
        return lp;
    }
    
}
