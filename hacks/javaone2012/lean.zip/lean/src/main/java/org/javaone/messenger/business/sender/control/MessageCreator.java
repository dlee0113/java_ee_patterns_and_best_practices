/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.javaone.messenger.business.sender.control;

import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import org.javaone.messenger.business.sender.entity.JavaOneMessage;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class MessageCreator {
    
    @Asynchronous
    public Future<JavaOneMessage> create(){
        JavaOneMessage message = new JavaOneMessage("Spam: " + System.currentTimeMillis());
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(MessageCreator.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new AsyncResult<JavaOneMessage>(message);
    }
    
    
}
