/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.javaone.messenger.business.sender.control;

import java.security.Principal;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class CustomPrincipalProvider {
    
    @Inject
    Principal principal;
    
    @Produces
    public CustomPrincipal create(){
        return new CustomPrincipal(principal.getName());
    }
    
}
