package com.airhacks.airport.flights;

import java.net.URI;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

/**
 *
 * @author airhacks.com
 */
@Path("flights")
public class FlightsResource {

    @GET
    public JsonArray all() {
        JsonObject gdn = Json.createObjectBuilder().add("flight", "gdn").build();
        JsonObject muc = Json.createObjectBuilder().add("flight", "muc").build();
        return Json.createArrayBuilder().add(gdn).add(muc).build();
    }

    @GET
    @Path("{id}")
    public Flight get(@PathParam("id") String id) {
        return new Flight(id);
    }

    @POST
    public Response save(String city, @Context UriInfo info) {
        System.out.println("city = " + city);
        URI uri = info.getAbsolutePathBuilder().path("/" + city).build();
        return Response.created(uri).build();
    }

}
