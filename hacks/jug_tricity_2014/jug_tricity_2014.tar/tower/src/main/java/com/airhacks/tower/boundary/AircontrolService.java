package com.airhacks.tower.boundary;

import com.airhacks.tower.control.TargetURI;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import javax.annotation.Resource;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.enterprise.event.Observes;
import javax.inject.Inject;
import javax.json.JsonArray;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author airhacks.com
 */
public class AircontrolService {

    @Inject
    @TargetURI("http://localhost:8080/airport/resources/flights/")
    //@TargetURI("http://www.google.de")
    WebTarget target;

    @Resource
    ManagedExecutorService mes;

    public void onStatusRequest(@Observes Consumer<Object> consumer) {
        CompletableFuture.supplyAsync(this::flights, mes).
                thenAccept(consumer).exceptionally((t) -> {
                    System.out.println("!!!!!!!!!!!!! = " + t);
                    consumer.accept(Response.status(500).header("x-problem", "Timeout").build());
                    return null;
                });
    }

    public JsonArray flights() {
        return target.request(MediaType.APPLICATION_JSON).get(JsonArray.class);
    }

}
