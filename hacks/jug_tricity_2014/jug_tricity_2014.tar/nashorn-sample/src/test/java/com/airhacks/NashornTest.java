package com.airhacks;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import org.junit.Test;

/**
 *
 * @author airhacks.com
 */
public class NashornTest {

    @Test
    public void interfaceImplementation() throws ScriptException {
        Runnable run = interfaces();
        System.out.println("-- " + run);
        run.run();
    }

    public Runnable interfaces() throws ScriptException {
        ScriptEngineManager sem = new ScriptEngineManager();
        ScriptEngine engine = sem.getEngineByName("javascript");
        engine.eval("function run(){ print('run me');}");
        Invocable invocable = (Invocable) engine;
        return invocable.getInterface(Runnable.class);
    }

    @Test
    public void query() {
        List<String> strings = new ArrayList<>();
        strings.add("java");
        strings.add("javascript");
        strings.add("scala");
        List<String> filtered = strings.stream().
                filter((t) -> t.startsWith("j")).
                collect(Collectors.toList());
        System.out.println("filtered = " + filtered);
    }

}
