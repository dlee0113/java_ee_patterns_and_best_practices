/*
 */
package de.summit;

import de.summit.airportmgmt.business.flight.entity.Flight;
import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;
import java.util.function.Predicate;
import org.junit.Test;

/**
 *
 * @author adam-bien.com
 */
public class MapReduce {

    @Test
    public void flights() {
        List<Flight> flights = new ArrayList<>();
        flights.add(new Flight("lh", 1));
        flights.add(new Flight("lh", 2));
        flights.add(new Flight("topgun", 100));
        final Predicate<? super Flight> filter = f -> f.getNumber().equalsIgnoreCase("lh");
        OptionalDouble average = flights.parallelStream().
                filter(filter).
                mapToInt(f -> f.getCapacity()).
                average();
        System.out.println(" --  " + average.getAsDouble());
    }

}
