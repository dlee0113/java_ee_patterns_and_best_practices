/*
 */
package de.summit.airportmgmt.business.configurator.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam-bien.com
 */
public class Configurator {

    @Produces
    public String configure(InjectionPoint ip) {
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String name = ip.getMember().getName();
        return clazz.getName() + "." + name;
    }

}
