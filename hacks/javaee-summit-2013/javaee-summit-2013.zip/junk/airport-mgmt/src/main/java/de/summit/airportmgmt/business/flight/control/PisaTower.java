/*
 */
package de.summit.airportmgmt.business.flight.control;

/**
 *
 * @author adam-bien.com
 */
@Architecture(Architecture.Type.BROKEN)
public class PisaTower implements Tower {

    @Override
    public String validate(String id) {
        return " ok....";
    }

}
