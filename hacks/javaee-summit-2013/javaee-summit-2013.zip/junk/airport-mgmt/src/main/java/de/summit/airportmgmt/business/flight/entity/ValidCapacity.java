/*
 */
package de.summit.airportmgmt.business.flight.entity;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;

/**
 *
 * @author adam-bien.com
 */
@Documented
@Constraint(validatedBy = ValidCapacityValidator.class)
@Target({ElementType.TYPE, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidCapacity {

    String message() default "{de.summit.airportmgmt.business.flight.entity.ValidCapacity}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
