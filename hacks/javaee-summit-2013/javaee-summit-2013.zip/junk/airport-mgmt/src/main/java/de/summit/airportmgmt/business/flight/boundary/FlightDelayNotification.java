/*
 */
package de.summit.airportmgmt.business.flight.boundary;

import java.io.IOException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
@ServerEndpoint("/delays/{flight-name}")
public class FlightDelayNotification {

    private Session session;

    @OnOpen
    public void onOpen(Session session) {
        this.session = session;
        System.out.println("--- " + session);
        try {
            session.getBasicRemote().sendText("LH42 delayed");
        } catch (IOException ex) {
            Logger.getLogger(FlightDelayNotification.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @OnMessage
    public void message(@PathParam("flight-name") String key, String message) {
        System.out.println("Got message: " + key + " " + message);
    }

    //@Schedule(hour = "*", minute = "*", second = "*/2")
    public void notifyDelays() {
        System.out.println("Notifying: " + new Date());
        try {
            if (session != null) {
                session.getBasicRemote().sendText("Delay: " + new Date());
            }
        } catch (IOException ex) {
            Logger.getLogger(FlightDelayNotification.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
