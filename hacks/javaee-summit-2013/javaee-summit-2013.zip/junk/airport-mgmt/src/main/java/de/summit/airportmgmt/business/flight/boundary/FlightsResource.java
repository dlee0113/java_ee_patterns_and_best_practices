/*
 */
package de.summit.airportmgmt.business.flight.boundary;

import de.summit.airportmgmt.business.flight.entity.Flight;
import de.summit.airportmgmt.business.flight.entity.ValidCapacity;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

/**
 *
 * @author adam-bien.com
 */
@Stateless
@Path("flights")
public class FlightsResource {

    @Inject
    FlightBookingService fbs;

    @GET
    @Path("{nbr}")
    public Flight byNbr(@PathParam("nbr") String nbr, @Context HttpHeaders headers) {
        // Wrong place, but use this below for unit tests
        //Validation.buildDefaultValidatorFactory().getValidator();
        System.out.println("Headers: " + headers);
        return fbs.find(nbr);
    }

    @GET
    public List<Flight> all() {
        List<Flight> flights = new ArrayList<>();
        flights.add(new Flight("topgun", 2));
        return flights;
    }

    @POST
    public Response newFlight(@ValidCapacity Flight flight) {
        System.out.println("Flight: " + flight);
        this.fbs.save(flight);
        return Response.created(URI.create("/" + System.currentTimeMillis())).header("x-exception", "does not work").build();
    }
}
