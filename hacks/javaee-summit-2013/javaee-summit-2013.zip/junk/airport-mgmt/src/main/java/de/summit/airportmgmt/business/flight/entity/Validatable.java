/*
 */
package de.summit.airportmgmt.business.flight.entity;

/**
 *
 * @author adam-bien.com
 */
public interface Validatable {

    public boolean isValid();
}
