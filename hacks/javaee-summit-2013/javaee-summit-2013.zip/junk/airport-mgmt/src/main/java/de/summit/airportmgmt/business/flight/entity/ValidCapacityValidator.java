/*
 */
package de.summit.airportmgmt.business.flight.entity;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 *
 * @author adam-bien.com
 */
public class ValidCapacityValidator implements ConstraintValidator<ValidCapacity, Validatable> {

    @Override
    public void initialize(ValidCapacity constraintAnnotation) {

    }

    @Override
    public boolean isValid(Validatable value, ConstraintValidatorContext context) {
        return value.isValid();
    }
}
