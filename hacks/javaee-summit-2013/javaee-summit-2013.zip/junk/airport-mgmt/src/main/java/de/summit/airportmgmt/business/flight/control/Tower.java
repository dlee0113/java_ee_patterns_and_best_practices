/*
 */
package de.summit.airportmgmt.business.flight.control;

/**
 *
 * @author adam-bien.com
 */
public interface Tower {

    String validate(String id);

}
