/*
 */
package de.summit.airportmgmt.business.flight.boundary;

import de.summit.airportmgmt.business.flight.control.Tower;
import de.summit.airportmgmt.business.flight.entity.Flight;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class FlightBookingService {

    @Inject
    @Any
    Instance<Tower> towers;

    @Inject
    Event<Flight> flights;

    @Inject
    String defaultFlight;

    public Flight find(String nbr) {
        /*
         for (Tower tower : towers) {
         System.out.println("Tower: " + tower);
         }
         */
        return new Flight(defaultFlight, 5);
    }

    public void save(Flight flight) {
        System.out.println("Saving to DB: " + flight);
        flights.fire(flight);
    }
}
