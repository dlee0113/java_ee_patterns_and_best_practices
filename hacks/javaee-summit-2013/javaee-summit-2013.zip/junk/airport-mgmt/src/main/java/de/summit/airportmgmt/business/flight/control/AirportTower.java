/*
 */
package de.summit.airportmgmt.business.flight.control;

/**
 *
 * @author adam-bien.com
 */
@Architecture(Architecture.Type.MODERN)
public class AirportTower implements Tower {

    @Override
    public String validate(String id) {
        return id + " ok";
    }
}
