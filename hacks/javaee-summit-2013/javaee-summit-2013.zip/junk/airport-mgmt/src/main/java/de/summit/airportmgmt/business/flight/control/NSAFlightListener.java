/*
 */
package de.summit.airportmgmt.business.flight.control;

import de.summit.airportmgmt.business.flight.entity.Flight;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;
import javax.enterprise.inject.spi.EventMetadata;

/**
 *
 * @author adam-bien.com
 */
//@Stateless
public class NSAFlightListener {

    //@Asynchronous
    public void onFlight(@Observes(during = TransactionPhase.AFTER_SUCCESS) Flight f, EventMetadata em) {
        System.out.println("NSA says thanks!: " + f + em.getInjectionPoint().getMember().getName());
    }
}
