/*
 */
package de.summit.airportmgmt.presentation;

import de.summit.airportmgmt.business.flight.boundary.FlightBookingService;
import de.summit.airportmgmt.business.flight.entity.Flight;
import java.util.Set;
import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

/**
 *
 * @author adam-bien.com
 */
@Model
public class Index {

    @Inject
    FlightBookingService fbs;

    Flight flight;

    @Inject
    Validator validator;

    @PostConstruct
    public void init() {
        this.flight = new Flight();
    }

    public Flight getFlight() {
        return flight;
    }

    public Object save() {
        System.out.println("Flight: " + flight);
        Set<ConstraintViolation<Flight>> violations = validator.validate(this.flight);
        if (!violations.isEmpty()) {
            //FacesContext.getCurrentInstance().ad
            return "invalid";
        }
        this.fbs.save(flight);
        return null;
    }

}
