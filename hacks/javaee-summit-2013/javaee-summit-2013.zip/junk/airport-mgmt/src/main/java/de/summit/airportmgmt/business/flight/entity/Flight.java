/*
 */
package de.summit.airportmgmt.business.flight.entity;

import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam-bien.com
 */
@ValidCapacity
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Flight implements Validatable {

    @Size(min = 2, max = 10, message = "Custom message")
    private String number;
    private int capacity;

    public Flight(String number, int capacity) {
        this.number = number;
        this.capacity = capacity;
    }

    public Flight() {
    }

    @Override
    public String toString() {
        return "Flight{" + "number=" + number + ", capacity=" + capacity + '}';
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    @Override
    public boolean isValid() {
        return "topgun".equals(this.number) && capacity <= 2;
    }

}
