/*
 */
package com.airhacks.airport.mgmt.st;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam-bien.com
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Flight {

    private String number;
    private int capacity;

    private String something;

    public Flight(String number, int capacity) {
        this.number = number;
        this.capacity = capacity;
    }

    public Flight() {
    }

    @Override
    public String toString() {
        return "Flight{" + "number=" + number + ", capacity=" + capacity + '}';
    }

}
