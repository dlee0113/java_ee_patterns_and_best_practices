/*
 */
package com.airhacks.airport.mgmt.st;

import javax.json.JsonObject;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import junit.framework.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author adam-bien.com
 */
public class FlightsResourceTest {

    private Client client;
    private WebTarget flightsTarget;

    @Before
    public void initialize() {
        this.client = ClientBuilder.newClient();
        this.flightsTarget = this.client.target("http://localhost:8080/airport-mgmt/resources/flights");
    }

    @Test
    public void flightByNumber() {
        Flight flight = this.flightsTarget.path("42").request().get(Flight.class);
        Assert.assertNotNull(flight);
        System.out.println("Flight: " + flight);
    }

    @Test
    public void flighByNumberTypeUnsafe() {
        JsonObject flight = this.flightsTarget.path("42").request(MediaType.APPLICATION_JSON).get(JsonObject.class);
        Assert.assertNotNull(flight);
        System.out.println("As json: " + flight);

    }

}
