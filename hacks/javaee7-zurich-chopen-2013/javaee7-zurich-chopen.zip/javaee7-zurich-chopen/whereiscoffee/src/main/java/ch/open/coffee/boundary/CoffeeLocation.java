/*
 *
 */
package ch.open.coffee.boundary;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class CoffeeLocation {

    private String name;
    private int capacity;

    public boolean isValid() {
        return name != null && capacity > 90;
    }
}
