/*
 *
 */
package ch.open.coffee.boundary;

import ch.open.coffee.control.AnswerCache;
import javax.ejb.Stateless;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class AnswerService {

    @Inject
    AnswerCache cache;

    public String answer() {
        return cache.cached();
    }
}
