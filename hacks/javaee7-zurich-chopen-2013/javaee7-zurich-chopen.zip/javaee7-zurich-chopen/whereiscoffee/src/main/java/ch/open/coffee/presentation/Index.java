/*
 *
 */
package ch.open.coffee.presentation;

import ch.open.coffee.boundary.AnswerService;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Model
public class Index {

    @Inject
    AnswerService as;

    public String getAnswer() {
        return as.answer();
    }
}
