/*
 *
 */
package ch.open.coffee.entity;

import javax.persistence.Entity;

/**
 *
 * @author adam-bien.com
 */
@Entity
public class Cafeteria {

}
