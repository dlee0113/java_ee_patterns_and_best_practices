/*
 *
 */
package ch.open.coffee.boundary;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 *
 * @author adam-bien.com
 */
public class JavaEECompatibleValidator implements ConstraintValidator<JavaEECompatible, CoffeeLocation> {

    @Override
    public void initialize(JavaEECompatible constraintAnnotation) {
    }

    @Override
    public boolean isValid(CoffeeLocation value, ConstraintValidatorContext context) {
        return value.isValid();

    }
}
