/*
 *
 */
package ch.open.coffee.boundary;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.enterprise.concurrent.ManagedExecutorService;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class DTComputer {

    @Resource
    ManagedExecutorService mes;

    public int answer() {
        Callable<Integer> answer = new Callable<Integer>() {

            @Override
            public Integer call() throws Exception {
                return 42;
            }
        };
        Future<Integer> theAnswer = mes.submit(answer);
        try {
            Integer result = theAnswer.get();
        } catch (InterruptedException | ExecutionException ex) {
            return 21;
        }
        return 42;
    }

}
