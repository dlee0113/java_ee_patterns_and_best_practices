/*
 *
 */
package ch.open.coffee.startup;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.persistence.Persistence;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
public class Initializer {

    @PostConstruct
    public void init() {
        Persistence.generateSchema("it", null/* properties */);
    }

}
