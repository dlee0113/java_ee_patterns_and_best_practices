/*
 *
 */
package ch.open.coffee.control;

/**
 *
 * @author adam-bien.com
 */
public class AnswerCache {

    public String cached() {
        return "from cache";
    }

}
