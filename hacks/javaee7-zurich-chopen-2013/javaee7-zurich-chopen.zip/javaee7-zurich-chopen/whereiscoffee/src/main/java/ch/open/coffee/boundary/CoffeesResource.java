/*
 *
 */
package ch.open.coffee.boundary;

import java.util.concurrent.TimeUnit;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.json.Json;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;
import javax.ws.rs.container.TimeoutHandler;
import javax.ws.rs.core.Response;

/**
 *
 * @author adam-bien.com
 */
@Stateless
@Path("coffees")
public class CoffeesResource {

    @Inject
    DTComputer computer;

    @GET
    public void find(@Suspended AsyncResponse response) {
        response.setTimeout(10, TimeUnit.SECONDS);
        response.setTimeoutHandler(new TimeoutHandler() {

            @Override
            public void handleTimeout(AsyncResponse asyncResponse) {
                asyncResponse.resume(Response.noContent().build());

            }
        });
        response.resume(Json.createObjectBuilder().add("answer", computer.answer()).build().toString());
    }

    @POST
    public void save(@JavaEECompatible CoffeeLocation location) {
        System.out.println("Thanks for the location: " + location);
    }

}
