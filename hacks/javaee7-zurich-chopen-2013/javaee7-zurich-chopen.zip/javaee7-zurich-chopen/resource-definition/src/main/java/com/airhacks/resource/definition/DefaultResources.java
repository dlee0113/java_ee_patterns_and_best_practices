package com.airhacks.resource.definition;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.jms.ConnectionFactory;
import javax.sql.DataSource;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
public class DefaultResources {

    @Resource
    DataSource ds;

    @Resource
    ConnectionFactory connectionFactory;

    @PostConstruct
    public void initialize() {
        System.out.println("DataSource: " + ds);
        System.out.println("ConnectionFactory: " + connectionFactory);
    }
}
