package com.airhacks.resource.definition;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.jms.ConnectionFactory;
import javax.jms.JMSConnectionFactoryDefinition;
import javax.jms.JMSDestinationDefinition;
import javax.jms.JMSException;
import javax.jms.Queue;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
@JMSDestinationDefinition(name = "java:app/AirQueue",
        interfaceName = "javax.jms.Queue", destinationName = "airqueue")
@JMSConnectionFactoryDefinition(name = "java:app/AirhacksConnectionFactory",
        interfaceName = "javax.jms.QueueConnectionFactory")
public class JMSResourceSetup {

    @Resource(lookup = "java:app/AirhacksConnectionFactory")
    ConnectionFactory connectionFactory;

    @Resource(lookup = "java:app/AirQueue")
    Queue queue;

    @PostConstruct
    public void validateDI() {
        try {
            System.out.println("DataSource: " + connectionFactory.createConnection());
            System.out.println("Queue: " + queue);

        } catch (JMSException ex) {
            Logger.getLogger(JMSResourceSetup.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
