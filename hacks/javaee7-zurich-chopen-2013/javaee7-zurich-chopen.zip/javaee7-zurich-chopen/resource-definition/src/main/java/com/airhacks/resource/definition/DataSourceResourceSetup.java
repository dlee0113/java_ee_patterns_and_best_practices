package com.airhacks.resource.definition;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.sql.DataSource;

/**
 *
 * @author adam-bien.com
 */
@DataSourceDefinition(name = "java:app/AirhacksSource",
        className = "org.apache.derby.jdbc.EmbeddedDriver",
        url = "jdbc:derby:./sample;create=true")
@Startup
@Singleton
public class DataSourceResourceSetup {

    @Resource(lookup = "java:app/AirhacksSource")
    DataSource source;

    @PostConstruct
    public void validateDI() {
        try {
            System.out.println("DataSource: " + source.getConnection());
        } catch (SQLException ex) {
            Logger.getLogger(DataSourceResourceSetup.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
