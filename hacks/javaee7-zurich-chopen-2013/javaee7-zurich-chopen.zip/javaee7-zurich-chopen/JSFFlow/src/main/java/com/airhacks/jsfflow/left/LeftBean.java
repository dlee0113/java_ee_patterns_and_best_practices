/*
 * 
 */
package com.airhacks.jsfflow.left;

import javax.faces.flow.FlowScoped;
import javax.inject.Named;

/**
 *
 * @author adam-bien.com
 */
@Named
@FlowScoped("left")
public class LeftBean {
    
    public String getNavigation(){
        return "/back";
    }
    
}
