/*
 * 
 */
package com.airhacks.jsfflow;

import javax.enterprise.inject.Produces;
import javax.faces.flow.Flow;
import javax.faces.flow.builder.FlowBuilder;
import javax.faces.flow.builder.FlowBuilderParameter;
import javax.faces.flow.builder.FlowDefinition;

/**
 *
 * @author adam-bien.com
 */
public class FlowConfiguration {
     
    @Produces @FlowDefinition
    public Flow build(@FlowBuilderParameter FlowBuilder flowBuilder) {
        String flowId = "left";
        flowBuilder.id("", flowId);
        flowBuilder.viewNode(flowId, "/" + flowId + "-flow/" + flowId + ".xhtml");
        flowBuilder.returnNode("returnAction").fromOutcome("#{leftBean.navigation}");        

        return flowBuilder.getFlow();
    }
}
