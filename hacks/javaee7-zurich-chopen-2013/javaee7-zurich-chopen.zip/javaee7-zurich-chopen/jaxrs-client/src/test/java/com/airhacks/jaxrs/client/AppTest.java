package com.airhacks.jaxrs.client;

import javax.json.JsonObject;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import static org.hamcrest.CoreMatchers.is;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest {

    private Client client;

    @Before
    public void initClient() {
        this.client = ClientBuilder.newClient().r;
    }

    //@Test(timeout = 11000)
    public void timeout() {
        Response response = this.client.target("http://locahost:8080/whereiscoffee/v1/coffees").request().get();
        Assert.assertThat(response.getStatus(), is(204));
    }

    @Test(timeout = 1000)
    public void fetch() {
        Response response = this.client.target("http://localhost:8080/whereiscoffee/v1/coffees").request(MediaType.APPLICATION_JSON).get();
        Assert.assertThat(response.getStatus(), is(200));
        JsonObject readEntity = response.readEntity(JsonObject.class);
        System.out.println("JsonObject: " + readEntity);
    }
}
