/*
 *
 */
package com.airhacks.jaxrs.client;

import org.junit.Before;
import org.junit.Test;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 *
 * @author adam-bien.com
 */
public class DTComputerTest {

    DTComputer cut;

    @Before
    public void init() {
        this.cut = mock(DTComputer.class);
    }

    @Test
    public void wrongAnswer() {
        when(this.cut.answer()).thenReturn("21");
        System.out.println(" " + this.cut.answer());
    }

}
