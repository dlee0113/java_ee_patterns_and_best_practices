/*
 *
 */
package com.airhacks.jaxrs.client;

/**
 *
 * @author adam-bien.com
 */
public class DTComputer {

    public String answer() {
        return "The answer is: 42";
    }

}
