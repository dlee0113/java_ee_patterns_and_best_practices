package com.airhacks.jms.presentation;

import com.airhacks.jms.business.sendandreceive.Sender;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Model
public class Index {

    @Inject
    Sender sender;

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object send() {
        this.sender.send(message);
        return null;
    }
}
