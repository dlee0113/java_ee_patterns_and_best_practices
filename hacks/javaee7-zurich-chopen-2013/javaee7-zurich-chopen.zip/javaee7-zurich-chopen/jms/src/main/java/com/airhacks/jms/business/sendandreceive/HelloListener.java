package com.airhacks.jms.business.sendandreceive;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.Message;
import javax.jms.MessageListener;

/**
 *
 * @author adam-bien.com
 */
@MessageDriven(activationConfig = {
    @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
    @ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = "jms/hello")
})
public class HelloListener implements MessageListener {

    @Override
    public void onMessage(Message message) {
        System.out.println("Receiving: " + message);
    }

}
