package com.airhacks.jms.business.sendandreceive;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSContext;
import javax.jms.Queue;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class Sender {

    @Resource(mappedName = "jms/hello")
    private Queue hello;

    @Inject
    @JMSConnectionFactory("java:comp/DefaultJMSConnectionFactory")
    private JMSContext context;

    public void send(String messageData) {
        context.createProducer().send(hello, messageData);
    }

}
