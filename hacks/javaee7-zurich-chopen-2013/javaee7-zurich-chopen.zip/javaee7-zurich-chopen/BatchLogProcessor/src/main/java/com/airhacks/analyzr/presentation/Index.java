/*
 *
 */
package com.airhacks.analyzr.presentation;

import com.airhacks.analyzr.business.logprocessor.boundary.JobController;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Model
public class Index {

    @Inject
    JobController controller;

    private long currentJob;

    public long getCurrentJob() {
        return currentJob;
    }

    public void setCurrentJob(long currentJob) {
        this.currentJob = currentJob;
    }

    public String getStatus() {
        if (currentJob == 0) {
            return "";
        }
        return this.controller.getStatus(currentJob).toString();
    }

    public Object start() {
        this.currentJob = this.controller.start();
        return null;
    }

}
