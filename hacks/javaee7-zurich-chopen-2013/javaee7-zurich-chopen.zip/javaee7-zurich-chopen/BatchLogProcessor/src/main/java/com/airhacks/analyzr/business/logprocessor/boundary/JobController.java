/*
 *
 */
package com.airhacks.analyzr.business.logprocessor.boundary;

import java.util.Properties;
import javax.batch.operations.JobOperator;
import javax.batch.runtime.BatchRuntime;
import javax.batch.runtime.BatchStatus;
import javax.ejb.Stateless;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class JobController {

    public long start() {
        JobOperator operator = BatchRuntime.getJobOperator();
        Properties props = new Properties();
        props.setProperty("filename", "server.log");
        return operator.start("logprocessing", props);
    }

    public BatchStatus getStatus(long executionId) {
        return BatchRuntime.getJobOperator().getJobExecution(executionId).getBatchStatus();
    }
}
