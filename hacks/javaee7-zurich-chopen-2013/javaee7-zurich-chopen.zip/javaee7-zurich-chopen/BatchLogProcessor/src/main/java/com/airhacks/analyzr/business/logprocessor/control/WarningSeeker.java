package com.airhacks.analyzr.business.logprocessor.control;

import javax.batch.api.chunk.ItemProcessor;

public class WarningSeeker
        implements ItemProcessor {

    @Override
    public Object processItem(Object obj) throws Exception {
        String line = (String) obj;
        if (line.contains("WARNING")) {
            return line;
        } else {
            return null;
        }
    }

}
