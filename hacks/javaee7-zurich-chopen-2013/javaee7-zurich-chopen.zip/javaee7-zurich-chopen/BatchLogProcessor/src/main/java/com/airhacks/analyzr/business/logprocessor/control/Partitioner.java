package com.airhacks.analyzr.business.logprocessor.control;

import javax.batch.api.partition.PartitionMapper;
import javax.batch.api.partition.PartitionPlan;
import javax.batch.api.partition.PartitionPlanImpl;

public class Partitioner implements PartitionMapper {

    @Override
    public PartitionPlan mapPartitions() throws Exception {
        PartitionPlanImpl partition = new PartitionPlanImpl();
        partition.setPartitions(5);
        partition.setThreads(5);
        return partition;
    }

}
