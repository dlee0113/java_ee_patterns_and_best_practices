package com.airhacks.analyzr.business.logprocessor.control;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.Properties;
import javax.batch.api.chunk.AbstractItemReader;
import javax.batch.runtime.BatchRuntime;
import javax.batch.runtime.context.JobContext;
import javax.inject.Inject;

public class RemoteLogReader
        extends AbstractItemReader {

    @Inject
    private JobContext jobContext;
    private BufferedReader logStream;

    @Override
    public void open(Serializable e) throws Exception {
        Properties properties = BatchRuntime.getJobOperator().getParameters(jobContext.getExecutionId());
        System.out.println("ID: " + jobContext.getExecutionId() + " Properties: " + properties);
        String filename = "server.log";
        if (properties != null) {
            filename = properties.getProperty("filename");
        }
        final InputStream resourceAsStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(filename);
        this.logStream = new BufferedReader(new InputStreamReader(resourceAsStream));
    }

    public Object readItem() throws Exception {
        return this.logStream.readLine();
    }

}
