package com.airhacks.analyzr.business.logprocessor.control;

import java.io.Serializable;
import java.util.List;
import javax.batch.api.chunk.AbstractItemWriter;

public class SystemOutWriter
        extends AbstractItemWriter {

    @Override
    public void open(Serializable checkpoint) throws Exception {
        super.open(checkpoint);
    }

    @Override
    public void writeItems(List list) throws Exception {
        for (int i = 0; i < list.size(); i++) {
            Object object = list.get(i);
            System.out.println("[" + i + "] " + String.valueOf(object));
        }
    }

}
