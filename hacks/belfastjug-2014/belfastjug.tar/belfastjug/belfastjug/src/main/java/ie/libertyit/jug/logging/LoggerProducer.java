package ie.libertyit.jug.logging;

import java.util.function.Consumer;
import java.util.logging.Logger;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author airhacks.com
 */
public class LoggerProducer {

    @Produces
    public Consumer<String> configure(InjectionPoint ip) {
        String name = ip.getMember().getDeclaringClass().getName();
        return Logger.getLogger(name)::info;
    }

}
