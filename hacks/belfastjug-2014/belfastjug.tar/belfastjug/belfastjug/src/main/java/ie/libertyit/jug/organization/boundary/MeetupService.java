package ie.libertyit.jug.organization.boundary;

import ie.libertyit.jug.organization.control.SessionEvaluator;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
public class MeetupService {

    @Inject
    SessionEvaluator se;

    public String eval() {
        return String.valueOf(se.evaluation("java"));
    }

}
