package ie.libertyit.jug.configuration.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author airhacks.com
 */
public class Configurator {

    @Produces
    public String expose(InjectionPoint ip, Stage stage) {
        String clazzName = ip.getMember().getDeclaringClass().getName();
        String fieldName = ip.getMember().getName();
        return clazzName + "---->" + fieldName + " " + stage;
    }

}
