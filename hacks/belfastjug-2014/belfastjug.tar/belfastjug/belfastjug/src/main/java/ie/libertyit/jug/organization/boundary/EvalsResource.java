package ie.libertyit.jug.organization.boundary;

import java.util.function.Consumer;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;

/**
 *
 * @author airhacks.com
 */
@Stateless
@Interceptors(Auditor.class)
@Path("evals")
public class EvalsResource {

    @Inject
    Event<Consumer<String>> events;

    @GET
    public void eval(@Suspended AsyncResponse response) {
        Consumer<String> consumer = response::resume;
        events.fire(consumer);
    }

}
