package ie.libertyit.jug.organization.control;

/**
 *
 * @author airhacks.com
 */
public class SessionEvaluator {

    public int evaluation(String title) {
        if (title.contains("java")) {
            return 11;
        } else {
            return -1;
        }
    }

}
