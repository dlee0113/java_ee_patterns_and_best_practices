package ie.libertyit.jug.organization.control;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import javax.annotation.Resource;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.enterprise.event.Observes;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
public class EvaluationProcessor {

    @Inject
    Messenger messenger;

    @Resource
    ManagedExecutorService pool;

    public void onNewEvaluation(@Observes Consumer<String> client) {
        CompletableFuture.supplyAsync(messenger::message, pool).thenAccept(client);

    }

}
