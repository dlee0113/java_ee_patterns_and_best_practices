package ie.libertyit.jug.configuration.boundary;

/**
 *
 * @author airhacks.com
 */
public enum Stage {

    DEV, PROD;
}
