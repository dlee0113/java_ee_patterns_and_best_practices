package ie.libertyit.jug.configuration.boundary;

import javax.enterprise.inject.Produces;

/**
 *
 * @author airhacks.com
 */
public class Staging {

    @Produces
    public Stage expose() {
        return Stage.DEV;
    }

}
