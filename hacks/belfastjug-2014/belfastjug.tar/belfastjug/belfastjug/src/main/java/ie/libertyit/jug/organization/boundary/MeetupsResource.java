package ie.libertyit.jug.organization.boundary;

import java.net.URI;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

/**
 *
 * @author airhacks.com
 */
@Stateless
@Path("meetups")
public class MeetupsResource {

    @Inject
    MeetupService ms;

    @GET
    public JsonArray all() {
        JsonObject m1 = Json.createObjectBuilder().
                add("java", "rocks").
                add("rank", ms.eval()).
                build();
        return Json.createArrayBuilder().add(m1).build();
    }

    @GET
    @Path("{id}")
    public JsonObject byId(@PathParam("id") long id) {
        return Json.createObjectBuilder().
                add("java", "rocks").
                add("id", id).
                build();

    }

    @POST
    public Response save(JsonObject meetup, @Context UriInfo info) {
        System.out.println("meetup = " + meetup);
        URI uri = info.getAbsolutePathBuilder().path("/" + System.currentTimeMillis()).build();
        return Response.created(uri).build();
    }

}
