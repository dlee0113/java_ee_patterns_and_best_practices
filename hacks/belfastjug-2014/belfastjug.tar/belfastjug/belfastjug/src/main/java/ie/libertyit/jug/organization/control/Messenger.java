package ie.libertyit.jug.organization.control;

import java.util.function.Consumer;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
public class Messenger {

    @Inject
    String message;

    @Inject
    Consumer<String> LOG;

    public String message() {
        LOG.accept("Called");
        return "no questions, no t-shirts! " + message;
    }

}
