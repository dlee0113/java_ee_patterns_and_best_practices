package com.devoxx.business.security.boundary;

import com.devoxx.business.security.entity.DevoxxHacker;
import java.security.Principal;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class SecurityProvider {

    @Inject
    private Principal principal;
    
    @Produces
    public DevoxxHacker hacker(){
        return new DevoxxHacker(principal.getName(),"admin --from database");
    }
}
