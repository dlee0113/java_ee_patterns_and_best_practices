/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.devoxx.business.security.entity;

/**
 *
 * @author adam-bien.com
 */
public class DevoxxHacker {
    private String name;
    private String permissions;

    public DevoxxHacker(String name, String permissions) {
        this.name = name;
        this.permissions = permissions;
    }
    
    
}
