/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.devoxx.business.slides.control;

/**
 *
 * @author adam-bien.com
 */
public class Buzzwords {
    
    public String next(){
        return "esb";
    }
}
