package com.devoxx.business.slides.boundary;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam-bien.com
 */
public class PerformanceAudit {

    @AroundInvoke
    public Object measure(InvocationContext ic) throws Exception{
        try{
        
            return ic.proceed();
        }finally{
            System.out.println("_--- " + ic.getMethod());
        }
    }
}
