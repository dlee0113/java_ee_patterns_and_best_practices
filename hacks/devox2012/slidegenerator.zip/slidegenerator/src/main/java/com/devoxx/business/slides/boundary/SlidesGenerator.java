package com.devoxx.business.slides.boundary;
import com.devoxx.business.slides.control.Buzzwords;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
/**
 *
 * @author adam-bien.com
 */
@Stateless
@Interceptors(PerformanceAudit.class)
public class SlidesGenerator {
    
    @Inject
    String message;
    
    @Inject
    Buzzwords buzzwords;
    
    public String slides(){
        return message;
    }
}
