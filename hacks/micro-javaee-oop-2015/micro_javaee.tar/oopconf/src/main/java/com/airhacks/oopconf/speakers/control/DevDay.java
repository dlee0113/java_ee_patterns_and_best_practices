package com.airhacks.oopconf.speakers.control;

import javax.annotation.PostConstruct;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

/**
 *
 * @author airhacks.com
 */
public class DevDay {

    private Client client;
    private WebTarget speakersTarget;

    @PostConstruct
    public void init() {
        this.client = ClientBuilder.newClient();

        this.speakersTarget = this.client.target("http://localhost:8080/oradevs/resources/sessions");
    }

    public String speakers() {
        return this.speakersTarget.
                request().
                get(String.class);
    }

}
