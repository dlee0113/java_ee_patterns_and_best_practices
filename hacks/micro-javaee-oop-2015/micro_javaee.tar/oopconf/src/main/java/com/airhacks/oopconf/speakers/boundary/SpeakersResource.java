package com.airhacks.oopconf.speakers.boundary;

import com.airhacks.oopconf.speakers.control.DevDay;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonArray;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

/**
 *
 * @author airhacks.com
 */
@Stateless
@Path("speakers")
public class SpeakersResource {

    @Inject
    DevDay other;

    @GET
    public JsonArray speakers() {
        String speakers = other.speakers();
        return Json.createArrayBuilder().add("duke").add(speakers).build();
    }
}
