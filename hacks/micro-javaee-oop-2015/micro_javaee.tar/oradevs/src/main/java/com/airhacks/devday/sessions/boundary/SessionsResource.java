package com.airhacks.devday.sessions.boundary;

import javax.json.Json;
import javax.json.JsonArray;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

/**
 *
 * @author airhacks.com
 */
@Path("sessions")
public class SessionsResource {

    @GET
    public JsonArray all() {
        return Json.createArrayBuilder().add("javaee").add("events").build();
    }

}
