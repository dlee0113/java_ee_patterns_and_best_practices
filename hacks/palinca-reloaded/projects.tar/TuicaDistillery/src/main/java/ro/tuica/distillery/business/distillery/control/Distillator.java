package ro.tuica.distillery.business.distillery.control;

/**
 *
 * @author airhacks.com
 */
public class Distillator {

    public void doSomethingExpensive() {
        System.out.println("Done!");
    }
}
