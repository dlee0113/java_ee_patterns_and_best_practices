package com.gameduell.business.techtalk.control;

import java.util.Date;
import javax.ejb.Schedule;
import javax.ejb.Singleton;

/**
 *
 * @author adam-bien.com
 */
@Singleton
public class SimpleTimer {
    
    //@Schedule(hour="*",minute="*",second="*/1")
    public void repeatMe(){
        System.out.println("On timeout: " + new Date());
    }
}
