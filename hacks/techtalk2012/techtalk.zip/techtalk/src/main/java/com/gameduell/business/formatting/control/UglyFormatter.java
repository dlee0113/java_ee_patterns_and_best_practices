/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gameduell.business.formatting.control;

/**
 *
 * @author adam-bien.com
 */
public class UglyFormatter implements Formatter{

    @Override
    public String format(String format) {
        return "copyright adam bien " + format;
    }
    
}
