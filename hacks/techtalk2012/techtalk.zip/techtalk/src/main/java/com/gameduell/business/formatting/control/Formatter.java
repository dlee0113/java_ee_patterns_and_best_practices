package com.gameduell.business.formatting.control;

/**
 *
 * @author adam-bien.com
 */
public interface Formatter {
    public String format(String format);
}
