package com.gameduell.business.techtalk.control;

import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class PrepareSlides {

    @Asynchronous
    public Future<String> prepareSlide(int number){
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(PrepareSlides.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new AsyncResult<String>("Prepared ! " + number);
    }
}
