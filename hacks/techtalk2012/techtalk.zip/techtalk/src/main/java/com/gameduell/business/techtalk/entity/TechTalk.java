package com.gameduell.business.techtalk.entity;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class TechTalk implements Serializable{

    private String title;

    public TechTalk() {
    }

    public TechTalk(String title) {
        this.title = title;
    }
     
    
    
}
