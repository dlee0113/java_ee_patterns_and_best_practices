/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gameduell.business.configuration;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.Specializes;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam-bien.com
 */
public class SpecificConfigurator extends Configurator{

    @Override @Produces @Specializes
    public String getString(InjectionPoint ip) {
        return "hardcoded";
    }
    
}
