package com.gameduell.business.techtalk.boundary;

import com.gameduell.business.formatting.control.Formatter;
import com.gameduell.business.techtalk.control.PrepareSlides;
import com.gameduell.business.techtalk.entity.TechTalk;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author adam-bien.com
 */
@Stateless
@Path("techtalks")
@Produces({"awesome/serializer",MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
public class TechtalksResource {
    
    @Inject
    PrepareSlides prepareSlides;
    @Inject
    String message;

    @Inject
    String iamdifferent;
    
    @Inject
    Instance<Formatter> formatter;
    
    @Inject
    Event<String> listeners;
    
    @GET
    public TechTalk talks(@Context HttpHeaders headers){
        List<Future<String>> results = new ArrayList<Future<String>>();
        for(int i=0;i<10;i++){
          Future<String> slides = prepareSlides.prepareSlide(i);
          results.add(slides);
        }
        for (Future<String> future : results) {
            try {
                System.out.println("Got result " + future.get());
            } catch (Exception ex) {
            }
        }
        for (Formatter format : formatter) {
            System.out.println("Found: " + format);

        }
        listeners.fire(message);

        return new TechTalk(message + iamdifferent+ headers.getRequestHeaders());
    }
}
