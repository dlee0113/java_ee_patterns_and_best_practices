/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gameduell.business.formatting.control;

import javax.enterprise.inject.Alternative;

/**
 *
 * @author adam-bien.com
 */
public class NiceFormatter implements Formatter{

    @Override
    public String format(String format) {
        return "beatiful! " + format;
    }
    
}
