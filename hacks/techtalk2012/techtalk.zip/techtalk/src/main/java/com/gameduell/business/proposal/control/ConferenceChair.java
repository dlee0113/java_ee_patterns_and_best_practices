/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gameduell.business.proposal.control;

import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author adam-bien.com
 */
public class ConferenceChair {

    public void content(@Observes(during= TransactionPhase.AFTER_SUCCESS) String content){
        System.out.println("Content: " + content);
    }
}
