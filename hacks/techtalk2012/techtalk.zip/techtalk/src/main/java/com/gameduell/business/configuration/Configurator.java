/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gameduell.business.configuration;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;


/**
 *
 * @author adam-bien.com
 */
public class Configurator {
   
    @Produces
    public String getString(InjectionPoint ip){
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String name = ip.getMember().getName();
        return "configured " + clazz.getName() + "." +name;
    }
}
