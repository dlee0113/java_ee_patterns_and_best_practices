#!/usr/bin/jjs -fv

var command = "curl http://localhost:5555/containers/json";
$EXEC(command);
var rawOutput = $OUT;
//print(rawOutput);
var containers = JSON.parse(rawOutput);
//print(containers);
for each(container in containers) {
    print(container.Id + " " + container.Names[0] + " " + container.Image);

}
