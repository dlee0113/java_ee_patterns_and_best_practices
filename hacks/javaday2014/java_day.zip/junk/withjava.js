#!/usr/bin/jjs -cp ./naslib/target/naslib.jar -fv
var inspector = com.airhacks.naslib.Inspector;
var args = $ARG;

//inspector.gadget(args);
for each(arg in args) {
    print(arg);
}

var Runnable = java.lang.Runnable;

var executable = function () {
    print("runnable should work now");
};
var runnable = new Runnable(executable);

print(runnable);
runnable.run();
