package com.airhacks.naslib;

import java.lang.reflect.Method;

/**
 *
 * @author airhacks.com
 */
public class Inspector {

    public static void gadget(Object o) {
        final Class<? extends Object> clazz = o.getClass();
        System.out.println("Clazz: " + clazz.getName());
        Method[] methods = clazz.getMethods();
        for (Method method : methods) {
            System.out.println("" + method);
        }
    }

}
