package com.nashacks;

import java.math.BigDecimal;
import javax.script.Compilable;
import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author airhacks.com
 */
public class PlayingTest {

    private ScriptEngine engine;

    @Before
    public void initialize() {
        ScriptEngineManager sem = new ScriptEngineManager();
        this.engine = sem.getEngineByName("javascript");
    }

    @Test
    public void isNashorn() {
        assertTrue(this.engine.getClass().getName().toLowerCase().contains("nashorn"));
        assertTrue(this.engine instanceof Invocable);
        assertTrue(this.engine instanceof Compilable);
    }

    @Test
    public void playingWithInvocable() throws ScriptException {
        Invocable invocable = (Invocable) this.engine;
        this.engine.eval("function run(){ print(\'hey duke\');}");
        Runnable runnable = invocable.getInterface(Runnable.class);
        assertNotNull(runnable);
        runnable.run();
    }

    @Test
    public void accessinJavaAPIs() throws ScriptException {
        this.engine.put("A", new BigDecimal(21));
        this.engine.put("B", new BigDecimal(2));
        this.engine.put("MESSAGE", "a java string");
        Double retVal = (Double) this.engine.eval("A * B");
        assertThat(retVal, is(42.0));
        String message = (String) this.engine.eval("MESSAGE");
        System.out.println("message = " + message);

    }

}
