package pl.devcrowd.virtual.business.chickens.boundary;

import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import pl.devcrowd.virtual.business.chickens.control.ChickenStore;
import pl.devcrowd.virtual.business.chickens.entity.Chicken;

/**
 *
 * @author airhacks.com
 */
@Stateless
public class ChickenService {

    @Inject
    ChickenStore store;

    public List<Chicken> getAllChickens() {
        return this.store.all();
    }

    public void save(Chicken chicken) {
        this.store.save(chicken);
    }
}
