package pl.devcrowd.virtual.business.chickens.boundary;

import java.util.List;
import javax.inject.Inject;
import javax.json.JsonObject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import pl.devcrowd.virtual.business.chickens.entity.Chicken;

/**
 *
 * @author airhacks.com
 */
@Path("chickens")
public class ChickensResource {

    @Inject
    ChickenService cs;

    @GET
    public List<Chicken> chickens() {
        return cs.getAllChickens();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public void save(JsonObject chicken) {
        String name = chicken.getString("name");
        int age = chicken.getInt("age");
        cs.save(new Chicken(name, age));
    }

    @POST
    @Consumes(MediaType.APPLICATION_XML)
    public void save(Chicken chicken) {
        System.out.println("Typesafe chicken: " + chicken);
    }

}
