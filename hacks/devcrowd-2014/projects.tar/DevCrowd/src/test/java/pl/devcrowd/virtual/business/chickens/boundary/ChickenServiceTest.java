package pl.devcrowd.virtual.business.chickens.boundary;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verify;
import org.mockito.runners.MockitoJUnitRunner;
import pl.devcrowd.virtual.business.chickens.control.ChickenStore;
import pl.devcrowd.virtual.business.chickens.entity.Chicken;

/**
 *
 * @author airhacks.com
 */
@RunWith(MockitoJUnitRunner.class)
public class ChickenServiceTest {

    @InjectMocks
    ChickenService cs;

    @Mock
    ChickenStore store;

    @Test
    public void save() {
        final Chicken chicken = new Chicken();
        this.cs.save(chicken);
        verify(this.store, times(1)).save(chicken);
    }

}
