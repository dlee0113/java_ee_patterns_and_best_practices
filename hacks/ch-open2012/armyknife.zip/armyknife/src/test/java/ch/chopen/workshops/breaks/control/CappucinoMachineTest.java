/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.chopen.workshops.breaks.control;

import ch.chopen.workshops.breaks.entity.Coffee;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import static org.mockito.Mockito.*;

/**
 *
 * @author adam-bien.com
 */
public class CappucinoMachineTest {
    
    CappucinoMachine cut;
    
    @Before
    public void init(){
        cut = mock(CappucinoMachine.class);
    
    }
    
    @Test
    public void mockActuallWorks() {
        when(cut.prepare(21)).thenReturn(new Coffee("from test", 2));
        Coffee coffeee = cut.prepare(21);
    }
}
