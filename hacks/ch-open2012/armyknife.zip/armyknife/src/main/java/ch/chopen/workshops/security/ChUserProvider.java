/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.chopen.workshops.security;

import ch.chopen.workshops.security.entity.ChUser;
import java.security.Principal;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class ChUserProvider {
    
    @Inject
    Principal principal;
    
    @Produces
    public ChUser exposes(){
        return new ChUser(principal.getName(), "my permissions");
    }
    
}
