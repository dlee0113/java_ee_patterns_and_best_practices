/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.chopen.workshops.configuration.entity;


/**
 *
 * @author adam-bien.com
 */
public enum Stage {
    DEVELOPMENT, PRODUCTION;
}
