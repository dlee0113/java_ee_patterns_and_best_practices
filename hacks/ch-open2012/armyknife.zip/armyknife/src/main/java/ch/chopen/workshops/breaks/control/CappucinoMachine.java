package ch.chopen.workshops.breaks.control;

import ch.chopen.workshops.breaks.entity.Coffee;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Instance;
import javax.enterprise.inject.Stereotype;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class CappucinoMachine {
    
    @Inject
    Steam steam;
    
    @Inject
    Instance<MilkProvider> mp;
    
    @Inject
    String message;
    
    @Inject
    Event<Coffee> event;
    
    @Inject @European
    PowerOutlet po;
    
    
    @Asynchronous
    public Future<Coffee> prepare(){
        for (MilkProvider milkProvider : mp) {
            System.out.println("Found: " + milkProvider);
        }
        steam.generate();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(CappucinoMachine.class.getName()).log(Level.SEVERE, null, ex);
        }
        Coffee coffee = new Coffee(message, 21);
        event.fire(coffee);
        po.on();
        return new AsyncResult<Coffee>(coffee);
    }

    
    public Coffee prepare(int caffeine){
        if(caffeine < 42)
            throw new IllegalArgumentException("Too weak for a developer!");
        return new Coffee("capppucino", 21);
    }
}
