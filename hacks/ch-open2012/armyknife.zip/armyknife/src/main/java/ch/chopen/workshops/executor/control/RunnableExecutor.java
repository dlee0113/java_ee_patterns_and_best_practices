/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.chopen.workshops.executor.control;

import ch.chopen.workshops.executor.PerformanceMonitor;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.interceptor.InterceptorBinding;
import javax.interceptor.Interceptors;

/**
 *
 * @author adam-bien.com
 */
@Interceptors(PerformanceMonitor.class)
@Stateless
public class RunnableExecutor {

    @Asynchronous
    public void execute(Runnable r){
        r.run();
    }
}
