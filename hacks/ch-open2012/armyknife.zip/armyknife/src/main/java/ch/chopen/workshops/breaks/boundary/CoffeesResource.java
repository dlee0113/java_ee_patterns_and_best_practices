package ch.chopen.workshops.breaks.boundary;

import ch.chopen.workshops.breaks.control.CappucinoMachine;
import ch.chopen.workshops.breaks.entity.Coffee;
import ch.chopen.workshops.executor.control.RunnableExecutor;
import ch.chopen.workshops.security.entity.ChUser;
import com.sun.org.apache.bcel.internal.generic.AALOAD;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;


@Path("coffees")
@Stateless
@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML,"binary/coffee"})
public class CoffeesResource {
    
    @Inject
    CappucinoMachine cm;
    
    @Inject
    RunnableExecutor executor;
    
    @Inject
    Instance<ChUser> chUser;

    @GET
    public List<Coffee> coffees(@Context HttpHeaders header){
        System.out.println("Principal: " + chUser.get());
        List<Future<Coffee>> coffees = new ArrayList<Future<Coffee>>();
        List<Coffee> result = new ArrayList<Coffee>();
        for(int i=0;i<10;i++){
            coffees.add(cm.prepare());
        }
        for (Future<Coffee> future : coffees) {
            try {
                result.add(future.get());
            } catch (Exception e){
                System.out.println("-- " +e);
            }
        }
        this.executor.execute(new Runnable() {

            @Override
            public void run() {
                System.out.println("Something slow ");
            }
        });
        return result;
    }
}
