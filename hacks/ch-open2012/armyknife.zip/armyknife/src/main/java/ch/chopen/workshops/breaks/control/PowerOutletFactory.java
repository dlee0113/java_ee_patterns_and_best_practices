/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.chopen.workshops.breaks.control;

import javax.enterprise.inject.Produces;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class PowerOutletFactory {
  
    
    @Produces @European
    public PowerOutlet outlet(PowerOutlet outlet){
        outlet.setVoltage(220);
        outlet.prepare();
        return outlet;
    }
}
