package ch.chopen.workshops.configuration.boundary;

import ch.chopen.workshops.configuration.entity.Stage;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam-bien.com
 */
public class Configurator {

    
    @Produces
    public String getString(InjectionPoint ip,Stage stage){
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String name = ip.getMember().getName();
        return "rapperswil coffee " + clazz.getName() + "."+ name + stage;
    }
}
