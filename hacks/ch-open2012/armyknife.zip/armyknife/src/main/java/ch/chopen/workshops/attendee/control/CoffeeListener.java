package ch.chopen.workshops.attendee.control;

import ch.chopen.workshops.breaks.entity.Coffee;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author adam-bien.com
 */
public class CoffeeListener {

    public void onCupCoffee(@Observes(during= TransactionPhase.AFTER_SUCCESS) Coffee coffee){
        System.out.println("Drinking my coffee: " + coffee);
    }
}
