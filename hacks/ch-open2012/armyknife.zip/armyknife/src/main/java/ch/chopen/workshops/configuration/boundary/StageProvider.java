/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.chopen.workshops.configuration.boundary;

import ch.chopen.workshops.configuration.entity.Stage;
import javax.enterprise.inject.Produces;

/**
 *
 * @author adam-bien.com
 */
public class StageProvider {
    
    @Produces
    public Stage stage(){
        return Stage.DEVELOPMENT;
    }
}
