/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.chopen.workshops.breaks.control;

import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class PowerOutlet {
    
    private int voltage;

    public int getVoltage() {
        return voltage;
    }

    public void setVoltage(int voltage) {
        this.voltage = voltage;
    }


    
    public void prepare(){
        this.voltage++;
    }
    
    
    public void on(){
        System.out.println("Is on: " + this.voltage);
    }
    
}
