package ch.chopen.workshops.breaks.control;

/**
 *
 * @author adam-bien.com
 */
public interface MilkProvider {
    
    public String getMilk();
}
