/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.chopen.workshops.breaks.control;

import javax.enterprise.inject.Specializes;

/**
 *
 * @author adam-bien.com
 */
@Specializes
public class HighPressureSteamer extends Steam{

    @Override
    public void generate() {
        System.out.println("High pressure steam!");
    }
    
    
    
}
