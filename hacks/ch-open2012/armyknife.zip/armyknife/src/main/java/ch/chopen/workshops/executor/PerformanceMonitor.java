package ch.chopen.workshops.executor;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam-bien.com
 */
public class PerformanceMonitor {

    @AroundInvoke
    public Object measure(InvocationContext ic) throws Exception{
        long start = System.currentTimeMillis();
        try{
            return ic.proceed();
        }finally{
            System.out.println(" " + ic.getMethod()  + " took " + (System.currentTimeMillis() -start));
        }
    }
}
