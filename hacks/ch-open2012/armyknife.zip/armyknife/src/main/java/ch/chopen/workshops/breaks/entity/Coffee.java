package ch.chopen.workshops.breaks.entity;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Coffee implements Serializable{

    private String brand;
    private int caffeine;

    public Coffee() {
    }

    public Coffee(String brand, int caffeine) {
        this.brand = brand;
        this.caffeine = caffeine;
    }
    
    
}
