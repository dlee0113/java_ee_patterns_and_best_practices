/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.chopen.workshops.breaks.control;

/**
 *
 * @author adam-bien.com
 */
public class LowEndMilkProvider implements MilkProvider{

    @Override
    public String getMilk() {
        return "powder";
    }
    
}
