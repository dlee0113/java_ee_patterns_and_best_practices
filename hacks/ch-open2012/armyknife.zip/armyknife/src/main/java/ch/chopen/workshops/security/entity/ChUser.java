/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.chopen.workshops.security.entity;

/**
 *
 * @author adam-bien.com
 */
public class ChUser {
    private String name;
    private String permissions;

    public ChUser(String name, String permissions) {
        this.name = name;
        this.permissions = permissions;
    }

    @Override
    public String toString() {
        return "ChUser{" + "name=" + name + ", permissions=" + permissions + '}';
    }
    
    
    
}
