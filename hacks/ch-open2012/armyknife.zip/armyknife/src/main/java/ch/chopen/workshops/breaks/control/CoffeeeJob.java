package ch.chopen.workshops.breaks.control;

import java.util.Date;
import java.util.concurrent.TimeUnit;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.AccessTimeout;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Schedule;
import javax.ejb.ScheduleExpression;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class CoffeeeJob {

    @Resource
    TimerService ts;
    private Timer timer;
    
    @PostConstruct
    public void initialize(){
        ScheduleExpression se = new ScheduleExpression();
        se.hour("*").minute("*").second("*/5");
        this.timer = ts.createCalendarTimer(se);
    }
    
    @Timeout
    public void makeCoffee(){
        System.out.println("Making new coffeee: " + new Date());
        throw new IllegalArgumentException("Attendee request");
    }
    
    public void cancel(){
        this.timer.cancel();
    }
}
