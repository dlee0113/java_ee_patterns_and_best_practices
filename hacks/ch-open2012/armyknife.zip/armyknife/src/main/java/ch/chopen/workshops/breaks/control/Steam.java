package ch.chopen.workshops.breaks.control;

/**
 *
 * @author adam-bien.com
 */
public class Steam {

    
    public void generate(){
        System.out.println("Some steam");
    }
    
}
