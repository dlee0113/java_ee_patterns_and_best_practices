/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.infoshare.unworkshop.business.configuration.boundary;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import pl.infoshare.unworkshop.business.transcoding.control.Transcoder;
import static org.mockito.Mockito.*;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

/**
 *
 * @author adam-bien.com
 */
@RunWith(MockitoJUnitRunner.class)
public class MessageServiceTest {

    @InjectMocks
    MessageService cut;
    @Mock
    Transcoder transcoder;

    @Test
    public void transcoder() {
        when(transcoder.encode(anyString())).thenReturn("42");
        System.out.println(transcoder.encode("doesn't matter"));
        verify(transcoder, times(1)).encode(anyString());
    }
}
