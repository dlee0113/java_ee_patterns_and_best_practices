package pl.infoshare.unworkshop.business.configuration.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.faces.application.ProjectStage;

/**
 *
 * @author adam-bien.com
 */
public class Configurator {

    @Produces
    public String getString(InjectionPoint ip, ProjectStage stage) {
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String name = ip.getMember().getName();

        return stage + "-" + clazz.getName() + "." + name;
    }
}
