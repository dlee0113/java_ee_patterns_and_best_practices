/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.infoshare.unworkshop.business.configuration.boundary;

import javax.ejb.Stateless;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import pl.infoshare.unworkshop.business.datastore.MessageAccessor;
import pl.infoshare.unworkshop.business.transcoding.control.Niceness;
import pl.infoshare.unworkshop.business.transcoding.control.Transcoder;

/**
 *
 * @author adam-bien.com
 */
@Interceptors(SomeAspects.class)
@Stateless
public class MessageService {

    @Inject
    Instance<String> message;
    @Inject
    @Niceness(Niceness.Level.LOWER)
    private Transcoder transcoder;
    @Inject
    private MessageAccessor ms;

    public String getMessage() {
        String encoded = transcoder.encode(message.get());
        if (encoded.endsWith(".pl")) {
            throw new IllegalStateException("Too nice exception");
        }
        return encoded + ms.getData();
    }
}
