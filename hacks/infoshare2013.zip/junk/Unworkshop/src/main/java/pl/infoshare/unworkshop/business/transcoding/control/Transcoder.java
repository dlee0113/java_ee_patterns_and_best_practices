package pl.infoshare.unworkshop.business.transcoding.control;

/**
 *
 * @author adam-bien.com
 */
public interface Transcoder {

    String encode(String message);
}
