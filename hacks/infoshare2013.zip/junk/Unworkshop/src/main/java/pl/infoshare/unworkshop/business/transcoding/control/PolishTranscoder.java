/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.infoshare.unworkshop.business.transcoding.control;

/**
 *
 * @author adam-bien.com
 */
@Niceness(Niceness.Level.HIGH)
public class PolishTranscoder implements Transcoder {

    @Override
    public String encode(String message) {
        return message + ".pl";
    }
}
