package pl.infoshare.unworkshop.business.datastore;

/**
 *
 * @author adam-bien.com
 */
@Relational
public class SQLAccessor implements MessageAccessor {

    @Override
    public String getData() {
        return "Sql";
    }
}
