/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.infoshare.unworkshop.business.datastore;

/**
 *
 * @author adam-bien.com
 */
public interface MessageAccessor {

    public String getData();
}
