package pl.infoshare.unworkshop.business.configuration.boundary;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam-bien.com
 */
public class SomeAspects {

    @AroundInvoke
    public Object decorate(InvocationContext ic) throws Exception {
        System.out.println(" " + ic.getMethod());
        return ic.proceed();
    }
}
