package pl.infoshare.unworkshop.presentation.configuration;

import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.faces.application.ProjectStage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import pl.infoshare.unworkshop.business.configuration.boundary.MessageService;

/**
 *
 * @author adam-bien.com
 */
@Model
public class Index {

    @Inject
    MessageService ms;

    public String getMessage() {
        return ms.getMessage();
    }

    @Produces
    public ProjectStage stage() {
        return FacesContext.getCurrentInstance().getApplication().getProjectStage();
    }
}
