package ch.open.waslos.business.user.boundary;

import javax.json.JsonObject;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author airhacks.com
 */
public class UsersResourceIT {

    private WebTarget tut;

    @Before
    public void init() {
        Client client = ClientBuilder.newClient();
        this.tut = client.target("http://localhost:8080/waslos/resources/users/");
    }

    @Test
    public void status() {

        Response response = this.tut.path("42").request().accept(MediaType.APPLICATION_JSON).get();
        assertThat(response.getStatus(), is(200));

    }

    @Test
    public void fetchUser() {
        JsonObject response = this.tut.path("42").request().accept(MediaType.APPLICATION_JSON).get(JsonObject.class);
        assertThat(response.getJsonNumber("id").longValue(), is(42l));
    }

}
