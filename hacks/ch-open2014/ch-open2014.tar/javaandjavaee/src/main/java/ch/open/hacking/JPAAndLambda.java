package ch.open.hacking;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author airhacks.com
 */
public class JPAAndLambda {

    public static void main(String[] args) {
        List<User> users = new ArrayList<>();
        users.add(new User(20, "duke"));
        users.add(new User(18, "duchess"));

        List<String> names = users.parallelStream().
                filter((t) -> t.getAge() < 20).
                map((t) -> t.getName()).
                collect(Collectors.toList());
        System.out.println("count = " + names);

        double average = users.stream().
                mapToLong(t -> t.getAge()).
                average().
                orElse(0);
        System.out.println("average = " + average);
    }
}
