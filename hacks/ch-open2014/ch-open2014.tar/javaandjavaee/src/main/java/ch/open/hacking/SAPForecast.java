package ch.open.hacking;

import javax.ejb.Stateless;

/**
 *
 * @author airhacks.com
 */
@Stateless
public class SAPForecast {

    public String weather() {
        return "cloudy";
    }

}
