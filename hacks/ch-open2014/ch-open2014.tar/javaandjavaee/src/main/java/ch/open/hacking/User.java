package ch.open.hacking;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author airhacks.com
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Table(name = "AA_USER")
@Entity
public class User {

    private long age;
    private String name;

    public User() {
    }

    public User(long age, String name) {
        this.age = age;
        this.name = name;
    }

    public long getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

}
