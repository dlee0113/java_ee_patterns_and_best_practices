package ch.open.hacking;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Supplier;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.enterprise.event.Observes;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
@Stateless
public class Forecaster {

    @Inject
    SAPForecast forecast;

    @Resource
    ManagedExecutorService mes;

    public void onForecastRequest(@Observes Consumer<Object> client) {
        Supplier<String> forecastProvider = forecast::weather;
        CompletableFuture.supplyAsync(forecastProvider, mes).thenAccept(client);

    }

}
