package ch.open.waslos.business.user.boundary;

import ch.open.waslos.business.user.entity.User;
import java.util.function.Consumer;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class UserManager {

    @PersistenceContext
    EntityManager em;

    @Inject
    Consumer<String> LOG;

    public User get(long id) {
        LOG.accept("User found: " + id);
        return this.em.find(User.class, id);
    }

    public User save(User user) {
        return this.em.merge(user);
    }

}
