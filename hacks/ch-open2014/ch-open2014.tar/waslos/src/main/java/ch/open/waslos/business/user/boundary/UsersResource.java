package ch.open.waslos.business.user.boundary;

import ch.open.waslos.business.user.entity.User;
import java.net.URI;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.json.JsonObject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

/**
 *
 * @author airhacks.com
 */
@Stateless
@Path("users")
public class UsersResource {

    @Inject
    UserManager um;

    @GET
    @Path("{id}")
    public User user(@PathParam("id") long id) {
        return um.get(id);
    }

    @POST
    public Response save(JsonObject json, @Context UriInfo info) {
        User user = fromJson(json);
        User created = this.um.save(user);
        URI uri = info.getAbsolutePathBuilder().path("/" + created.getId()).build();
        return Response.created(uri).build();
    }

    public User fromJson(JsonObject json) {
        return new User(json.getString("name"));
    }

}
