package ch.open.waslos.business.logging.boundary;

import java.util.function.Consumer;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author airhacks.com
 */
public class LogExposer {

    @Produces
    public Consumer<String> exposes(InjectionPoint ip) {
        String name = ip.getMember().getDeclaringClass().getName();
        return System.out::println;
    }
}
