package org.oneday.business.goodmorning.boundary;

import javax.ejb.Stateless;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import org.oneday.business.goodmorning.control.Greeter;
import org.oneday.business.goodmorning.control.ReusableGreeter;
import org.oneday.business.goodmorning.entity.OneDayHello;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class OneDay {
    
    @Inject @Any
    Instance<Greeter> greeters;
    
    public OneDayHello hello(){
        String foundGreeters = "------";
        for (Greeter greeter : greeters) {
            foundGreeters += greeter.toString();
        }
        return new OneDayHello(foundGreeters);
    }
}
