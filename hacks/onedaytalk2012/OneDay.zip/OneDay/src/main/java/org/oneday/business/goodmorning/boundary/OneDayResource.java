package org.oneday.business.goodmorning.boundary;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author adam-bien.com
 */

@Path("greetings")
@Stateless
public class OneDayResource {
    
    @Inject
    OneDay day;
    
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public Response hello(@Context HttpHeaders headers){
        return Response.ok().entity(day.hello()).build();
    }
    
}
