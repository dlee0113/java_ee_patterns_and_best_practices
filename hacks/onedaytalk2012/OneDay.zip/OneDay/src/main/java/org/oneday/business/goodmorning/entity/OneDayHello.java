package org.oneday.business.goodmorning.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class OneDayHello {

    private String message;

    public OneDayHello() {
    }

    public OneDayHello(String message) {
        this.message = message;
    }
    
    
    
    
}
