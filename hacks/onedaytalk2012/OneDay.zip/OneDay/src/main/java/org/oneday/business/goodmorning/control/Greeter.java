/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.oneday.business.goodmorning.control;

import org.oneday.business.goodmorning.entity.OneDayHello;

/**
 *
 * @author adam-bien.com
 */
public interface Greeter {
    OneDayHello overengineered();
}
