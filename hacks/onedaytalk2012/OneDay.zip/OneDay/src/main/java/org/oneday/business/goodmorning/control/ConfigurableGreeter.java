/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.oneday.business.goodmorning.control;

import javax.enterprise.inject.Specializes;
import org.oneday.business.goodmorning.entity.OneDayHello;

/**
 *
 * @author adam-bien.com
 */
public class ConfigurableGreeter implements Greeter{

    @Override
    public OneDayHello overengineered() {
        return new OneDayHello("configurable");
    }

    
    
}
