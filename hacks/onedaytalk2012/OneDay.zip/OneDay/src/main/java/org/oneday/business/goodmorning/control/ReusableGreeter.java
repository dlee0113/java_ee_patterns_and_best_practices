package org.oneday.business.goodmorning.control;

import org.oneday.business.goodmorning.entity.OneDayHello;

/**
 *
 * @author adam-bien.com
 */
public class ReusableGreeter implements Greeter{

    public OneDayHello overengineered(){
        return new OneDayHello(" usually not exists!");
    }
}
