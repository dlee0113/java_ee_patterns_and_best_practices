/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jughh.scheduling;

import java.util.Date;

/**
 *
 * @author adam-bien.com
 */
public interface IWatch {
      public Date current();
}
