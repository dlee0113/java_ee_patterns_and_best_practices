package de.jughh.scheduling;

import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author adam-bien.com
 */
@Stateless
@Path("sessions")
@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
public class SessionsResource {
    
    @GET
    public Session hey(){
        return new Session("james", "duke rocks");
    }
    
    @GET
    @Path("{id}-{lang}")
    public Session getSpecifi(@PathParam("id") long id, @PathParam("lang") String language){
        return new Session("james" +id, language);
    }
}
