package de.jughh.scheduling;

import javax.ejb.Stateless;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.Interceptors;

@Stateless
@Interceptors(LoggingAspect.class)
public class XtremeComplexity {
    
    @Inject
    Instance<IWatch> service;
    
    @Inject
    BeerFactory bf;
    
    public String enterpriseHello(){
        for (IWatch iWatch : service) {
            System.out.println("--- " + iWatch);
        }
        
        return " Hey joed: " + System.currentTimeMillis() + " " + bf.drink();
    }
}
