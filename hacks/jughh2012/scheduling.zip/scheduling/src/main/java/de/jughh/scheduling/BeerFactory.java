package de.jughh.scheduling;

import javax.enterprise.inject.Default;

/**
 *
 * @author adam-bien.com
 */
public class BeerFactory {

    public String drink(){
        return "alc free";
    }
}
