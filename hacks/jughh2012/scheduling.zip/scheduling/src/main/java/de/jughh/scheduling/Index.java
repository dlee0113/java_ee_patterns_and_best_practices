package de.jughh.scheduling;

import javax.enterprise.inject.Model;
import javax.inject.Inject;

@Model
public class Index {

    @Inject
    XtremeComplexity complexity;
    
    public String getMessage(){
        return "JUGHH rocks " + complexity.enterpriseHello();
    }
}

