/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jughh.scheduling;

import javax.enterprise.inject.Specializes;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Specializes
public class OOSEBeerFactory extends BeerFactory{

    @Inject
    private String message;
    
    @Override
    public String drink() {
        return super.drink() + message;
    }
    
}
