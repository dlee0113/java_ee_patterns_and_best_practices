package de.jughh.scheduling;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam-bien.com
 */
public class Configurable {
    
    /**
     * A getter
     * @param ip
     * @return a String
     */
    @Produces
    public String getString(InjectionPoint ip){
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String className = clazz.getName();
        String name = ip.getMember().getName();
        return "good night! "  + className + "."+name;
    }
}
