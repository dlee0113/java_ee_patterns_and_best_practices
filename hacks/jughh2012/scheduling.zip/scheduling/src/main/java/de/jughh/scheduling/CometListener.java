package de.jughh.scheduling;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.Asynchronous;
import javax.enterprise.event.Observes;
import javax.servlet.AsyncContext;

/**
 *
 * @author adam-bien.com
 */
public class CometListener {

    public void onRequest(@Observes AsyncContext ac) {
        try {
            PrintWriter writer = ac.getResponse().getWriter();
            writer.println("Hot stuff");
            ac.complete();
        } catch (IOException iOException) {
        }
    }
    
}
