package de.jughh.scheduling;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam-bien.com
 */
public class LoggingAspect {

    @AroundInvoke
    public Object log(InvocationContext ic) throws Exception{
        System.out.println("Method: " + ic.getMethod());
        return ic.proceed();
    }
}
