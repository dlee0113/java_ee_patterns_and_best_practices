package de.jughh.scheduling;

import java.util.Date;

/**
 *
 * @author adam-bien.com
 */
public class AtomWatch implements IWatch{

    @Override
    public Date current() {
        return new Date();
    }
    
}
