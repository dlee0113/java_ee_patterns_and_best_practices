/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.jughh.scheduling;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Session {
    
    private String speaker;
    private String title;

    public Session(String speaker, String title) {
        this.speaker = speaker;
        this.title = title;
    }

    public Session() {
    }
    
    
}
