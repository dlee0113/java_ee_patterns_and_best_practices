package de.jughh.scheduling;

import java.util.Date;

/**
 *
 * @author adam-bien.com
 */
public class WatchService implements IWatch{
    
    public Date current(){
        return new Date();
    }
}
