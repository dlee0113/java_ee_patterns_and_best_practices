package de.summit.workshops.business.registration.boundary;

import de.summit.workshops.business.registration.entity.Attendee;
import java.net.URI;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

/**
 *
 * @author adam-bien.com
 */
@Stateless
@Path("registrations")
public class RegistrationsResource {

    @Inject
    RegistrationService rs;

    @Context
    UriInfo info;

    @GET
    public JsonArray registrations() {
        JsonObject attendee = Json.createObjectBuilder().add("name", "hugo").build();
        return Json.createArrayBuilder().add(attendee).build();
    }

    @GET
    @Path("{id}")
    public Attendee registration(@PathParam("id") String id, @Context HttpHeaders headers) {
        return new Attendee(id + headers.toString(), 21);
    }

    @POST
    public Response register(Attendee attendee) {
        System.out.println("Created! " + attendee);
        UriBuilder path = this.info.getAbsolutePathBuilder().path("/" + System.currentTimeMillis());
        URI uri = URI.create(path.toTemplate());
        System.out.println("Result: " + rs.register(attendee));
        return Response.created(uri).build();
    }
}
