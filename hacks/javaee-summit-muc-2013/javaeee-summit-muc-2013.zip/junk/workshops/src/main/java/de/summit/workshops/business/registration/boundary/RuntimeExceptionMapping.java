package de.summit.workshops.business.registration.boundary;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

/**
 *
 * @author adam-bien.com
 */
//@Provider
public class RuntimeExceptionMapping implements ExceptionMapper<RuntimeException> {

    @Override
    public Response toResponse(RuntimeException exception) {
        return Response.status(4242).header("X-exception-detail", exception.getMessage()).build();
    }
}
