package de.summit.workshops.business.registration.control;

import de.summit.workshops.business.registration.entity.Attendee;

/**
 *
 * @author adam-bien.com
 */
public interface ASNValidator {

    public boolean check(Attendee attendee);
}
