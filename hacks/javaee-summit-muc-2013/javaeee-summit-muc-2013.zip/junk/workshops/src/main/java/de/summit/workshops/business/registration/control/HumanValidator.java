package de.summit.workshops.business.registration.control;

import de.summit.workshops.business.registration.entity.Attendee;

/**
 *
 * @author adam-bien.com
 */
public class HumanValidator implements ASNValidator {

    @Override
    public boolean check(Attendee attendee) {
        System.out.println("HumanValidator " + attendee);
        return false;
    }
}
