package de.summit.workshops.business.progress;

import java.util.concurrent.TimeUnit;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;
import javax.ws.rs.container.TimeoutHandler;
import javax.ws.rs.core.Response;

/**
 *
 * @author adam-bien.com
 */
@Path("validations")
public class AttendeeValidationProgress {

    @GET
    @Path("{id}")
    public void validation(@Suspended AsyncResponse response, @PathParam("id") String id) {
        response.resume("Hey joe is registered " + id);
        response.setTimeout(2, TimeUnit.SECONDS);
        response.setTimeoutHandler(new TimeoutHandler() {

            @Override
            public void handleTimeout(AsyncResponse asyncResponse) {
                Response response = Response.status(204).build();
                asyncResponse.resume(response);
            }
        });
    }
}
