package de.summit.workshops.business.registration.boundary;

import java.util.Date;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.ScheduleExpression;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
public class TemporaryFileCleanup {

    @Resource
    TimerService ts;
    private Timer timer;

    @PostConstruct
    public void onInit() {
        ScheduleExpression se = new ScheduleExpression();
        se.second("*/2").minute("*").hour("*");
        this.timer = ts.createCalendarTimer(se);
    }

    @Timeout
    public void cleanup() {
        System.out.println("Works: " + new Date());

    }
}
