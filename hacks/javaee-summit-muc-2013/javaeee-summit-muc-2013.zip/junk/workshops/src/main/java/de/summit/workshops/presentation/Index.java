package de.summit.workshops.presentation;

import de.summit.workshops.business.registration.boundary.RegistrationService;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Model
public class Index {

    @Inject
    RegistrationService rs;

    public String getRegistrations() {
        return rs.getRegistrations();
    }
}
