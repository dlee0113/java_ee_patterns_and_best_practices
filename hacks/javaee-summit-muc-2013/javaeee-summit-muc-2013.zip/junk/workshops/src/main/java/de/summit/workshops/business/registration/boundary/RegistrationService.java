package de.summit.workshops.business.registration.boundary;

import de.summit.workshops.business.registration.entity.Attendee;
import de.summit.workshops.business.registration.entity.HumanAttendee;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.jms.JMSContext;
import javax.jms.JMSDestinationDefinition;
import javax.jms.Queue;

/**
 *
 * @author adam-bien.com
 */
@JMSDestinationDefinition(name = "java:global/jms/workshop", interfaceName = "javax.jms.Queue")
@Stateless
public class RegistrationService {

    @Resource
    ManagedExecutorService mes;

    @Inject
    Event<Attendee> events;

    @Resource
    SessionContext sc;

    @Resource
    JMSContext context;

    @Resource(name = "java:global/jms/workshop")
    Queue queue;

    public String getRegistrations() {
        context.createProducer().send(queue, "hey joe");
        return "duke,hugo";
    }

    public String register(@HumanAttendee Attendee attendee) {
        events.fire(attendee);
        sc.setRollbackOnly();
        try {
            System.out.println("Registered: " + attendee);
            Callable<String> check = new Callable<String>() {

                @Override
                public String call() throws Exception {
                    return "works";
                }
            };
            Future<String> submit = mes.submit(check);
            return submit.get();
        } catch (InterruptedException | ExecutionException ex) {
            throw new IllegalStateException("Something wrong: " + ex, ex);
        }
    }
}
