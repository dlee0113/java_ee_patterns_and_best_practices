package de.summit.workshops.business.progress;

import java.io.IOException;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Singleton;
import javax.enterprise.event.Observes;
import javax.servlet.AsyncContext;

/**
 *
 * @author adam-bien.com
 */
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class ClientListener {

    private CopyOnWriteArrayList<AsyncContext> listeners;

    @PostConstruct
    public void onInit() {
        this.listeners = new CopyOnWriteArrayList<>();
    }

    public void onNewWindow(@Observes AsyncContext ac) {
        this.listeners.add(ac);
        try {
            ac.getResponse().getWriter().print("Seems to work: " + System.currentTimeMillis());
        } catch (IOException ex) {
            Logger.getLogger(ClientListener.class.getName()).log(Level.SEVERE, null, ex);
        }
        ac.complete();
    }
}
