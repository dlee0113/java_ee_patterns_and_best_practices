package de.summit.workshops.business.registration.control;

import de.summit.workshops.business.registration.entity.Attendee;
import javax.ejb.Singleton;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author adam-bien.com
 */
@Singleton
public class RegistrationListener {

    public void onRegistration(@Observes(during = TransactionPhase.AFTER_SUCCESS) Attendee attendee) {
        System.out.println("Registered: " + attendee);
    }

    public void onFailedRegistration(@Observes(during = TransactionPhase.AFTER_FAILURE) Attendee attendee) {
        System.out.println("Problem: " + attendee);
    }
}
