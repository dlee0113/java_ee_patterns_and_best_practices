package de.summit.workshops.business.registration.entity;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 *
 * @author adam-bien.com
 */
public class HumanAttendeeValidator implements ConstraintValidator<HumanAttendee, Attendee> {

    private HumanAttendee annotation;

    public void initialize(HumanAttendee annotation) {
        this.annotation = annotation;
    }

    @Override
    public boolean isValid(Attendee value, ConstraintValidatorContext context) {
        return value.isValid();
    }
}
