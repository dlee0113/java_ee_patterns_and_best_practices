package de.summit.wild.configuration;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam-bien.com
 */
public class Configurator {

    @Produces
    public String getConfiguration(InjectionPoint ip) {
        String classNme = ip.getMember().getDeclaringClass().getName();
        String name = ip.getMember().getName();
        return "hey configured duke  " + classNme + "." + name;
    }
}
