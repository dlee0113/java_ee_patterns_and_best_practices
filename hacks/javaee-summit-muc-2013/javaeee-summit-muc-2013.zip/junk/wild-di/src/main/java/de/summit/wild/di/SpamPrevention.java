package de.summit.wild.di;

import javax.enterprise.inject.Alternative;

/**
 *
 * @author adam-bien.com
 */
@Alternative
public class SpamPrevention implements AttendeeValidator {

    @Override
    public boolean validate(String name) {
        System.out.println("Spam !!!!!!");
        return true;
    }
}
