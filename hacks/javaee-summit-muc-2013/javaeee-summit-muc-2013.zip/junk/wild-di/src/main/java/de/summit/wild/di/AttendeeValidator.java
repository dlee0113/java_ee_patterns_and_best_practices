package de.summit.wild.di;

/**
 *
 * @author adam-bien.com
 */
public interface AttendeeValidator {

    boolean validate(String name);
}
