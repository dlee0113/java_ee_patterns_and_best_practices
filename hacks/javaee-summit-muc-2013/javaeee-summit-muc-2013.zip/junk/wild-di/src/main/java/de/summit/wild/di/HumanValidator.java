package de.summit.wild.di;

/**
 *
 * @author adam-bien.com
 */
public class HumanValidator implements AttendeeValidator {

    @Override
    public boolean validate(String name) {
        System.out.println("Attendee validator " + name);
        return false;
    }
}
