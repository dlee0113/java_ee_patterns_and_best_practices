package de.summit.wild.di;

import javax.enterprise.inject.Instance;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Model
public class Index {

    @Inject
    Instance<AttendeeValidator> validator;

    @Inject
    String name;

    @Inject
    String lastName;

    public String getMessage() {
        String retVal = "";
        for (AttendeeValidator attendeeValidator : validator) {
            retVal += attendeeValidator.validate("hey " + name + " " + lastName);
        }
        return retVal;
    }
}
