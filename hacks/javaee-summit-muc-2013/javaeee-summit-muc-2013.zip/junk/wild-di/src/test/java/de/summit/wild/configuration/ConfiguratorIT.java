package de.summit.wild.configuration;

import javax.inject.Inject;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 *
 * @author adam-bien.com
 */
@RunWith(Arquillian.class)
public class ConfiguratorIT {

    @Inject
    String name;

    @Deployment
    public static JavaArchive create() {
        return ShrinkWrap.create(JavaArchive.class).
                addClasses(Configurator.class).addAsManifestResource(EmptyAsset.INSTANCE, "beans.xml");
    }

    @Test
    public void injectString() {
        System.out.println("Name: " + name);
        Assert.assertNotNull(name);
    }

}
