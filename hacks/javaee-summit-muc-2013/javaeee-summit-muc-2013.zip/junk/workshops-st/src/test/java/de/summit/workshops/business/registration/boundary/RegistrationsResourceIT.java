package de.summit.workshops.business.registration.boundary;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import static org.hamcrest.CoreMatchers.is;
import org.junit.Assert;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author adam-bien.com
 */
public class RegistrationsResourceIT {

    private Client client;
    private WebTarget registrations;

    @Before
    public void initializeClient() {
        this.client = ClientBuilder.newClient();
        this.registrations = this.client.target("http://localhost:8080/workshops/v1/registrations/");
    }

    @Test
    public void registrations() {
        Response response = this.registrations.request().get();
        int status = response.getStatus();
        assertThat(status, is(200));
        String asString = response.readEntity(String.class);
        Assert.assertNotNull(asString);
    }
}
