/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.rheinjug.presentation.engine.boundary;

import de.rheinjug.business.engine.boundary.Engine;
import javax.inject.Inject;
import org.junit.AfterClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import static org.mockito.Mockito.*;
import static org.hamcrest.CoreMatchers.*;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class IndexTest {
    
    Index cut;
    
    @Before
    public void inject(){
        this.cut = new Index();
        this.cut.engine= mock(Engine.class);
    }

    @Test
    public void winner() {
        when(this.cut.engine.winner()).thenReturn("rheiny");
        String winner = this.cut.winner();
        assertThat(winner,is("rheiny"));
    }
}
