/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.rheinjug.business.generator.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Entrophy(Entrophy.Level.LOW)
public class MillisGenerator implements Numbers{

    @Override
    public long getRand() {
        return 2;
    }
    
}
