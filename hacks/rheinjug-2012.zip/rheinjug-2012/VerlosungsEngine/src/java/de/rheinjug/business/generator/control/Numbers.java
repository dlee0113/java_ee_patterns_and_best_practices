/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.rheinjug.business.generator.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
public interface Numbers {
    
    long getRand();
}
