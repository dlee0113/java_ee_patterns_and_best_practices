package de.rheinjug.presentation.engine.boundary;

import de.rheinjug.business.engine.boundary.Engine;
import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

@Model
public class Index {
    
    @Inject
    Engine engine;
    
    @PostConstruct
    public void init(){
        System.out.println("Index");
    }

    public String winner(){
        return engine.winner();
    }
    
}
