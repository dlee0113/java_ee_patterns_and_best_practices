/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.rheinjug.business.engine.boundary;

import de.rheinjug.business.generator.control.Entrophy;
import java.lang.annotation.Annotation;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class EnthropySelector implements Entrophy{

    private Level level;

    public EnthropySelector(Level level) {
        this.level = level;
    }
    
    
    
    @Override
    public Level value() {
       return this.level;
    }

    @Override
    public Class<? extends Annotation> annotationType() {
        return Entrophy.class;
    }
    
}
