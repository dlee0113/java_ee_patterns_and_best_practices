/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.rheinjug.business.engine.control;

import java.util.Date;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Stateless;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Startup
@Singleton
public class StorageEngine {
    
    @Asynchronous
    public Future<String> store(){
        System.out.println("stored!");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(StorageEngine.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new AsyncResult<String>("id");
    }
    
    @Schedule(minute="*",hour="*",second="*/2",persistent=true)
    public void flushCache(){
        System.out.println("------- " + new Date());
    
    }
}
