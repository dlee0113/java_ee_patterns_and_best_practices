/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.rheinjug.business.generator.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Entrophy(Entrophy.Level.HIGH)
public class LavaLampGenerator implements Numbers{

    @Override
    public long getRand() {
        return 21;
    }
    
}
