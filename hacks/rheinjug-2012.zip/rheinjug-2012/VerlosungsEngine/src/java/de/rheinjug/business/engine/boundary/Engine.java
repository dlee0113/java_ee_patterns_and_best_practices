package de.rheinjug.business.engine.boundary;

import de.rheinjug.business.engine.control.StorageEngine;
import de.rheinjug.business.generator.control.Entrophy;
import de.rheinjug.business.generator.control.Numbers;
import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.Interceptors;

@Stateless
@Interceptors(JUGHeadQuarter.class)
public class Engine {
    
    @Inject
    Instance<String> message;
    
    @Inject
    int number;
    
    @Inject
    StorageEngine store;
    
   @Inject @Any
   Instance<Numbers> generators;
    
    @PostConstruct
    public void init(){
        System.out.println("Engine");
    }

    
    public String winner(){
        for (Numbers numbers : generators.select(new EnthropySelector(Entrophy.Level.HIGH))) {
            System.out.println("---- " + numbers);
            
        }
        store.store();
        return "works " + message.get();
 
    }
}
