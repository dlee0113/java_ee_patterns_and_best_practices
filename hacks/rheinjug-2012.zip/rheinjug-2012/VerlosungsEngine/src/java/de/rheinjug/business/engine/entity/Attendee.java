package de.rheinjug.business.engine.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam bien, adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Attendee {

    private String name;
    private int rank;

    public Attendee() {
    }

    public Attendee(String name, int rank) {
        this.name = name;
        this.rank = rank;
    }
    
    
}
