package de.rheinjug.business.engine.control;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.inject.Inject;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class Configurator {
    
    @Inject
    DBConfigurationProvider provider;

    @Produces
    public String hugo(InjectionPoint ip){
        final Class clazz = ip.getMember().getDeclaringClass();
        return clazz.getName() + "." + ip.getMember().getName();
    }

    @Produces
    public int number(){
        return 42;
    }
 
}
