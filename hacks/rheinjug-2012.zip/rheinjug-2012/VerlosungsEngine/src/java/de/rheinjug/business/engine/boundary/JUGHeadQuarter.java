package de.rheinjug.business.engine.boundary;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class JUGHeadQuarter {

    @AroundInvoke
    public Object audit(InvocationContext ic) throws Exception {
        System.out.println("--Before");
        try {
            return ic.proceed();
        } finally {
            System.out.println("---after");
        }
    }
}
