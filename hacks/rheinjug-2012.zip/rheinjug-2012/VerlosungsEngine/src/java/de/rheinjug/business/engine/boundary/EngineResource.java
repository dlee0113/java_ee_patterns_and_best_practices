/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.rheinjug.business.engine.boundary;

import de.rheinjug.business.engine.entity.Attendee;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Path("generator")
@Stateless
@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
public class EngineResource {
    
    @Inject
    Engine engine;
    
    @GET
    public Attendee getAttendee(){
        return new Attendee(engine.winner(),42);
    }
    
    @Path("{name}")
    @GET
    public Attendee specific(@PathParam("name") String name){
        return new Attendee(name, 42);
    }
    
    @POST
    public void save(Attendee attendee){
        System.out.println("--- " + attendee);
    }
}
