/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.london.olympics.business.configuration.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
public enum Stage {
    DEVELOPMENT,PRODUCTION;
}
