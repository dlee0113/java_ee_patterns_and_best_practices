/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.london.olympics.business.registration.boundary;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class LoggingAspect {
    
    
    @AroundInvoke
    public Object log(InvocationContext ic) throws Exception{
        System.out.println("ASPECT------- " + ic.getMethod());
        return ic.proceed();
    }
}
