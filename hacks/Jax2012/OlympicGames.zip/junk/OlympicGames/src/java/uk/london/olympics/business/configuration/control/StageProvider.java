/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.london.olympics.business.configuration.control;

import javax.enterprise.inject.Produces;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class StageProvider {
    
    @Produces
    public Stage getStage(){
        return Stage.PRODUCTION;
    }
}
