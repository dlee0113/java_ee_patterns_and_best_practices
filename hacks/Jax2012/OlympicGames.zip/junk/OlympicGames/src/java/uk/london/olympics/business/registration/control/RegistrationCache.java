package uk.london.olympics.business.registration.control;

import java.util.Date;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.*;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import uk.london.olympics.business.configuration.control.Stage;
import uk.london.olympics.business.configuration.control.StageDependent;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Startup
@Singleton
public class RegistrationCache {

    @Inject @StageDependent
    private Instance<Integer> notificationPeriod;

    @Inject
    private Integer global;
    
    @Resource
    TimerService ts;
    
    private Timer timer;
    
    @PostConstruct
    public void onStartup(){
        //ScheduleExpression expression = new ScheduleExpression();
        //expression.hour("*").minute("*").second("*/" + notificationPeriod.get());
        System.out.println("----------Initialized ! " + notificationPeriod.get());
       // this.timer = ts.createCalendarTimer(expression);
    }
    
    @Timeout
    //@Schedule(minute="*",second="*/2",hour="*")
    public void sendNotificationEmails(){
        System.out.println("---- sending: " + new Date());
    }
    
    @PreDestroy
    public void cancelTimer(){
        this.timer.cancel();
    }
}
