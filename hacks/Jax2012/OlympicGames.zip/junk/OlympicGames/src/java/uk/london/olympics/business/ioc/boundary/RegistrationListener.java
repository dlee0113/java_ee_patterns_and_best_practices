/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.london.olympics.business.ioc.boundary;

import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;
import uk.london.olympics.business.registration.entity.Athlete;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class RegistrationListener {

    
    public void onNewRegistrations(@Observes(during= TransactionPhase.AFTER_SUCCESS) Athlete a){
        System.out.println("---GOT---- " + a);
    }
    public void onFailedRegistrations(@Observes(during= TransactionPhase.AFTER_FAILURE) Athlete a){
        System.out.println("---PROBLEM---- " + a);
    }
}
