package uk.london.olympics.business.registration.boundary;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.Asynchronous;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import uk.london.olympics.business.registration.entity.Athlete;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Interceptors(LoggingAspect.class)
@Stateless
public class AthletesRegistration {

    @Inject
    Event<Athlete> registrations;
    
    @Resource
    SessionContext sc;
    
    public String hello(){
        return " Welcome all inj!";
    }

    
    @Asynchronous
    public void register(Athlete athlete) {
        registrations.fire(athlete);
        System.out.println("---- " + athlete);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(AthletesRegistration.class.getName()).log(Level.SEVERE, null, ex);
        }
        sc.setRollbackOnly();
    }
}
