/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.london.olympics.business.configuration.control;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class DBConfigurationProvider implements ConfigurationSource{

    public Map<String, String> configuration() {
        Map<String,String> fromDB = new HashMap<String, String>(){{
            put("hey","joe");
        }};
        return fromDB;
    }
    
}
