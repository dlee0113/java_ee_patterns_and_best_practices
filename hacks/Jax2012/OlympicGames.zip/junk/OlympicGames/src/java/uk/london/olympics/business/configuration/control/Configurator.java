package uk.london.olympics.business.configuration.control;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Instance;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.inject.Inject;

public class Configurator {
    
    @Inject
    Instance<ConfigurationSource> source;
    
    @PostConstruct
    public void initialize(){
        for (ConfigurationSource configurationSource : source) {
            System.out.println("---- " + configurationSource);
        }
    }

    @Produces @StageDependent
    public int getStageDependentInt(InjectionPoint ip,Stage stage){
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String memberName = ip.getMember().getName();
        System.out.println("- "+ stage +"--- " + clazz.getName() + "." +memberName);
        return 5;
    }

    @Produces
    public int getInt(InjectionPoint ip){
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String memberName = ip.getMember().getName();
        System.out.println("---- " + clazz.getName() + "." +memberName);
        return 5;
    }
    
}
