package uk.london.olympics.business.registration.entity;

import javax.validation.constraints.Max;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import uk.london.olympics.business.registration.boundary.Name;

/**
 *
 * @author adam bien, adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Athlete {

    @Name("hugo")
    private String name;
    
    @Max(value=100,message="Sumo is not olympic!")
    private int weight;

    public Athlete() {
    }

    public Athlete(String name, int weight) {
        this.name = name;
        this.weight = weight;
    }
    
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "Athlete{" + "name=" + name + ", weight=" + weight + '}';
    }
    
    
    
    
    
    
}
