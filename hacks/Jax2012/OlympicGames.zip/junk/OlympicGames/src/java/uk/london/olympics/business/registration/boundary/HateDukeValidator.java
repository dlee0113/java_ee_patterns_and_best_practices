package uk.london.olympics.business.registration.boundary;

import java.lang.annotation.Annotation;
import java.util.Set;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Validator;
import javax.validation.metadata.BeanDescriptor;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class HateDukeValidator implements ConstraintValidator<Name, String> {
    private Name annotation;

    @Override
    public void initialize(Name constraintAnnotation) {
        this.annotation = constraintAnnotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return (!annotation.value().equalsIgnoreCase(value));
    }

    
}
