package uk.london.olympics.business.registration.boundary;

import java.awt.PageAttributes;
import java.net.URI;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import uk.london.olympics.business.registration.entity.Athlete;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Path("registrations")
@Stateless
@Produces(MediaType.APPLICATION_XML)
@Consumes(MediaType.APPLICATION_XML)
public class RegistrationsResource {
    
    @GET
    public Response welcome(){
        return Response.ok(new Athlete("chief", 20)).
                header("X-deprecation", "Don't call me tommorrow").
                build();
    }
    
    @GET
    @Path("{id}") 
    public Athlete getRegistration(@PathParam("id") int id){
        return new Athlete("from path", id);
    }
    
    @POST
    public Response save(Athlete athlete){
        System.out.println("---- " + athlete);
        URI create = URI.create("/42");
        return Response.created(create).build();
    }
}
