/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.london.olympics.business.configuration.control;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.Specializes;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class HardcodedConfigurator{

    //@Produces @Specializes
    public int getInt(InjectionPoint ip,Stage stage) {
        return 13;
    }
    
}
