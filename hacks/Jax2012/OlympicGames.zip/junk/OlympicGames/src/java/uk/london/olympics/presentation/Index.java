package uk.london.olympics.presentation;

import java.util.Set;
import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import uk.london.olympics.business.registration.boundary.AthletesRegistration;
import uk.london.olympics.business.registration.entity.Athlete;

@Model
public class Index {
    
    @Inject
    AthletesRegistration ar;
    
    private Athlete athlete;
    
    @Inject
    Validator validator;
    
    @PostConstruct
    public void initialize(){
        athlete = new Athlete();
    }

    public Athlete getAthlete() {
        return athlete;
    }
    

    public Object register(){
        this.ar.register(this.athlete);
        System.out.println("Validator: " + this.validator);
        return null;
    }
    
}
