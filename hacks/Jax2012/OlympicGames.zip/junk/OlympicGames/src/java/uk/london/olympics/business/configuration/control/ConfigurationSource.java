/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.london.olympics.business.configuration.control;

import java.util.Map;

/**
 *
 * @author adam bien, adam-bien.com
 */
public interface ConfigurationSource {
    
    public Map<String,String> configuration();
}
