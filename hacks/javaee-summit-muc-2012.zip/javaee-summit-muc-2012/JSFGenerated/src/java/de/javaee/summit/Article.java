/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaee.summit;

import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Entity
@Table(name = "ARTICLE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Article.findAll", query = "SELECT a FROM Article a"),
    @NamedQuery(name = "Article.findByCKey", query = "SELECT a FROM Article a WHERE a.cKey = :cKey"),
    @NamedQuery(name = "Article.findByContent", query = "SELECT a FROM Article a WHERE a.content = :content"),
    @NamedQuery(name = "Article.findById", query = "SELECT a FROM Article a WHERE a.id = :id"),
    @NamedQuery(name = "Article.findByTitle", query = "SELECT a FROM Article a WHERE a.title = :title"),
    @NamedQuery(name = "Article.findByVersion", query = "SELECT a FROM Article a WHERE a.version = :version")})
public class Article implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "C_KEY")
    private Long cKey;
    @Size(max = 255)
    @Column(name = "CONTENT")
    private String content;
    @Column(name = "ID")
    private BigInteger id;
    @Size(max = 255)
    @Column(name = "TITLE")
    private String title;
    @Column(name = "VERSION")
    private BigInteger version;

    public Article() {
    }

    public Article(Long cKey) {
        this.cKey = cKey;
    }

    public Long getCKey() {
        return cKey;
    }

    public void setCKey(Long cKey) {
        this.cKey = cKey;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public BigInteger getId() {
        return id;
    }

    public void setId(BigInteger id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public BigInteger getVersion() {
        return version;
    }

    public void setVersion(BigInteger version) {
        this.version = version;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cKey != null ? cKey.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Article)) {
            return false;
        }
        Article other = (Article) object;
        if ((this.cKey == null && other.cKey != null) || (this.cKey != null && !this.cKey.equals(other.cKey))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "de.javaee.summit.Article[ cKey=" + cKey + " ]";
    }
    
}
