package de.javaeesummit.business.authentication.boundary;

import de.javaeesummit.business.authentication.entity.BugRole;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.Specializes;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class ExtendedRoleProvider extends RoleProvider{

    @Override @Produces @Specializes
    public BugRole auth() {
        return new BugRole("Extesibility works", 42l, "java duke");
    }
    
}
