package de.javaeesummit.business.bugs.control;

import java.util.Date;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Schedule;
import javax.ejb.ScheduleExpression;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.inject.Inject;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Startup
@Singleton
public class PeriodicBugDestroyer {

    @Resource
    TimerService ts;

    private Timer timer;
   
    @Inject
    private String second;
    
    @PostConstruct
    public void createTimer(){
        ScheduleExpression se = new ScheduleExpression();
        se.hour("*").minute("*").second(this.second);
        this.timer = ts.createCalendarTimer(se);
    }
    
    //@Schedule(hour="*",minute="*",second="*/2")
    @Timeout
    public void seekAndDestroy(){
        System.out.println("Found!!!!!" + new Date());
    }
    
}
