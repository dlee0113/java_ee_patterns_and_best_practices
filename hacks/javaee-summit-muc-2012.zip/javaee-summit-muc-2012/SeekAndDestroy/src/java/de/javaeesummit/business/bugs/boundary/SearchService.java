package de.javaeesummit.business.bugs.boundary;

import de.javaeesummit.business.authentication.entity.BugRole;
import de.javaeesummit.business.bugs.control.BugRepository;
import de.javaeesummit.business.bugs.control.Debugger;
import de.javaeesummit.business.bugs.control.SearchAlgorithm;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Stateless
public class SearchService {
    
    @Inject
    BugRepository br;
    
    @Inject
    Instance<BugRole> bugRole;

    @Inject
    Debugger debugger;
    
    @Inject
    Instance<SearchAlgorithm> algorithms;
    
    public String getBug(){
        for(SearchAlgorithm algo:algorithms){
            System.out.println("Algo: " + algo);
            algo.search();
        }
        return br.getBug() + bugRole.get();
    }
   
    public void debug(){
        List<Future<Long>> results = new ArrayList<Future<Long>>();
        for (int i = 0; i < 10; i++) {
            Future<Long> result = debugger.debugClass(i);
            results.add(result);
        }
        for (Future<Long> future : results) {
            try {
                System.out.println("--- " + future.get());
            } catch (InterruptedException ex) {
                Logger.getLogger(SearchService.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ExecutionException ex) {
                Logger.getLogger(SearchService.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        for (int i = 0; i < 10; i++) {
            debugger.debugInterface(i);
        }
        
    }
}
