package de.javaeesummit.business.bugs.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class BugRepository {

    
    public String getBug(){
        return "found: " + System.currentTimeMillis();
     }
}
