package de.javaeesummit.presentation;

import de.javaeesummit.business.bugs.boundary.SearchService;
import de.javaeesummit.business.configuration.boundary.StageProvider;
import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.faces.application.ProjectStage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Model
public class Index {
    
    @Inject
    SearchService service;
    
    public String getSichtbar(){
        return service.getBug();
    }
    
    @Produces
    public ProjectStage expose(){
        return FacesContext.getCurrentInstance().getApplication().getProjectStage();
    }
    
    public Object perform(){
        System.out.println("Performed!!!");
        service.debug();
        return null;
    }
}
