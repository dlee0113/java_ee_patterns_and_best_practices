/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaeesummit.business.bugs.control;

import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class JobMonitor {

    public void onSuccess(@Observes(during= TransactionPhase.AFTER_SUCCESS) Long result){
        System.out.println("++++Got result: " + result);
    }
    public void onFailure(@Observes(during= TransactionPhase.AFTER_FAILURE) Long result){
        System.out.println("----Got result: " + result);
    }
}
