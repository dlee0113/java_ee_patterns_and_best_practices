/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaeesummit.business.bugs.control;

import de.javaeesummit.business.bugs.boundary.SearchService;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Stateless
public class Debugger {
 
    @Resource
    SessionContext sc;
    
    @Inject
    Event<Long> events;
    

    @Asynchronous
    public Future<Long> debugClass(int classId){
        System.out.println("Debugging: " + classId);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(SearchService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new AsyncResult<Long>(System.currentTimeMillis());
    }

    @Asynchronous
    public void debugInterface(int classId){
        System.out.println("Debugging: " + classId);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(SearchService.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        events.fire(System.currentTimeMillis());
        //sc.setRollbackOnly();
    }
}
