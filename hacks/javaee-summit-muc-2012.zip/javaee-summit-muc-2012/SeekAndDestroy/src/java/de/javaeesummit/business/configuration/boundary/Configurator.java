/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaeesummit.business.configuration.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class Configurator {
    
    
    @Produces
    public String getString(InjectionPoint ip,Stage stage){
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String name = ip.getMember().getName();
        System.out.println("-" + stage + "--  " + clazz.getName() + "." + name);
        return "*/5";
    }
}
