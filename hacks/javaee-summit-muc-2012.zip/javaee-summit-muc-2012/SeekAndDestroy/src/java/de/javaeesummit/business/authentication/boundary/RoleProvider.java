/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaeesummit.business.authentication.boundary;

import de.javaeesummit.business.authentication.entity.BugRole;
import java.security.Principal;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class RoleProvider {

    @Inject
    private Principal principal;
    
    @Produces
    public BugRole auth(){
        return new BugRole(principal.getName(), System.currentTimeMillis(), "duke");
    }
}
