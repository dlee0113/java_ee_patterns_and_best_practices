/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaeesummit.business.authentication.entity;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class BugRole {
    
    private String name;
    private long creationTime;
    private String principalName;
    //relations to anything you can imagine

    public BugRole(String name, long creationTime, String principalName) {
        this.name = name;
        this.creationTime = creationTime;
        this.principalName = principalName;
    }

    @Override
    public String toString() {
        return "BugRole{" + "name=" + name + ", creationTime=" + creationTime + ", principalName=" + principalName + '}';
    }
    
    
}
