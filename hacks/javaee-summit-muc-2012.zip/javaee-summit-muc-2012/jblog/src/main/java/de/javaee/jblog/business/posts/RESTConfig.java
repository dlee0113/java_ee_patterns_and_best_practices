/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaee.jblog.business.posts;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author adam bien, adam-bien.com
 */
@ApplicationPath("resources")
public class RESTConfig extends Application{
    
}
