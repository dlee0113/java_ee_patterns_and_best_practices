package de.javaee.jblog.presentation;

import de.javaee.jblog.business.posts.boundary.Authoring;
import de.javaee.jblog.business.posts.entity.Article;
import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Model
public class Index {
    
    private Article article;
    
    @Inject
    Authoring authoring;
    
    @PostConstruct
    public void init(){
        this.article = new Article();
    }
    
    public String getMessage(){
        return authoring.getPost();
    }

    public Article getArticle() {
        return article;
    }
    
    
    
    public Object save(){
        this.authoring.save(article);
        return null;
    }
}
