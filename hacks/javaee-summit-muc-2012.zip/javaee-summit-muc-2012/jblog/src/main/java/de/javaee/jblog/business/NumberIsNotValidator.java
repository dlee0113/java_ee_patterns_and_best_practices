/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaee.jblog.business;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class NumberIsNotValidator implements ConstraintValidator<NumberIsNot, Long> {
    private NumberIsNot anno;
    
    @Override
    public void initialize(NumberIsNot anno) {
        this.anno = anno;
    }
    
    @Override
    public boolean isValid(Long value, ConstraintValidatorContext context) {
        return (anno.value() != value);
    }
}
