/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaee.jblog.business;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Documented
@Constraint(validatedBy = NumberIsNotValidator.class)
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface NumberIsNot {
    long value() default 42;
    String message() default "42 is forbidden!";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
