package de.javaee.jblog.business.posts.entity;

import de.javaee.jblog.business.NumberIsNot;
import java.io.Serializable;
import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Version;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Article implements Serializable{
    
    @Id
    @GeneratedValue
    @Column(name="c_key")
    private long key;
    
    @NumberIsNot(21)
    private long id;
    
    @Size(min=2,message="Wahnsinnig?")
    private String title;
    private String content;
    
    @Version
    private long version;

    public Article(long id, String title, String content) {
        this.id = id;
        this.title = title;
        this.content = content;
    }

    public Article() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    
    
    
    @Override
    public String toString() {
        return "Article{" + "id=" + id + ", title=" + title + ", content=" + content + '}';
    }
    
    
    
    
}
