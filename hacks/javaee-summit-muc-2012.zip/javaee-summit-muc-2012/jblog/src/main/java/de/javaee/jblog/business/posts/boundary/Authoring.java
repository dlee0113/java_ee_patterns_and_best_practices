package de.javaee.jblog.business.posts.boundary;

import de.javaee.jblog.business.posts.entity.Article;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

@TransactionManagement(TransactionManagementType.BEAN)
@Stateless
public class Authoring {
    
    @Inject
    Event<Article> articles;
    
    @PersistenceContext
    EntityManager em;
    
    @Resource
    UserTransaction ut;
    
    public String getPost(){
        return "post";
    }

    public void save(Article article) {
        try {
            ut.begin();
        } catch (NotSupportedException ex) {
            Logger.getLogger(Authoring.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SystemException ex) {
            Logger.getLogger(Authoring.class.getName()).log(Level.SEVERE, null, ex);
        }
        try{
        em.merge(article);
        articles.fire(article);
        }catch(RuntimeException e){
            try {
                ut.rollback();
            } catch (IllegalStateException ex) {
                Logger.getLogger(Authoring.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SecurityException ex) {
                Logger.getLogger(Authoring.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SystemException ex) {
                Logger.getLogger(Authoring.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        try {
            ut.commit();
        } catch (RollbackException ex) {
            Logger.getLogger(Authoring.class.getName()).log(Level.SEVERE, null, ex);
        } catch (HeuristicMixedException ex) {
            Logger.getLogger(Authoring.class.getName()).log(Level.SEVERE, null, ex);
        } catch (HeuristicRollbackException ex) {
            Logger.getLogger(Authoring.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SecurityException ex) {
            Logger.getLogger(Authoring.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalStateException ex) {
            Logger.getLogger(Authoring.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SystemException ex) {
            Logger.getLogger(Authoring.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
