package de.javaee.jblog.business.posts.boundary;

import de.javaee.jblog.business.posts.entity.Article;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.ejb.PostActivate;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Path("posts")
@Stateless
@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML,"serialization/java"})
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML,"serialization/java"})
public class PostsResource {
    
    @Inject
    Authoring authoring;
    
    @Inject
    Validator validator;
    
    @GET
    public List<Article> posts(){
        List<Article> list = new ArrayList<Article>(){{
            add(new Article(42,"java ee rocks","yes"));
            add(new Article(21,"test","hey content"));
        
        }};
        return list;
    }
    
    @GET
    @Path("{id}-{title}")
    public Article get(@PathParam("id") int id,@PathParam("title") String title,@Context HttpHeaders headers){
        //return new Article(id, title, "new content " + System.currentTimeMillis());
        throw new IllegalStateException("No articles at sunday!");
    }
    
    @DELETE
    @Path("{id}")
    public void delete(@PathParam("id") int id){
        System.out.println("Deleting: " + id);
    }
    
    
    @POST
    public Response save(Article article){
        Set<ConstraintViolation<Article>> validate = validator.validate(article, new Class[]{});
        if(!validate.isEmpty()){
           return Response.status(Response.Status.NOT_ACCEPTABLE).header("x-error", validate).build(); 
        }
            
        System.out.println("--- GOT article: " + article);
        authoring.save(article);
        URI uri = URI.create(""+article.getId());
        if(article == null){
            return Response.status(Response.Status.NOT_ACCEPTABLE).header("x-error", "Article cannot be null").build();
        }
        return Response.created(uri).build();
    }
}
