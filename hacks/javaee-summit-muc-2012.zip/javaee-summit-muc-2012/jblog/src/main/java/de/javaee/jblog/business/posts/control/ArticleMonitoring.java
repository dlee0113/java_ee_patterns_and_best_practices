package de.javaee.jblog.business.posts.control;

import de.javaee.jblog.business.posts.entity.Article;
import java.lang.management.ManagementFactory;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.enterprise.event.Observes;
import javax.management.InstanceAlreadyExistsException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.NotCompliantMBeanException;
import javax.management.ObjectName;

/**
 *
 * @author adam bien, adam-bien.com
 */
@LocalBean
@Startup
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class ArticleMonitoring implements ArticleMonitoringMXBean{

    private AtomicLong counter = new AtomicLong(0);
    private ObjectName objectName;
    private MBeanServer platformMBeanServer;
    
    @Resource
    SessionContext sc;
    
    @PostConstruct
    public void registerInJMX(){
        try {
            objectName = new ObjectName("jblog:type=" + this.getClass().getName());
            platformMBeanServer = ManagementFactory.getPlatformMBeanServer();
            platformMBeanServer.registerMBean(sc.getBusinessObject(ArticleMonitoring.class), objectName);
        } catch (Exception ex) {
            throw new IllegalStateException("Cannot register ArticleMonitoring",ex);
        }
    }
    @PreDestroy
    public void unregister(){
        try {
            platformMBeanServer.unregisterMBean(this.objectName);
        } catch (Exception ex) {
            throw new IllegalStateException("Cannot unregister ArticleMonitoring",ex);
        }
    }
    
    
    @Override
    public long getArticleAmount() {
        return counter.longValue();
    }
    
    public void onNewArticle(@Observes Article article){
        counter.incrementAndGet();
    }

    @Override
    public void reset() {
        this.counter.set(0);
    }
    
}
