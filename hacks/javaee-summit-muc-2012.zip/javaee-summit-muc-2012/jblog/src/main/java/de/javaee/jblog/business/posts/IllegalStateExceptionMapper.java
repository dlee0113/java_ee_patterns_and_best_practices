/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaee.jblog.business.posts;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Provider
public class IllegalStateExceptionMapper implements ExceptionMapper<IllegalStateException> {

    @Override
    public Response toResponse(IllegalStateException exception) {
        return Response.status(Response.Status.SERVICE_UNAVAILABLE).header("x-error", exception.toString()).build();
    }
    
    
    
}
