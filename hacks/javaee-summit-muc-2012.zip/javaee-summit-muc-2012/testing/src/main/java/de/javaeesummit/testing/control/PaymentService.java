/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaeesummit.testing.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
public interface PaymentService {
    
    public void pay();
}
