/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaeesummit.testing.boundary;

import de.javaeesummit.testing.control.PaymentService;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Stateless
public class OrderService {
    
    @Inject
    Payment payment;
    
    @Inject
    PaymentService paymentService;
    
    
    public void order(){
        try {
            if(!payment.checkPayment()){
                throw new IllegalStateException("Cannot order");
            }
        } catch (DontCallMeException ex) {
            throw new RuntimeException("Host is dead"); 
       }
    }
    
    public void save(){
    }
}
