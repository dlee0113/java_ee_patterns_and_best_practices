/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaeesummit.testing.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class PaypalPayment implements PaymentService{

    @Override
    public void pay() {
        System.out.println("Didn't");
    }
    
}
