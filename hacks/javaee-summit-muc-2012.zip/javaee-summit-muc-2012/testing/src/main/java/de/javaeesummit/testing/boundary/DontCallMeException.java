/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaeesummit.testing.boundary;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class DontCallMeException extends Exception{
    
}
