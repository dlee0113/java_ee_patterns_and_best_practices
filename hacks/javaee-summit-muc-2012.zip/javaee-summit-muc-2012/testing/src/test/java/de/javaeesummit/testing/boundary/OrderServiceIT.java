/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaeesummit.testing.boundary;

import de.javaeesummit.testing.control.AmexPayment;
import de.javaeesummit.testing.control.PaymentService;
import de.javaeesummit.testing.control.PaypalPayment;
import javax.inject.Inject;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ArchivePaths;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.ByteArrayAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/**
 *
 * @author adam bien, adam-bien.com
 */
@RunWith(Arquillian.class)
public class OrderServiceIT {
   
    @Inject
    PayingCustomer cut;
    
    @Deployment
    public static JavaArchive createTestArchive() {
        return ShrinkWrap.create(JavaArchive.class, "test.jar").
                addClasses(PayingCustomer.class,AmexPayment.class,PaypalPayment.class,PaymentService.class).
                addAsManifestResource(
                new ByteArrayAsset("<beans/>".getBytes()),
                ArchivePaths.create("beans.xml"));
    }
    
    @Test
    public void paymentWorks(){
        assertTrue(cut.works());
    }

}
