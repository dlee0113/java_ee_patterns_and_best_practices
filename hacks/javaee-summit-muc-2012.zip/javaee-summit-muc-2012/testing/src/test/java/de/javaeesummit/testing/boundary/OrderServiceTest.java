/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaeesummit.testing.boundary;

import javax.annotation.PostConstruct;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import static org.mockito.Mockito.*;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class OrderServiceTest {
    
    OrderService cut;
    
    @Before
    public void inject(){
        cut = new OrderService();
        cut.payment = mock(Payment.class);
    }

    @Test(expected=IllegalStateException.class)
    public void orderWithoutPayment() throws Exception {
        when(cut.payment.checkPayment()).thenReturn(false);
        cut.order();
    }

    @Test
    public void successfulOrder() throws Exception {
        when(cut.payment.checkPayment()).thenReturn(true);
        cut.order();
        verify(cut.payment).checkPayment();
    }

    @Test(expected=RuntimeException.class)
    public void orderWithUnavailableHost() throws Exception {
        when(cut.payment.checkPayment()).thenThrow(new DontCallMeException());
        cut.order();
    }
    
    
}
