/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaeesummit.testing.boundary;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import javax.annotation.PostConstruct;
import javax.ws.rs.core.MediaType;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class PostsIT {
    private Client create;

    @Before
    public void init(){
        this.create = Client.create();
    }
    
    @Test
    public void get(){
        Article article = this.create.resource("http://localhost:8080/jblog/resources/posts/42-hugo").accept(MediaType.APPLICATION_XML).get(Article.class);
        System.out.println("Article: " + article);
    
    }
    @Test
    public void post(){
       this.create.resource("http://localhost:8080/jblog/resources/posts").accept(MediaType.APPLICATION_XML).post(new Article(42, "hey", "content"));
    
    }
    
}
