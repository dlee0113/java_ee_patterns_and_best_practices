/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.javaeesummit.testing.boundary;

import de.javaeesummit.testing.control.PaymentService;
import javax.inject.Inject;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class PayingCustomer {
    
    @Inject
    PaymentService paymentService;
    
    
    public boolean works(){
        return paymentService != null;
    }
}
