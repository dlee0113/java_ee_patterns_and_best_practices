package de.javaeesummit.testing.boundary;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam bien, adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Article implements Serializable{
    
    private long id;
    private String title;
    private String content;

    public Article(long id, String title, String content) {
        this.id = id;
        this.title = title;
        this.content = content;
    }

    public Article() {
    }

    
    @Override
    public String toString() {
        return "Article{" + "id=" + id + ", title=" + title + ", content=" + content + '}';
    }
    
    
    
    
}
