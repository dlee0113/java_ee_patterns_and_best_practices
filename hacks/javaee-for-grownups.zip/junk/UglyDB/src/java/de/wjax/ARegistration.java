/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam-bien.com
 */
@Entity
@Table(name = "A_REGISTRATION")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ARegistration.findAll", query = "SELECT a FROM ARegistration a"),
    @NamedQuery(name = "ARegistration.findById", query = "SELECT a FROM ARegistration a WHERE a.id = :id"),
    @NamedQuery(name = "ARegistration.findByAge", query = "SELECT a FROM ARegistration a WHERE a.age = :age"),
    @NamedQuery(name = "ARegistration.findByFirstname", query = "SELECT a FROM ARegistration a WHERE a.firstname = :firstname"),
    @NamedQuery(name = "ARegistration.findByLastname", query = "SELECT a FROM ARegistration a WHERE a.lastname = :lastname")})
public class ARegistration implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Column(name = "AGE")
    private Integer age;
    @Size(max = 255)
    @Column(name = "FIRSTNAME")
    private String firstname;
    @Size(max = 255)
    @Column(name = "LASTNAME")
    private String lastname;

    public ARegistration() {
    }

    public ARegistration(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ARegistration)) {
            return false;
        }
        ARegistration other = (ARegistration) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "de.wjax.ARegistration[ id=" + id + " ]";
    }
    
}
