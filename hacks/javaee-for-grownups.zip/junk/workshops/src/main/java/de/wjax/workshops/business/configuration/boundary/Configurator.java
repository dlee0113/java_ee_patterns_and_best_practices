/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.workshops.business.configuration.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam-bien.com
 */
public class Configurator {

    @Produces
    public String getProperty(InjectionPoint ip,Stage s){
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String name = ip.getMember().getName();
        return clazz.getName() + "." + name + s.name();
    }
}
