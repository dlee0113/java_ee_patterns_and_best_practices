package de.wjax.workshops.business.registration.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam-bien.com
 */
@Table(name = "A_REGISTRATION")
@Entity
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Registration {
    
    @Id
    @GeneratedValue
    private long id;
    
    private String firstName;
    private String lastName;
    private int age;

    public Registration(String firstName, String lastName, int age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
    }

    public Registration() {
    }

    public long getId() {
        return id;
    }
    
    

    @Override
    public String toString() {
        return "Registration{" + "firstName=" + firstName + ", lastName=" + lastName + ", age=" + age + '}';
    }
    
    
}
