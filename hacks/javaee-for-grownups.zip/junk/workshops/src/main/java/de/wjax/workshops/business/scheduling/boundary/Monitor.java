package de.wjax.workshops.business.scheduling.boundary;

import javax.interceptor.AroundInvoke;
import javax.interceptor.AroundTimeout;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam-bien.com
 */
public class Monitor {

    @AroundTimeout
    @AroundInvoke
    public Object log(InvocationContext ic) throws Exception{
        long start = System.currentTimeMillis();
       try{
            return ic.proceed();
        }finally{
           System.out.println("---After "+ (System.currentTimeMillis()-start) + " " + ic.getMethod());
        }
    }
}
