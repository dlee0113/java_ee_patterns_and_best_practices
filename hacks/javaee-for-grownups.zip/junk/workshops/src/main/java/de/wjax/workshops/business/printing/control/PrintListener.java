/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.workshops.business.printing.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;
import javax.servlet.AsyncContext;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class PrintListener {
    
    private CopyOnWriteArrayList<AsyncContext> webListeners;
    
    @PostConstruct
    public void init(){
        this.webListeners = new CopyOnWriteArrayList<AsyncContext>();
    }
    
    
    public void onPrintDone(@Observes(during = TransactionPhase.AFTER_SUCCESS) String printout) throws IOException{
        System.out.println("+++++Printout: " + printout);
        for (AsyncContext asyncContext : webListeners) {
            PrintWriter writer = asyncContext.getResponse().getWriter();
            writer.println("Printed: " + printout);
            asyncContext.complete();
            webListeners.remove(asyncContext);
        }
    }
    public void onPrintFailed(@Observes(during = TransactionPhase.AFTER_FAILURE) String printout){
        System.out.println("----Printout: " + printout);
    }
    
    public void webListener(@Observes AsyncContext asyncContext){
        this.webListeners.add(asyncContext);
    }
}
