package de.wjax.workshops.business.registration.boundary;

import de.wjax.workshops.business.registration.entity.Registration;
import java.net.URI;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Stateless
@Path("registrations")
public class RegistrationsResource {
    
    @Inject
    Principal principal;
    
    @Inject
    RegisterService rs;
    
    @GET
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    public List<Registration> goodMorning(){
        List<Registration> results = new ArrayList<Registration>(){{
        add(new Registration("java", "duke " +principal , 42));
        add(new Registration("java", "duke " +principal , 42));
        add(new Registration("java", "duke " +principal , 42));
        }};
        return results;
    }
    
    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    public Registration registration(@PathParam("id") String id){
        return new Registration("java", "duke " +id , 42);
    }
    
    @POST
    @Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    public Response create(Registration registration){
        System.out.println("--- Got registration: " + registration);
        Registration savedOrUpdated = rs.saveOrUpdate(registration);
        URI uri = URI.create("/" + savedOrUpdated.getId());
        return Response.created(uri).build();
    }
}
