/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.workshops.client;

/**
 *
 * @author adam-bien.com
 */
public class FatClient {
    public static void main(String[] args) {
    }
}
