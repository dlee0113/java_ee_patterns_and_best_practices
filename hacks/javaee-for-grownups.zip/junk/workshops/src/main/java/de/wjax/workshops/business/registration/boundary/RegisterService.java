package de.wjax.workshops.business.registration.boundary;

import de.wjax.workshops.business.printing.control.Printer;
import de.wjax.workshops.business.registration.control.Overflow;
import de.wjax.workshops.business.registration.control.RegistrationValidator;
import de.wjax.workshops.business.registration.entity.Registration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


/**
 *
 * @author adam-bien.com
 */
@Stateless
public class RegisterService {
    
    @PersistenceContext
    EntityManager em;
    
    @Inject @Overflow(Overflow.Level.EMPTY)
    RegistrationValidator rv;
    
    @Inject
    Printer printer;
    

    public Registration saveOrUpdate(Registration registration){
        List<Future<String>> futures = new ArrayList<Future<String>>();
        if(!rv.isValid(registration)){
            throw new IllegalArgumentException("Go away!");
        }
        for(int i=0;i<10;i++){
            Future<String> print = printer.print(registration);
            futures.add(print);
        }
        for (Future<String> future : futures) {
            try {
                System.out.println("Result: " + future.get());
            } catch (InterruptedException ex) {
                Logger.getLogger(RegisterService.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ExecutionException ex) {
                ex.getCause(); //the origin
            }
        }
        return em.merge(registration);
    }
}
