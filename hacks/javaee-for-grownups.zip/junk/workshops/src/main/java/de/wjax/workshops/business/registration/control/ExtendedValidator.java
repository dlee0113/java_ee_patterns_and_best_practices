/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.workshops.business.registration.control;

import de.wjax.workshops.business.registration.entity.Registration;
import javax.enterprise.inject.Specializes;

/**
 *
 * @author adam-bien.com
 */
@Overflow(Overflow.Level.FULL)
public class ExtendedValidator implements RegistrationValidator{

    @Override
    public boolean isValid(Registration registration) {
        System.out.println("++++++ Extended validated: " + registration);
        return false;
    }
    
}
