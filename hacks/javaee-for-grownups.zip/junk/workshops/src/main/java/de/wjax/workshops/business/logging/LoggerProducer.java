/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.workshops.business.logging;

import java.util.logging.Logger;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam-bien.com
 */
public class LoggerProducer {
   
    @Produces
    public Logger create(InjectionPoint ip){
        return Logger.getLogger(ip.getMember().getDeclaringClass().getName());
    }
}
