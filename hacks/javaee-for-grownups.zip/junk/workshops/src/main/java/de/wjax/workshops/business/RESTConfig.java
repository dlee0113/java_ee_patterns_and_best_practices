package de.wjax.workshops.business;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("v1")
public class RESTConfig extends Application {
    
}
