/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.workshops.business.registration.control;

import de.wjax.workshops.business.registration.entity.Registration;

/**
 *
 * @author adam-bien.com
 */
@Overflow(Overflow.Level.EMPTY)
public class OptimisticValidator implements RegistrationValidator{

    @Override
    public boolean isValid(Registration registration) {
        System.out.println("+Optimistic++++++ " + registration);
        return true;
    }
    
}
