package de.wjax.workshops.business.printing.control;

import javax.ejb.Asynchronous;
import javax.ejb.Stateless;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class ThreadExecutor {
    
    @Asynchronous
    public void execute(Runnable runnable){
        runnable.run();
    }
}
