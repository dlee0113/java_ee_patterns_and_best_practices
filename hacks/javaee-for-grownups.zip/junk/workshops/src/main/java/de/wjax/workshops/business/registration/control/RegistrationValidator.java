package de.wjax.workshops.business.registration.control;

import de.wjax.workshops.business.registration.entity.Registration;

/**
 *
 * @author adam-bien.com
 */
public interface RegistrationValidator {
    
    
    public boolean isValid(Registration registration);
}
