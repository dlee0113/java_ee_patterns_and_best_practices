/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.workshops.business.scheduling.boundary;

import java.util.Collection;
import java.util.Date;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Schedule;
import javax.ejb.ScheduleExpression;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerConfig;
import javax.ejb.TimerService;
import javax.inject.Inject;
import javax.interceptor.Interceptors;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
@Interceptors(Monitor.class)
public class Scheduler {
    
    @Inject
    String message;
    
    @Resource
    TimerService ts;
    
    private Timer timer;
    
    @PostConstruct
    public void reconfigure(){
        ScheduleExpression se = new ScheduleExpression();
        TimerConfig config = new TimerConfig();
        config.setPersistent(true);
               
        se.hour("*").minute("*").second("*/5");
        this.timer = ts.createCalendarTimer(se,config);
    }
    
    @Timeout
    public void startJob(){
        System.out.println(message + "---scheduling: " + new Date());
    }
}
