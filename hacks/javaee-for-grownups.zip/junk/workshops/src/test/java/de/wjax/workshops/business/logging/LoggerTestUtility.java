/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.workshops.business.logging;

import java.util.logging.Logger;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class LoggerTestUtility {
    
    @Inject
    Logger log;

    public Logger getLog() {
        return log;
    }
    
    
}
