/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.workshops.business.registration.boundary;

import de.wjax.workshops.business.registration.control.ExtendedValidator;
import de.wjax.workshops.business.registration.control.OptimisticValidator;
import de.wjax.workshops.business.registration.entity.Registration;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.FlushModeType;
import javax.persistence.LockModeType;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.metamodel.Metamodel;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Before;

/**
 *
 * @author adam-bien.com
 */
public class RegisterServiceTest {

    RegisterService cut;
    
    @Before
    public void inject(){
     cut = new RegisterService();
     cut.em = mock(EntityManager.class);
     cut.rv = mock(OptimisticValidator.class);
     
    }

    @Test(expected = IllegalArgumentException.class)
    public void invalidArgument() {
        final Registration registration = new Registration();
        when(cut.rv.isValid(registration)).thenReturn(false);
        cut.saveOrUpdate(registration);
    }
}
