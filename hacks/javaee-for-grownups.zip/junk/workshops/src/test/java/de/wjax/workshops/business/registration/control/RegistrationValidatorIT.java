/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.wjax.workshops.business.registration.control;

import de.wjax.workshops.business.registration.entity.Registration;
import javax.inject.Inject;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.Archive;
import org.jboss.shrinkwrap.api.ArchivePaths;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;

/**
 *
 * @author adam-bien.com
 */
@RunWith(Arquillian.class)
public class RegistrationValidatorIT {
    
    @Inject @Overflow(Overflow.Level.EMPTY)
    RegistrationValidator cut;
    
    @Deployment
    public static Archive deploy(){
        return  ShrinkWrap.create(WebArchive.class).
                addClasses(RegistrationValidator.class,OptimisticValidator.class, Registration.class,ExtendedValidator.class,Overflow.class).
                addAsWebInfResource(EmptyAsset.INSTANCE,ArchivePaths.create("beans.xml"));
    }
    
    @Test
    public void optimistic() {
        assertTrue(cut.isValid(new Registration()));
    }
}
