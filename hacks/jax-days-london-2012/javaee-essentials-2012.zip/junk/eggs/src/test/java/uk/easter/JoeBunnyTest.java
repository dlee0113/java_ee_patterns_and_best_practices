/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.easter;

import org.junit.AfterClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.BeforeClass;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class JoeBunnyTest {

    @Test
    public void unitTest() {
    }
}
