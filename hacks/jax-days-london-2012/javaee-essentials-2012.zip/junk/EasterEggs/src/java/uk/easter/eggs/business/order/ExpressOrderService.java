
package uk.easter.eggs.business.order;
import static uk.easter.eggs.business.order.Priority.Type.*;
/**
 *
 * @author adam bien, adam-bien.com
 */
@Priority(HIGH)
public class ExpressOrderService implements OrderServiceContract{

    @Override
    public void order(EggOrder eggId) {
        System.out.println("-Express-- " + eggId);
    }
    
}
