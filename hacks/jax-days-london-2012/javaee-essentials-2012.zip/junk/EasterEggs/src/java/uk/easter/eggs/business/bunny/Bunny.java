/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.easter.eggs.business.bunny;

import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;
import uk.easter.eggs.business.order.EggOrder;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class Bunny {
    
    
    public void onNewOrder(@Observes(during= TransactionPhase.AFTER_SUCCESS) EggOrder orders){
        System.out.println("---Thanks for the order!: " + orders);
    }
}
