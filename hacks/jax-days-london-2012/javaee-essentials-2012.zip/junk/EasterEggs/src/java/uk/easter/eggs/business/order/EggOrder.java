package uk.easter.eggs.business.order;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Entity
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class EggOrder {
    
    @Id
    @GeneratedValue
    private long id;
    @Min(1) @Max(43)
    private int amount;
    @Size(min=3,max=20)
    private String color;

    public EggOrder(int amount, String color) {
        this.amount = amount;
        this.color = color;
    }

    public EggOrder() {
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    

    @Override
    public String toString() {
        return "EggOrder{" + "id=" + id + ", amount=" + amount + ", color=" + color + '}';
    }
    
    
    
}
