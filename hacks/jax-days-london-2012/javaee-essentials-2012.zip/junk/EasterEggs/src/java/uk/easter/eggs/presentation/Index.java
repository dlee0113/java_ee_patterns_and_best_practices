package uk.easter.eggs.presentation;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import uk.easter.eggs.business.order.EggOrder;
import uk.easter.eggs.business.order.OrderService;
import uk.easter.eggs.business.order.OrderServiceContract;
import uk.easter.eggs.business.order.Priority;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Named
@RequestScoped
public class Index {
    
    @Inject @Priority(Priority.Type.STANDARD)
    OrderServiceContract os;
    
    EggOrder eggOrder;

    @PostConstruct
    public void init(){
        System.out.println("Index initialized !");
        eggOrder = new EggOrder();
    }
    

    public EggOrder getEggOrder() {
        return eggOrder;
    }
    
    public Object save(){
        System.out.println("### " + eggOrder);
        this.os.order(eggOrder);
        return null;
    }
    
    @PreDestroy
    public void destroy(){
        System.out.println("Index pre destroy!");
    }
}
