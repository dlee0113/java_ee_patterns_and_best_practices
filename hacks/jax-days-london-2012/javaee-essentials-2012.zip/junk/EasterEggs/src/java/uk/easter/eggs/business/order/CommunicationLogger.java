package uk.easter.eggs.business.order;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class CommunicationLogger {

    @AroundInvoke
    public Object log(InvocationContext ic) throws Exception{
        System.out.println("---- " + ic.getMethod());
        return ic.proceed();
    }
}
