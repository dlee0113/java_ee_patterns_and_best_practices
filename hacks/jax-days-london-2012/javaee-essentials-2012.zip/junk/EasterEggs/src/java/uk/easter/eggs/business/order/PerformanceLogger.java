package uk.easter.eggs.business.order;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class PerformanceLogger {

    @AroundInvoke
    public Object log(InvocationContext ic) throws Exception{
        System.out.println("--Method: " + ic.getMethod());
        long start = System.currentTimeMillis();
        try{
            return ic.proceed();
        }finally{
            System.out.println("Performed in: " + (System.currentTimeMillis() - start));
        }
    }
}
