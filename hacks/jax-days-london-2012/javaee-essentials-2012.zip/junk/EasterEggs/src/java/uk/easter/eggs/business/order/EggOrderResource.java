package uk.easter.eggs.business.order;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path("orders")
@Stateless
@Interceptors(CommunicationLogger.class)
@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
public class EggOrderResource {
    
    @GET
    public List<EggOrder> orders(){
        List<EggOrder> orders = new ArrayList<EggOrder>(){{
            add( new EggOrder(42, "silver"));
            add( new EggOrder(21, "gold"));
        }};
        return orders;
    }
    
    @GET
    @Path("{amount}-{color}")
    public EggOrder get(@PathParam("amount") int amount, @PathParam("color") String color){
        return new EggOrder(amount, color);
    }
    
    @POST
    @Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    public void put(EggOrder eggOrder){
        System.out.println("----" + eggOrder);
    }
}
