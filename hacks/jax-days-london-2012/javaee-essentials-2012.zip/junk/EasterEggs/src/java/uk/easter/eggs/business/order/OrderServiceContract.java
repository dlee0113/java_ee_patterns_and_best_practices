/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.easter.eggs.business.order;

/**
 *
 * @author adam bien, adam-bien.com
 */
public interface OrderServiceContract {

    void order(EggOrder eggOrder);
    
}
