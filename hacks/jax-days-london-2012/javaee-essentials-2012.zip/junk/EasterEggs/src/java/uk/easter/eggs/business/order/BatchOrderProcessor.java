package uk.easter.eggs.business.order;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.inject.Named;
import javax.interceptor.Interceptors;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Named
@Stateless
@Interceptors(PerformanceLogger.class)
public class BatchOrderProcessor {
    
    @Inject
    OrderProcessor op;
    
    
    public String order(){
        StringBuilder result = new StringBuilder();
        List<Future<String>> futures = new ArrayList<Future<String>>();
        for(int i=0;i<10;i++){
            futures.add(op.order());
        }
        for (Future<String> future : futures) {
            try {
                result.append(future.get()).append("|");
            } catch (Exception ex) {
                Logger.getLogger(BatchOrderProcessor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return result.toString();
    }
}
