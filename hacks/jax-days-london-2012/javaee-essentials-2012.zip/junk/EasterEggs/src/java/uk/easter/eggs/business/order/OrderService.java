package uk.easter.eggs.business.order;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.*;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Priority(Priority.Type.STANDARD)
@Singleton
public class OrderService implements OrderServiceContract {

    @PersistenceContext
    EntityManager em;
    
    private List<EggOrder> orders;
    
    @Resource
    TimerService service;
    
    private Timer timer;
    
    @Inject
    Event<EggOrder> orderListeners;
    
    @Resource
    SessionContext sc;
    
    @PostConstruct
    public void init(){
        this.orders = new ArrayList<EggOrder>();
        ScheduleExpression exp = new ScheduleExpression();
        exp.hour("*").minute("*").second("*/3");
        this.timer = service.createCalendarTimer(exp);
    }
    
    @Override
    public void order(EggOrder order){
        this.orders.add(order);
        System.out.println("--Egg- " + order);
        this.orderListeners.fire(order);
        sc.setRollbackOnly();
    }
    
    @Timeout
    public void processOrders(){
        for (EggOrder eggOrder : orders) {
           em.persist(eggOrder);
        }
       // System.out.println("-Dynamic timer--" + orders + " " + new Date());
        orders.clear();
    }
}
