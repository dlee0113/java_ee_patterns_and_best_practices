/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.eggsonline.business.order.control;

import javax.inject.Inject;
import uk.eggsonline.business.order.entity.EasterEgg;

/**
 *
 * @author adam bien, adam-bien.com
 */
@US
public class EnterpriseCooker implements Cooker{
    
    @Inject
    PowerSupply powerSupply;

    @Override
    public boolean cook(EasterEgg egg) {
        System.out.println("---- Cooking: " + egg + " " + powerSupply);
        return true;
    }
    
}
