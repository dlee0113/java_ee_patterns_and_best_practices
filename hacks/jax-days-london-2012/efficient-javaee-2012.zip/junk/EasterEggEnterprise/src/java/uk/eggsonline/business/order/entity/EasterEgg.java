/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.eggsonline.business.order.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam bien, adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class EasterEgg {
    
    private String color;
    private int weight;

    public EasterEgg(String color, int weight) {
        this.color = color;
        this.weight = weight;
    }

    public EasterEgg() {
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    
    
    @Override
    public String toString() {
        return "EasterEgg{" + "color=" + color + ", weight=" + weight + '}';
    }
    
    
    
    
}
