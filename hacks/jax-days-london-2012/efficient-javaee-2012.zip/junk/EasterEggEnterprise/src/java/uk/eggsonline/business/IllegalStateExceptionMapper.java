/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.eggsonline.business;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;


/**
 *
 * @author adam bien, adam-bien.com
 */
@Provider
public class IllegalStateExceptionMapper implements ExceptionMapper<IllegalStateException> {

    @Override
    public Response toResponse(IllegalStateException exception) {
        return Response.status(4242).header("X-Error-Message", exception.getMessage()).build();
    }
    
}
