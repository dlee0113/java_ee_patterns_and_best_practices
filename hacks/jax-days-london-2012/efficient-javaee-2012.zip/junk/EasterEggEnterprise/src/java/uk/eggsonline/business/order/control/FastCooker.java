package uk.eggsonline.business.order.control;

import uk.eggsonline.business.order.entity.EasterEgg;

/**
 *
 * @author adam bien, adam-bien.com
 */
@UK
public class FastCooker implements Cooker{

    @Override
    public boolean cook(EasterEgg egg) {
        System.out.println("---Extremely fast cooking!" + egg);
        return true;
    }
    
}
