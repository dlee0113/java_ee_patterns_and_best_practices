package uk.eggsonline.business.monitoring;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.enterprise.event.Observes;
import javax.management.*;
import javax.servlet.AsyncContext;
import uk.eggsonline.business.order.entity.EasterEgg;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Startup
@Singleton
@LocalBean
public class EggOrderMonitoring implements EggOrderMonitoringMXBean {

    private MBeanServer mbeanServer;
    private ObjectName name;
    
    private String status;
    
    private AsyncContext ac;
    
    @PostConstruct
    public void registerInJMX(){
        try {
            this.name = new ObjectName(":type=EggOrderMonitoring,name=EggsMonitor");
            this.mbeanServer = ManagementFactory.getPlatformMBeanServer();
            this.mbeanServer.registerMBean(this, name);
            this.status ="--";
        } catch (Exception exception) {
            throw new IllegalStateException("Cannot register monitoring! " + exception);
        } 
    }
    
    @Override
    public String getStatus(){
        return this.status;
    }
    
    public void onNewEgg(@Observes EasterEgg egg){
        this.status += egg.toString();
        if(this.ac != null){
            try {
                this.ac.getResponse().getWriter().print(this.status);
            } catch (IOException ex) {
                Logger.getLogger(EggOrderMonitoring.class.getName()).log(Level.SEVERE, null, ex);
            }
            this.ac.complete();
        }
    }
    
    public void onNewListener(@Observes AsyncContext ctx){
        this.ac = ctx;
    }
   
    @PreDestroy
   public void unregister(){
        try {
            this.mbeanServer.unregisterMBean(name);
        } catch (Exception ex) {
            throw new IllegalStateException("Cannot register unregister! " + ex);
        }
            
   }
}
