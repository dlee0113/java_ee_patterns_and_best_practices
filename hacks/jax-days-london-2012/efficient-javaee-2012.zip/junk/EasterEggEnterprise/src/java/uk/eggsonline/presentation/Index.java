package uk.eggsonline.presentation;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Model;
import javax.inject.Inject;
import javax.inject.Named;
import uk.eggsonline.business.order.boundary.EggOrderResource;
import uk.eggsonline.business.order.boundary.OrderService;
import uk.eggsonline.business.order.entity.EasterEgg;

@Model
public class Index {

    @Inject
    EggOrderResource orderService;
    
    private EasterEgg easterEgg = new EasterEgg();

    public EasterEgg getEasterEgg() {
        return easterEgg;
    }
    
    
    public Object save(){
        orderService.place(easterEgg);
        return null;
    }
}
