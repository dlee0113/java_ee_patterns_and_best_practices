/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.eggsonline.business.order.control;

import javax.enterprise.inject.Produces;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class PowerSupplyFactory {
    
    @Produces
    public PowerSupply create(){
        return new PowerSupply(240);
    }
}
