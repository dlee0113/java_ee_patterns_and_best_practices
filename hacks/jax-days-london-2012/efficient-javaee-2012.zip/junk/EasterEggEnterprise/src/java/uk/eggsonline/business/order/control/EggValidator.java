package uk.eggsonline.business.order.control;

import uk.eggsonline.business.order.entity.EasterEgg;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class EggValidator {

    public boolean healthy(EasterEgg easterEgg){
        return true;
    }
}
