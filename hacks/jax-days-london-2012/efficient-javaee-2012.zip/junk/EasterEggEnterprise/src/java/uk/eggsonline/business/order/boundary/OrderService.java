package uk.eggsonline.business.order.boundary;

import java.awt.Paint;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import uk.eggsonline.business.order.control.Cooker;
import uk.eggsonline.business.order.control.EggValidator;
import uk.eggsonline.business.order.control.Painter;
import uk.eggsonline.business.order.control.Speed;
import uk.eggsonline.business.order.control.SpeedLiteral;
import uk.eggsonline.business.order.entity.EasterEgg;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Stateless
public class OrderService {
    
    @Inject
    Painter painter;
    
    @Inject
    Cooker cooker;
    
    @Inject
    EggValidator eggValidator;
    
    @Inject
    Event<EasterEgg> monitoring;

    public String getOrders() {
        if(!eggValidator.healthy(null))
            throw new IllegalStateException("Egg is not healthy");
        return "all orders from EJB!";
    }
    
    @Asynchronous
    public Future<EasterEgg> placeOrder(EasterEgg easterEgg){
        System.out.println("Cooker : " + cooker);
        System.out.println("--Thanks: " + painter.paint(easterEgg));
        monitoring.fire(easterEgg);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(OrderService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new AsyncResult<EasterEgg>(easterEgg);
    } 
    
}
