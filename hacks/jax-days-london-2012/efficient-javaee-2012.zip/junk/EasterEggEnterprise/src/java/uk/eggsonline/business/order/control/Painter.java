package uk.eggsonline.business.order.control;

import javax.inject.Inject;
import uk.eggsonline.business.order.entity.EasterEgg;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class Painter {
    
    @Inject
    private String backgroundColor;
    
    public EasterEgg paint(EasterEgg easterEgg){
        String color = easterEgg.getColor();
        easterEgg.setColor(backgroundColor + ":" + color);
        System.out.println("After painting: " + easterEgg);
        return easterEgg;
    }
}
