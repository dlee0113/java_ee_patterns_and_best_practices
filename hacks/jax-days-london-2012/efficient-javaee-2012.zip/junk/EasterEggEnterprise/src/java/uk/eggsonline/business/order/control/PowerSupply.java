/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.eggsonline.business.order.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class PowerSupply {
    
    private int voltage;

    public PowerSupply(int voltage) {
        this.voltage = voltage;
    }

    @Override
    public String toString() {
        return "PowerSupply{" + "voltage=" + voltage + '}';
    }
    
    
    
}
