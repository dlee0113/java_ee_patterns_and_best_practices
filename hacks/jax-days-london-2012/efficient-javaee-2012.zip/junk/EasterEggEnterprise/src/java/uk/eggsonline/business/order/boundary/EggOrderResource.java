package uk.eggsonline.business.order.boundary;

import java.net.URI;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import uk.eggsonline.business.order.entity.EasterEgg;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Stateless
@Path("orders")
public class EggOrderResource {
    
    @Inject
    OrderService orderService;
    
    @GET
    @Produces({MediaType.APPLICATION_XML,"application/eggs"})
    public Response test(@Context HttpHeaders headers){
        String orders = orderService.getOrders();
        return Response.status(Response.Status.OK).entity(new EasterEgg(orders, 180)).
        header("X-easter-order", "really enjoy!").
        build();
    }
    
    @POST
    @Consumes({MediaType.APPLICATION_XML})
    public Response place(EasterEgg egg){
        URI uri = URI.create("egg-id");
        orderService.placeOrder(egg);
        return Response.created(uri).build();
    }
}
