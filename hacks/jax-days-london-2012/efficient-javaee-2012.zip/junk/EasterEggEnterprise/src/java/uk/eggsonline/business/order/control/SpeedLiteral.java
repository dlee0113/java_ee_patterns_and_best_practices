package uk.eggsonline.business.order.control;

import java.lang.annotation.Annotation;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class SpeedLiteral implements Speed{
    private Velocity velocity;

    public SpeedLiteral(Velocity velocity) {
        this.velocity = velocity;
    }

    @Override
    public Velocity value() {
        return this.velocity;
    }

    @Override
    public Class<? extends Annotation> annotationType() {
        return Speed.class;
    }
    
}
