package uk.eggsonline.business.configuration.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class Configurator {

    
    @Produces
    public String getString(InjectionPoint ip){
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String fieldName = ip.getMember().getName();
        return clazz.getName() + "." + fieldName;
    }
}
