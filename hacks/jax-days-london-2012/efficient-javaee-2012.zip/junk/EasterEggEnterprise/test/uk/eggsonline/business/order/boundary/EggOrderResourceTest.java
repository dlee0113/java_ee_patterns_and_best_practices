/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.eggsonline.business.order.boundary;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import javax.ws.rs.core.MediaType;
import org.junit.AfterClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.BeforeClass;
import uk.eggsonline.business.order.entity.EasterEgg;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class EggOrderResourceTest {

   
    @Test
    public void place() {
        Client client = Client.create();
        ClientResponse response = client.resource("http://localhost:8080/EasterEggEnterprise/resources/orders").accept(MediaType.APPLICATION_XML).entity(new EasterEgg("silver", 12)).post(ClientResponse.class);
        System.out.println("Response: " + response);
    }
}
