/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uk.eggsonline.business.order.boundary;

import java.lang.reflect.Field;
import javax.inject.Inject;
import org.junit.AfterClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import uk.eggsonline.business.order.control.EggValidator;
import static org.mockito.Mockito.*;
import uk.eggsonline.business.order.entity.EasterEgg;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class OrderServiceTest {
    
    OrderService cut;
    
    @Before
    public void inject() {
        cut = new OrderService();
        cut.eggValidator = mock(EggValidator.class);
    }
    
    
    @Test(expected=IllegalStateException.class)
    public void getInvalidOrder() {
        when(cut.eggValidator.healthy(any(EasterEgg.class))).thenReturn(false);
        cut.getOrders();
    }

    @Test
    public void getValidOrder() {
        when(cut.eggValidator.healthy(any(EasterEgg.class))).thenReturn(true);
        cut.getOrders();
        verify(cut.eggValidator).healthy(null);
    }
    
    
    @Test
    public void howManyFields(){
        Field[] declaredFields = OrderService.class.getDeclaredFields();
        for (Field field : declaredFields) {
            if(field.isAnnotationPresent(Inject.class)){
                System.out.println("--- Injected field! " + field.getName() );
            }
        }
    }

}
