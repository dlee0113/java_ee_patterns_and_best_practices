package pt.workshop.rockandrio.business.tickets.control;

import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Stateless
public class Printer {
    
    @Asynchronous
    public Future<String> print(String name){
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Printer.class.getName()).log(Level.SEVERE, null, ex);
        }
        final String msg = name + " printed !";
        System.out.println(msg);
        return new AsyncResult<String>(msg);
    }
}
