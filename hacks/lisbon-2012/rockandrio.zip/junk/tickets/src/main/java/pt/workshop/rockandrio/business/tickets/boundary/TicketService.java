package pt.workshop.rockandrio.business.tickets.boundary;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.Asynchronous;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import pt.workshop.rockandrio.business.security.entity.RockPrincipal;
import pt.workshop.rockandrio.business.tickets.control.CashPayment;
import pt.workshop.rockandrio.business.tickets.control.Payment;
import pt.workshop.rockandrio.business.tickets.control.Printer;
import pt.workshop.rockandrio.business.tickets.entity.Ticket;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Stateless
@Interceptors(Audit.class)
public class TicketService {
    
    @Inject 
    Instance<Payment> p;
    
    @PersistenceContext
    EntityManager em;
    
    @Inject
    RockPrincipal rp;
    
    @Inject
    Event<String> ticketListeners;
    
    @Resource
    SessionContext sc;
    
    @Inject
    Printer printer;
    
    @Inject
    Map<String,Object> cache;
    
    public String getSong(){
        for (Payment payment : p) {
            System.out.println("---- " + payment);
            payment.pay();
            ticketListeners.fire("metallica");
        }
        
        em.persist(new Ticket("sepultura"));
        sc.setRollbackOnly();
        return "seek and destroy (bloat) " + System.currentTimeMillis() + " " + rp + this.cache; 
    }

    public void print() {
        List<Future<String>> tickets = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            tickets.add(printer.print("heavy: "+ i));
        }
        for (Future<String> future : tickets) {
            try {
                System.out.println("######## " + future.get());
            } catch (InterruptedException ex) {
                Logger.getLogger(TicketService.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ExecutionException ex) {
                Logger.getLogger(TicketService.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
