/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.workshop.rockandrio.business.security.boundary;

import java.security.Principal;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import pt.workshop.rockandrio.business.security.entity.RockPrincipal;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class SecurityProvider {
    
    @Inject
    Principal principal;
    
    @Produces
    public RockPrincipal principal(){
        return new RockPrincipal(principal.getName(), "adminstrator (comes from database)");
    }
}
