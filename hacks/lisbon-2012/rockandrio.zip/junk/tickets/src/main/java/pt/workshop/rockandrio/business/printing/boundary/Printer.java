package pt.workshop.rockandrio.business.printing.boundary;

import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class Printer {

    public void print(@Observes(during= TransactionPhase.AFTER_SUCCESS) String bandName){
        System.out.println("++++++++++ printing: " + bandName);
    }

    public void destroy(@Observes(during= TransactionPhase.AFTER_FAILURE) String bandName){
        System.out.println("Destroying: " + bandName);
    }
}
