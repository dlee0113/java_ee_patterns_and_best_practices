package pt.workshop.rockandrio.business.configurator.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.faces.application.ProjectStage;
import pt.workshop.rockandrio.business.tickets.boundary.Global;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class Configurator {


    @Produces
    public String getString(InjectionPoint ip,ProjectStage stage){
        Class clazz = ip.getMember().getDeclaringClass();
        String fieldName = ip.getMember().getName();
        return stage.name() + " " +clazz.getName() + "." + fieldName;
    }

    @Produces @Global
    public String getString(){
        return "42";
    }   
    
}
