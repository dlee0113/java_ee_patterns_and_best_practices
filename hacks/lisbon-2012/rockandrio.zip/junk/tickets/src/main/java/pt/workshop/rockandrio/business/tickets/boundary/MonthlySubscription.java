/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.workshop.rockandrio.business.tickets.boundary;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Schedule;
import javax.ejb.ScheduleExpression;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.enterprise.event.Observes;
import javax.servlet.AsyncContext;

@Startup
@Singleton
public class MonthlySubscription {
    @Resource
    TimerService ts;

    private List<AsyncContext> windows;
    
    private Timer timer;
    
    @PostConstruct
    public void onStart(){
        System.out.println("### some initializatio");
        ScheduleExpression se = new ScheduleExpression();
        se.minute("*").second("*/5").hour("*");
        this.timer =  ts.createCalendarTimer(se);
        this.windows = new ArrayList<>();
    }

    public void onNewBrowser(@Observes AsyncContext ac){
        this.windows.add(ac);
    
    }
    
    @Timeout
    public void buyTicket(){
        System.out.println("---- invoked: " + new Date());
        for (AsyncContext asyncContext : windows) {
            try {
                asyncContext.getResponse().getWriter().println("---- invoked: " + new Date());
                asyncContext.complete();
            } catch (IOException ex) {
                Logger.getLogger(MonthlySubscription.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        this.windows.clear();
                
    }
}
