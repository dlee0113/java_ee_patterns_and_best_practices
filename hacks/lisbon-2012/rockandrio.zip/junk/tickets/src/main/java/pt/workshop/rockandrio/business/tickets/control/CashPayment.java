package pt.workshop.rockandrio.business.tickets.control;

import javax.ejb.Stateless;
import javax.inject.Inject;
import pt.workshop.rockandrio.business.tickets.boundary.Global;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class CashPayment implements Payment {
    
    @Inject
    private String msg;

    @Inject
    private String loudness;
    
    @Inject @Global
    private String numberOfTickets;
    
    @Override
    public void pay(){
        System.out.println(msg + loudness +" " + numberOfTickets);
    }
    
}
