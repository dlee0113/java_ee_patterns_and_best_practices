package pt.workshop.rockandrio.business.tickets.boundary;

import java.net.URI;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Validator;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import pt.workshop.rockandrio.business.tickets.entity.Ticket;

@Path("tickets")
@Stateless
@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
public class TicketsResource {

    @Inject
    Validator validator;

    @GET
    public Ticket hello() {
        return new Ticket("rock and rio");
    }

    @GET
    @Path("{id}")
    public Ticket getTicket(@PathParam("id") long id) {
        return new Ticket("ticket with id: " + id);
    }

    @POST
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response buy(Ticket ticket) {
        if (!validator.validate(ticket, new Class[]{}).isEmpty()) {
            System.out.println("NOT VALID!!!! ");
            return Response.status(Response.Status.NOT_ACCEPTABLE).build();
        } else {
            System.out.println("--- got ticket!: " + ticket);
            URI create = URI.create("id" + ticket.getId());
            return Response.created(create).build();
        }
    }
}
