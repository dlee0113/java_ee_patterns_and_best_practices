package pt.workshop.rockandrio.business.cache.boundary;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Singleton;
import javax.enterprise.inject.Produces;

@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class CacheIntegrator {
    
    private Map<String,Object> cache;
    
    @PostConstruct
    public void initialize(){
        this.cache = new ConcurrentHashMap<>();
    }
    
    @Produces
    public Map<String,Object> expose(){
        return this.cache;
    }
    
}
