/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.workshop.rockandrio.business.configurator.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.Specializes;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.faces.application.ProjectStage;
import pt.workshop.rockandrio.business.tickets.boundary.Global;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class DBConfigurator extends Configurator{

    @Override @Specializes @Produces
    public String getString(InjectionPoint ip, ProjectStage stage) {
        return " from database";
    }

    @Override @Specializes @Produces @Global
    public String getString() {
        return " 21";
            
    }
    
}
