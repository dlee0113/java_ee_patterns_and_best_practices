package pt.workshop.rockandrio.business.tickets.boundary;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class Audit {

    @AroundInvoke
    public Object auditBuying(InvocationContext ic) throws Exception {
        long start = System.currentTimeMillis();
        try {
            System.out.println("--- " + ic.getMethod());
            return ic.proceed();
        } finally {
            System.out.println("---Ending: " + (System.currentTimeMillis() - start));
        }
    }
}
