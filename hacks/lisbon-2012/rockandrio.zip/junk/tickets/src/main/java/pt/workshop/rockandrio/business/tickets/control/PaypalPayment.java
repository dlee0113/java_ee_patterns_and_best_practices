/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.workshop.rockandrio.business.tickets.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class PaypalPayment implements Payment{

    @Override
    public void pay() {
        System.out.println("No!");
    }
    
}
