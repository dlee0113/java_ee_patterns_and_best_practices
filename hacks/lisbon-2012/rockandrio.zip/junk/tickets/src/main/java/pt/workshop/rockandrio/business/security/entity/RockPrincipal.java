/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.workshop.rockandrio.business.security.entity;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class RockPrincipal {
    
    private String name;
    private String roles;

    public RockPrincipal(String name, String roles) {
        this.name = name;
        this.roles = roles;
    }

    @Override
    public String toString() {
        return "RockPrincipal{" + "name=" + name + ", roles=" + roles + '}';
    }
    
    
   
}
