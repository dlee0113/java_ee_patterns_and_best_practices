/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.workshop.rockandrio.business.tickets.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
@Entity
public class Ticket {
    
    @Id
    @GeneratedValue
    private long id;
    
    @Size(min=1,max=5)
    @Column(name="c_name")
    private String name;

    public Ticket() {
    }

    public Ticket(String name) {
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }
    
    

    @Override
    public String toString() {
        return "Ticket{" + "id=" + id + ", name=" + name + '}';
    }
    
    
    
    
    
}
