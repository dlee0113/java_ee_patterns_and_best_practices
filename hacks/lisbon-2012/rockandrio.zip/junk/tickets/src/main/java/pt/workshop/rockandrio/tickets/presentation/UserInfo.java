/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.workshop.rockandrio.tickets.presentation;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;

/**
 *
 * @author adam bien, adam-bien.com
 */
@SessionScoped
public class UserInfo implements Serializable{
    private String name;
    
}
