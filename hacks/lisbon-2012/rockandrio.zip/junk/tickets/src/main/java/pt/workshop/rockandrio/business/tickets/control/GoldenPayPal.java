/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.workshop.rockandrio.business.tickets.control;

import javax.enterprise.inject.Specializes;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Specializes
public class GoldenPayPal extends PaypalPayment{

    @Override
    public void pay() {
        System.out.println("You are golden, of course!");
    }
    
}
