package pt.workshop.rockandrio.tickets.presentation;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.faces.application.ProjectStage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import pt.workshop.rockandrio.business.tickets.boundary.TicketService;

@Model
public class Index {
    
    @Inject
    TicketService ts;
    
    @Inject
    UserInfo info;
    
    @PostConstruct
    public void loadResources(){
        System.out.println("Loading!");
    }
    
    public String getTicket(){
        return "metallica " + ts.getSong();
    }
    
    public Object print(){
        ts.print();
        return null;
    }
    
    @Produces
    public ProjectStage stage(){
        return FacesContext.getCurrentInstance().getApplication().getProjectStage();
    }
    
}
