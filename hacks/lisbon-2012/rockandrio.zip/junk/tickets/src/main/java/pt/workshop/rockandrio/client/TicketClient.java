/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.workshop.rockandrio.client;

import com.sun.jersey.api.client.Client;
import javax.ws.rs.core.MediaType;
import pt.workshop.rockandrio.business.tickets.entity.Ticket;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class TicketClient {
    
    //change jersey scope to compile to try that!
    public static void main(String[] args) {
        Client client = Client.create();
        Ticket ticket = client.resource("http://localhost:8080/tickets/v1/tickets/").accept(MediaType.APPLICATION_XML).get(Ticket.class);
        System.out.println("Ticket: " + ticket);
        
    }
}
