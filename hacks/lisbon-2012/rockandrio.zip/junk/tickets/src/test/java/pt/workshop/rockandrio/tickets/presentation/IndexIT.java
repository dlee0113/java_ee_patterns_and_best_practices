/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.workshop.rockandrio.tickets.presentation;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class IndexIT {
    
    @Test
    public void integration(){
        fail("for fun");
    }
}
