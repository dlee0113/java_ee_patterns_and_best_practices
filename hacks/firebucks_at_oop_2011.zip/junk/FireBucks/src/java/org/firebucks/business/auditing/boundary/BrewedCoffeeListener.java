/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.firebucks.business.auditing.boundary;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.*;
import javax.enterprise.event.Observes;
import org.firebucks.business.ordering.entity.Coffee;

/**
 *
 * @author adam bien, blog.adam-bien.com
 */
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
@Singleton
public class BrewedCoffeeListener {
   
    
    private CopyOnWriteArrayList<Coffee> toBrew = new CopyOnWriteArrayList<Coffee>();
    
    @Asynchronous
    public void onBrewedCoffee(@Observes Coffee coffee){
        toBrew.add(coffee);
        System.out.println("---- Audited! " + coffee);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(BrewedCoffeeListener.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("----After");
    }
    
    @Schedule(hour="*",minute="*",second="*/5")
    public void brew(){
        System.out.println("--- " + toBrew + new Date());
    }
}
