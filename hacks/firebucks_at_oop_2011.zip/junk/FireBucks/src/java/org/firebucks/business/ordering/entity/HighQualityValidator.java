/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.firebucks.business.ordering.entity;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 *
 * @author adam bien, blog.adam-bien.com
 */
public class HighQualityValidator implements ConstraintValidator<HighQuality, java.lang.String> {
    private HighQuality annotation;
    
    @Override
    public void initialize(HighQuality annotation) {
        this.annotation = annotation;
    }
    
    @Override
    public boolean isValid(java.lang.String value, ConstraintValidatorContext context) {
        return annotation.value().equalsIgnoreCase(value);
    }
}
