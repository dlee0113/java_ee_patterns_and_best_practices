/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.firebucks.business.ordering.control;

import org.firebucks.business.ordering.entity.Coffee;

/**
 *
 * @author adam bien, blog.adam-bien.com
 */
public interface Filter {
    
    public Coffee filter(Coffee coffee);
    
}
