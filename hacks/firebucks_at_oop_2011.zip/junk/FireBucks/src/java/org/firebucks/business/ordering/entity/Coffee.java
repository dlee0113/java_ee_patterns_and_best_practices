package org.firebucks.business.ordering.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author adam bien, blog.adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
@Entity
public class Coffee {
    
    @Id
    @GeneratedValue
    private long id;
    
    @Size(min=2,max=5)
    @HighQuality("bla")
    private String name;
    
    @XmlTransient
    private boolean withCream;

    
    
    
    
    public Coffee() {
    }

    public Coffee(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Coffee{" + "id=" + id + ", name=" + name + ", withCream=" + withCream + '}';
    }

    
}
