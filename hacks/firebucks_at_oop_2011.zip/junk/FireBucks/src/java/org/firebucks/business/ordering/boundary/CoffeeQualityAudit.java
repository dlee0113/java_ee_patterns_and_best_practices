package org.firebucks.business.ordering.boundary;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam bien, blog.adam-bien.com
 */

public class CoffeeQualityAudit {

    @AroundInvoke
    public Object measure(InvocationContext ic) throws Exception{
        System.out.println("---" + ic.getMethod());
        return ic.proceed();
    }
}
