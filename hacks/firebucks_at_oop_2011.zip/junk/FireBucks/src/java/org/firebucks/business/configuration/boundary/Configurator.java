/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.firebucks.business.configuration.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam bien, blog.adam-bien.com
 */
public class Configurator {
    
    @Produces
    public String configure(InjectionPoint ip){
        String name = ip.getMember().getDeclaringClass().getName();
        return name + "." + ip.getMember().getName();
    }
    
}
