package org.firebucks.business.ordering.boundary;

import java.net.URI;
import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.print.attribute.standard.Media;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.firebucks.business.ordering.control.Filter;
import org.firebucks.business.ordering.control.Heater;
import org.firebucks.business.ordering.entity.Coffee;

/**
 *
 * @author adam bien, blog.adam-bien.com
 */
@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
@Path("coffees")
@Stateless
@Interceptors(CoffeeQualityAudit.class)
public class OrderService {
    
    @PersistenceContext
    EntityManager em;
    
    @Inject
    Heater heater;
    
    
    @Inject
    Event<Coffee> auditor;
    
    @Inject @Any
    Instance<Filter> filter;
    
    @PostConstruct
    public void init(){
        System.out.println("ManagedBean created");
    }
    
    
    @GET
    @Path("{color}-{temp}")
    public Coffee get(@PathParam("color") String color,@PathParam("temp") int temp){
        return new Coffee("black" +color + temp);
    }
    
    
    @POST
    public Response storeCoffee(Coffee coffee){
        for (Filter f : filter) {
            System.out.println("F: " + f);
        }

        coffee = heater.heat(coffee);
        coffee = em.merge(coffee);
        auditor.fire(coffee);
        System.out.println("Stored!--- " + coffee);
        URI uri = URI.create(""+coffee.getId());
        return Response.created(uri).build();
    }
}
