package org.firebucks.presentation;

import java.io.Serializable;
import javax.ejb.EJB;
import javax.enterprise.inject.Model;
import javax.inject.Inject;
import org.firebucks.business.ordering.boundary.OrderService;
import org.firebucks.business.ordering.entity.Coffee;

//@StatefulModel
@Model
public class Index implements Serializable{
    
    @Inject
    OrderService os;
    
    private Coffee coffee = new Coffee();

    public Coffee getCoffee() {
        return coffee;
    }
    
    
    
    public void order(){
        this.os.storeCoffee(coffee);
        //return null;
    }
}
