package org.firebucks.business.ordering.control;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.firebucks.business.ordering.entity.Coffee;

/**
 *
 * @author adam bien, blog.adam-bien.com
 */
public class Heater {
 
    @PersistenceContext
    EntityManager em;
    
    private String message;

    public Heater(String message) {
        this.message = message;
    }
    
    
    
    public Coffee heat(Coffee coffee){
//        coffee.setName("bla");
        System.out.println( message + "? " + em);
        return coffee;
    }
}
