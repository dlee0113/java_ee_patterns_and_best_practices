/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package diexplanation;

import java.lang.reflect.Field;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class DIExplanation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        Class<?> clazz = Class.forName("diexplanation.View");
        Field[] declaredFields = clazz.getDeclaredFields();
        for (Field field : declaredFields) {
            if(field.isAnnotationPresent(PleaseInject.class)){
                System.out.println("---- Found it: " + field.getName());
                field.setAccessible(true);
                field.set(clazz.newInstance(), new Controller());
            }
        }
    }
}
