/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nl.interaccess.configuration.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class Configurator {

    @Produces
    public String getString(InjectionPoint ip){
        String fieldName = ip.getMember().getName();
        Class<?> clazz = ip.getMember().getDeclaringClass();
        final String value = "-- " + clazz.getName() + "."+fieldName;
        System.out.println(value);
        return value;
    }
}
