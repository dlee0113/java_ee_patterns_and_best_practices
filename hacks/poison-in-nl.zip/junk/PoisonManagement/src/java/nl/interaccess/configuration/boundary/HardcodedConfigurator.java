package nl.interaccess.configuration.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.Specializes;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class HardcodedConfigurator extends Configurator{
    
    @Override @Produces @Specializes
    public String getString(InjectionPoint ip) {
        return "duke";
    }
    
}
