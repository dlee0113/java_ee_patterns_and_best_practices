/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nl.interaccess.audit;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class PerformanceWatch {
    
    @AroundInvoke
    public Object measure(InvocationContext ic) throws Exception{
        long start = System.currentTimeMillis();
        try{
        return ic.proceed();
        }finally{
            System.out.println("*** " + ic.getMethod() + " exec in: " + (System.currentTimeMillis()-start));
        }
    }
    
}
