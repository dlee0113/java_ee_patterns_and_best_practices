/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nl.interaccess.poisonmgmt.control;

import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class GraveDigger {
        public void onDrinkingEvent(@Observes(during= TransactionPhase.AFTER_SUCCESS) @Category(Category.Type.PESSIMISTIC) Boolean result){
        System.out.println("---:-(?: " + result);
    }

}
