package nl.interaccess.poisonmgmt.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class PoisonDetector {

    public boolean isDetected(){
        return true;
    }
}
