package nl.interaccess.poisonmgmt.presentation;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Model;
import javax.inject.Inject;
import javax.inject.Named;
import nl.interaccess.poisonmgmt.boundary.PoisonAnihilator;

@Model
public class Index {

    @Inject
    PoisonAnihilator pa;

    @PostConstruct
    public void doesNotMatter(){
        System.out.println("created!");
    }
    
    public String getPoison(){
        return pa.poison();
    }
    
    
    public Object drinking(){
        pa.drinkJenever();
        return "healtcheck";
    }
}
