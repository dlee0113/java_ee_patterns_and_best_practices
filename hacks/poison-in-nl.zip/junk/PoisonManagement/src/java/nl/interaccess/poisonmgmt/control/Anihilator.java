/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nl.interaccess.poisonmgmt.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
public interface Anihilator {
    
    public void remove();
}
