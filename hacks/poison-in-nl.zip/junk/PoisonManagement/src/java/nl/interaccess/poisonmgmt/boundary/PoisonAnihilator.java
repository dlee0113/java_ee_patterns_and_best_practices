package nl.interaccess.poisonmgmt.boundary;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import nl.interaccess.audit.PerformanceWatch;
import nl.interaccess.poisonmgmt.control.Anihilator;
import nl.interaccess.poisonmgmt.control.Drinker;
import nl.interaccess.poisonmgmt.control.PoisonDetector;
import nl.interaccess.poisonmgmt.entity.Poison;

@Interceptors(PerformanceWatch.class)
@Stateless
public class PoisonAnihilator {
    
    @Inject
    PoisonDetector detector;
    
    @PersistenceContext
    EntityManager em;
    
    @Inject
    Drinker drinker;
    
    @Inject
    Instance<Anihilator>anihilator;
    
    @PostConstruct
    public void onCreation(){
        System.out.println("EJB created!");
    }
   
    public String poison(){
        em.persist(new Poison("jenever"));
        for (Anihilator a : anihilator) {
            a.remove();
            System.out.println("--- " + a);
        }
        
        return "jenever is poison: " + detector.isDetected();
    }

    public void drinkJenever() {
        for (int i = 0; i < 5; i++)
            drinker.drink();
            
    }
}
