/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nl.interaccess.poisonmgmt.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class AtomicAnihilator implements Anihilator{

    @Override
    public void remove() {
        System.out.println("Remove!");
    }
    
}
