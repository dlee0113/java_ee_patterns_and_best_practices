package nl.interaccess.poisonmgmt.boundary;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import nl.interaccess.poisonmgmt.entity.Poison;

@Path("poisons")
@Stateless
@Produces(MediaType.APPLICATION_XML)
public class PoisonsResource {
    
    @GET
    public List<Poison> poisons(){
        List<Poison> poisons = new ArrayList<Poison>(){{
            add(new Poison("jenever"));
            add(new Poison("cognac"));
        }};
        return poisons;
    }
    @GET
    @Path("{id}-{name}")
    public Poison poison(@PathParam("id") long id,@PathParam("name")String name){
        return new Poison(" " + id + name);
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_XML)
    public Response create(Poison poison){
        System.out.println("##### " + poison);
        URI uri = URI.create("/42");
        return Response.created(uri).header("hot", "stuff").build();
    }
}
