/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nl.interaccess.poisonmgmt.control;

import java.util.concurrent.Future;
import javax.annotation.Resource;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Stateless
public class Drinker {

    @Inject @Category(Category.Type.PESSIMISTIC)
    Event<Boolean> resultSink;
    
    @Resource
    SessionContext sc;
    
    @Asynchronous
    public void drink() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
        }
        resultSink.fire(Boolean.TRUE);
        //sc.setRollbackOnly();
    }
}
