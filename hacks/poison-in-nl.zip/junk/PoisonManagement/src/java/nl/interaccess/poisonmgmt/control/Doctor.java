package nl.interaccess.poisonmgmt.control;

import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

public class Doctor {

    
    public void onDrinkingEvent(@Observes(during= TransactionPhase.AFTER_SUCCESS) @Category(Category.Type.OPTIMISTIC) Boolean result){
        System.out.println("---Nice!! :-): " + result);
    }

    public void anotherWatcher(@Observes(during= TransactionPhase.AFTER_FAILURE) Boolean result){
        System.out.println("####Rollback?: " + result);
    }
}
