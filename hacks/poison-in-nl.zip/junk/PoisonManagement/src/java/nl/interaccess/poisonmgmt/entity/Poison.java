package nl.interaccess.poisonmgmt.entity;

import java.beans.Transient;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Poison {
    
    @Id
    @GeneratedValue
    @XmlTransient
    private long id;
    private String name;

    public Poison() {
    }

    public Poison(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Poison{" + "id=" + id + ", name=" + name + '}';
    }
    
    
    
    
}
