package nl.interaccess.poisonmgmt.control;

import java.util.Date;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.*;
import javax.inject.Inject;

@Startup
@Singleton
public class AirSensor {
    
    @Resource
    TimerService ts;

    private Timer timer;
    
    @Inject
    private String seconds;

    @Inject
    private String alerts;
    
    @PostConstruct
    public void onStart(){
        ScheduleExpression se = new ScheduleExpression();
        se.hour("*").minute("*").second("*/30");
        this.timer = ts.createCalendarTimer(se);
    }

    @Timeout
    public void takeProbe(){
        System.out.println("--no jenever in the air " + new Date() + seconds + "###" + alerts);
    }
}
