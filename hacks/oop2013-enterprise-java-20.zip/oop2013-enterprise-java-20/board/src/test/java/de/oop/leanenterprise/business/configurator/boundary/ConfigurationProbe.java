/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.oop.leanenterprise.business.configurator.boundary;

import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class ConfigurationProbe {

    @Inject
    String name;

    public String getName() {
        return this.name;
    }
}
