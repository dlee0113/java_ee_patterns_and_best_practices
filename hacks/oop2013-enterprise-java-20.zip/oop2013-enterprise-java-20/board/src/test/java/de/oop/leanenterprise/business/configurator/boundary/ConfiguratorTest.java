/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.oop.leanenterprise.business.configurator.boundary;

import javax.inject.Inject;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;

/**
 *
 * @author adam-bien.com
 */
@RunWith(Arquillian.class)
public class ConfiguratorTest {

    @Inject
    ConfigurationProbe cp;

    @Deployment
    public static WebArchive create() {
        return ShrinkWrap.create(WebArchive.class).
                addClasses(Configurator.class, Stage.class, TestStageProvider.class, ConfigurationProbe.class).
                addAsWebInfResource(EmptyAsset.INSTANCE, "beans.xml");
    }

    @Test
    public void configurationWorks() {
        String name = cp.getName();
        System.out.println("--- " + name);
    }
}
