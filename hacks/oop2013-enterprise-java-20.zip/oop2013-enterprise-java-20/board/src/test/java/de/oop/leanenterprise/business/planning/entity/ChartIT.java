package de.oop.leanenterprise.business.planning.entity;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author adam-bien.com
 */
public class ChartIT {

    private EntityManager em;
    private EntityTransaction tx;

    @Before
    public void initializeEM() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("integration-test");
        this.em = emf.createEntityManager();
        this.tx = this.em.getTransaction();
    }

    @Test
    public void mapping() {
        this.tx.begin();
        this.em.merge(new Chart(42));
        this.tx.commit();
        List results = this.em.createNamedQuery(Chart.findAll).getResultList();
        assertFalse(results.isEmpty());
    }
}
