package de.oop.leanenterprise.business.planning.boundary;

import de.oop.leanenterprise.business.planning.control.ProjectManager;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Before;

/**
 *
 * @author adam-bien.com
 */
public class PlannerTest {

    Planner cut;
    ProjectManager pm;

    @Before
    public void inject() {
        this.cut = new Planner();
        this.cut.pm = mock(ProjectManager.class);
    }

    @Test(expected = IllegalStateException.class)
    public void test() {
        when(this.cut.pm.valid(42)).thenReturn(false);
        this.cut.setProgress(42);
    }
}
