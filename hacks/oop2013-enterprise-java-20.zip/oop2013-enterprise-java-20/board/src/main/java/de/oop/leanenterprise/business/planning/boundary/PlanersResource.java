package de.oop.leanenterprise.business.planning.boundary;

import de.oop.leanenterprise.business.planning.entity.Chart;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Validator;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.apache.catalina.HttpResponse;

@Stateless
@Path("planners")
@Produces(MediaType.TEXT_PLAIN)
public class PlanersResource {

    @Inject
    Planner planner;

    @GET
    public String planners(@Context HttpServletResponse response) {
        return planner.getProgress();
    }

    @GET
    @Path("{first}-{last}")
    public String getPlanner(@PathParam("first") String first, @PathParam("last") String last) {
        return first + last + "works";
    }
}
