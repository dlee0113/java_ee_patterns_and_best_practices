package de.oop.leanenterprise.business.configurator.boundary;

/**
 *
 * @author adam-bien.com
 */
public enum Stage {

    PROD, TEST;
}
