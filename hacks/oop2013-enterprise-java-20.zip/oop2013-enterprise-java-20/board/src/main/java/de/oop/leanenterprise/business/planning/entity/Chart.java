package de.oop.leanenterprise.business.planning.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
@Entity
@NamedQueries({
    @NamedQuery(name = Chart.findAll, query = "select c from Chart c")
})
public class Chart {

    private static final String PREFIX = "de.oop.leanenterprise.business.planning.entity.Chart.";
    public final static String findAll = PREFIX + "findAll";
    @Id
    @GeneratedValue
    private long id;
    private int velocity;

    public Chart() {
    }

    public Chart(int velocity) {
        this.velocity = velocity;
    }
}
