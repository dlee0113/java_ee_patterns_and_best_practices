/**
 * Planning component is crucial for lean enterprises.
 */
package de.oop.leanenterprise.business.planning;
