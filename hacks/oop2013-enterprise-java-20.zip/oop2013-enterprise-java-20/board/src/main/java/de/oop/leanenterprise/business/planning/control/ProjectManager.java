package de.oop.leanenterprise.business.planning.control;

/**
 *
 * @author adam-bien.com
 */
public class ProjectManager {

    public boolean valid(int velocity) {
        return (42 == velocity);
    }
}
