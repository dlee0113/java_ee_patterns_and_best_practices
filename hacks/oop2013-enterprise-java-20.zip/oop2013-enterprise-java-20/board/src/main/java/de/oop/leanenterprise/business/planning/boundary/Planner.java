package de.oop.leanenterprise.business.planning.boundary;

import de.oop.leanenterprise.business.planning.control.ProjectManager;
import javax.ejb.Stateless;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class Planner {

    private static long counter = 0;
    @Inject
    ProjectManager pm;
    @Inject
    String message;

    public String getProgress() {
        return message + (counter++);
    }

    public void setProgress(int progress) {
        if (!pm.valid(progress)) {
            throw new IllegalStateException("You are too slow");
        }
    }
}
