package de.oop.leanenterprise.business.configurator.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam-bien.com
 */
public class Configurator {

    @Produces
    public String produce(InjectionPoint ip, Stage stage) {
        String clazz = ip.getMember().getDeclaringClass().getName();
        String name = ip.getMember().getName();

        return "20 degreees " + clazz + "." + name + " -- " + stage;
    }
}
