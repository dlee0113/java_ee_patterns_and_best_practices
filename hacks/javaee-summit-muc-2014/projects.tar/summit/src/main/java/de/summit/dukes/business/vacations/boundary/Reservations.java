package de.summit.dukes.business.vacations.boundary;

import de.summit.dukes.business.vacations.control.Validator;
import java.util.function.Consumer;
import javax.ejb.Stateless;
import javax.inject.Inject;

@Stateless
public class Reservations {

    @Inject
    Validator validator;

    @Inject
    Consumer<String> LOG;

    public boolean reserve(String name) {
        LOG.accept("got parameter: " + name);
        if (!validator.check(name)) {
            throw new IllegalArgumentException("Not valid!!!");
        }
        return ("duke".equalsIgnoreCase(name));
    }

}
