package de.summit.dukes.business.logger.boundary;

import java.util.function.Consumer;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author airhacks.com
 */
public class LogManager {

    @Produces
    public Consumer<String> expose(InjectionPoint ip) {
        //Logger logger = Logger.getLogger(ip.getMember().getDeclaringClass().getName());
        return System.out::println;//logger::info;
    }
}
