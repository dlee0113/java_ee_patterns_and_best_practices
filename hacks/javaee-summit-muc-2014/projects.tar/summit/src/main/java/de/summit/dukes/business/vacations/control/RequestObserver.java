package de.summit.dukes.business.vacations.control;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.enterprise.event.Observes;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
@Stateless
public class RequestObserver {

    @Inject
    RegistrationQuery query;

    @Resource
    ManagedExecutorService mes;

    public void onNewRequest(@Observes Consumer<Object> consumer) {
        CompletableFuture.supplyAsync(query::all, mes).thenAccept(consumer);
    }

}
