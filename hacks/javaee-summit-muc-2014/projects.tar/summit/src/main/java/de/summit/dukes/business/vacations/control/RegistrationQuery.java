package de.summit.dukes.business.vacations.control;

import de.summit.dukes.business.vacations.entity.Reservation;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author airhacks.com
 */
public class RegistrationQuery {

    public List<Reservation> all() {
        List<Reservation> list = new ArrayList<Reservation>() {
            {
                add(new Reservation("duke", 42));
                add(new Reservation("chief", 21));
            }
        };
        return list;
    }

}
