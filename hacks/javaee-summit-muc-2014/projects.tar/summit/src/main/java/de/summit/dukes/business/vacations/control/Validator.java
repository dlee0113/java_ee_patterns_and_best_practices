package de.summit.dukes.business.vacations.control;

/**
 *
 * @author airhacks.com
 */
public class Validator {

    public boolean check(String name) {
        return name != null;
    }
}
