package de.summit.dukes.business.vacations.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author airhacks.com
 */
@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Reservation {

    @Id
    @GeneratedValue
    private long id;

    @XmlElement(name = "firstName")
    private String name;

    private long timestamp;

    public Reservation(String name, long timestamp) {
        this.name = name;
        this.timestamp = timestamp;
    }

    public Reservation() {
    }

    @Override
    public String toString() {
        return "Reservation{" + "name=" + name + ", timestamp=" + timestamp + '}';
    }

    public String getName() {
        return name;
    }

    public long getTimestamp() {
        return timestamp;
    }

}
