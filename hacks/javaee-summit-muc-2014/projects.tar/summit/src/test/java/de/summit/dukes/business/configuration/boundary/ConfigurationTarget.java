package de.summit.dukes.business.configuration.boundary;

import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
public class ConfigurationTarget {

    @Inject
    String duke;

    public String getDuke() {
        return duke;
    }

}
