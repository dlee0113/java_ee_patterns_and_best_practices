package de.summit.dukes.business.configuration.boundary;

import javax.inject.Inject;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.Archive;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import static org.junit.Assert.assertTrue;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 *
 * @author airhacks.com
 */
@RunWith(Arquillian.class)
public class ConfiguratorIT {

    @Inject
    ConfigurationTarget ct;

    @Deployment
    public static Archive create() {
        return ShrinkWrap.create(JavaArchive.class).
                addClasses(ConfigurationTarget.class, Configurator.class).
                addAsManifestResource(EmptyAsset.INSTANCE, "beans.xml");
    }

    @Test
    public void keyComputedProperly() {
        String actual = ct.getDuke();
        System.out.println("--- " + actual);
        assertTrue(actual.contains("duke"));

    }

}
