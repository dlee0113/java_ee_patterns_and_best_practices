package de.summit.dukes.business.vacations.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.junit.Test;

/**
 *
 * @author airhacks.com
 */
public class ReservationTest {

    @Test
    public void query() {
        List<Reservation> reservations = new ArrayList<>();
        reservations.add(new Reservation("duke", 1));
        reservations.add(new Reservation("duchess", 2));

        List<String> list = reservations.parallelStream().filter(t -> t.getTimestamp() < 2).map(r -> r.getName()).collect(Collectors.toList());
        System.out.println("List: " + list);
    }

}
