package de.summit.dukes.business.vacations.boundary;

import de.summit.dukes.business.vacations.control.Validator;
import java.util.function.Consumer;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 *
 * @author airhacks.com
 */
public class ReservationsTest {

    Reservations cut;

    @Before
    public void inject() {
        this.cut = new Reservations();
        this.cut.validator = mock(Validator.class);
        this.cut.LOG = mock(Consumer.class);
    }

    @Test
    public void succesfullRegistration() {
        final String input = "duke";
        when(this.cut.validator.check(input)).thenReturn(true);
        boolean result = this.cut.reserve(input);
        assertTrue(result);
    }

    @Test(expected = IllegalArgumentException.class)
    public void incorrectReservation() {
        when(this.cut.validator.check(null)).thenReturn(false);
        this.cut.reserve(null);
    }

}
