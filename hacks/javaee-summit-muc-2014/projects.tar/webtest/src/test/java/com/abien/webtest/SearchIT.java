package com.abien.webtest;

import java.net.MalformedURLException;
import org.jboss.arquillian.container.test.api.RunAsClient;
import org.jboss.arquillian.drone.api.annotation.Drone;
import org.jboss.arquillian.junit.Arquillian;
import static org.junit.Assert.assertTrue;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 *
 * @author adam-bien.com
 */
@RunAsClient
@RunWith(Arquillian.class)
public class SearchIT {

    @Drone
    WebDriver page;

    @FindBy(tagName = "h3")
    WebElement element;

    @Test
    public void openAdminPage() throws MalformedURLException {
        page.get("http://localhost:8080");
        String title = page.getTitle();
        assertTrue(title.contains("WildFly"));
        String text = element.getText();
        assertTrue(text.contains("is running"));

    }
}
