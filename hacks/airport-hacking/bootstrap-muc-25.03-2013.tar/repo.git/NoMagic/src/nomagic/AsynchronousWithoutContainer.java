/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nomagic;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 *
 * @author adam-bien.com
 */
public class AsynchronousWithoutContainer {

    public static void main(String args[]) throws InterruptedException, ExecutionException {
        ExecutorService tp = Executors.newCachedThreadPool();
        Future<String> retVal = tp.submit(new Callable<String>() {
            public String call() {
                return "42";
            }
        });
        System.out.println(" " + retVal.get());


    }
}
