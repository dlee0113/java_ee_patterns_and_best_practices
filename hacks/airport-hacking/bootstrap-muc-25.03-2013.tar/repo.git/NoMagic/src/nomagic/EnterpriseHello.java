package nomagic;

public class EnterpriseHello {
}
