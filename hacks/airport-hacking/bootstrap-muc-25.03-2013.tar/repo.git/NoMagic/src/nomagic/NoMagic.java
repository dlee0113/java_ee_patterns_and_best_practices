/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nomagic;

import java.lang.reflect.Field;

/**
 *
 * @author adam-bien.com
 */
public class NoMagic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, IllegalAccessException {
        Class<?> clazz = Class.forName("nomagic.Index");
        Object newInstance = clazz.newInstance();
        
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            Airject annotation = field.getAnnotation(Airject.class);
            if (annotation != null) {
                Class<?> theOtherSide = field.getType();
                Object otherInstance = theOtherSide.newInstance();
                field.setAccessible(true);
                field.set(newInstance, otherInstance);
                System.out.println(" " + annotation.value() + " " + field);
            } else {
                System.out.println("No annotation: " + field);
            }
        }
        System.out.println("New instance: " + newInstance);
    }
}
