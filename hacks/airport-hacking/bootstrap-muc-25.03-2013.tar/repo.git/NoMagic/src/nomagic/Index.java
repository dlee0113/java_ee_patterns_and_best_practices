package nomagic;

public class Index {

    @Airject(true)
    private EnterpriseHello eh;
    String name;

    @Override
    public String toString() {
        return "Index{" + "eh=" + eh + ", name=" + name + '}';
    }
}
