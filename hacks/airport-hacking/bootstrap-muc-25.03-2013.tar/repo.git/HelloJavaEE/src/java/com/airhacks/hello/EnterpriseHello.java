package com.airhacks.hello;

import java.util.Date;
import java.util.concurrent.Future;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class EnterpriseHello {

    @Inject
    @Compression(Compression.Level.LOW)
    Compressor compressor;
    @PersistenceContext(unitName = "masterdata")
    EntityManager em;
    @PersistenceContext(unitName = "operational")
    EntityManager operation;
    @Resource
    SessionContext sc;

    @PostConstruct
    public void onInitalize() {
        System.out.println("EnterpriseHello");
    }

    @Asynchronous
    public Future<String> performAsync() {
        return new AsyncResult<String>("42");
    }

    //begin
    public String sayHello() {
        //em.persist(new Feedback());
        Feedback merge = em.merge(new Feedback("duke", "confused"));
        merge.setAttendeeName("james");
        compressor.compress();
        em.flush();
        em.clear();
        //sc.setRollbackOnly();
        return "Good morning: " + new Date();
    }//commit

    @PreDestroy
    public void destroy() {
        System.out.println("---EJB Destroying");
    }

    public void save(Feedback feedback) {
        this.em.merge(feedback);
    }
}
