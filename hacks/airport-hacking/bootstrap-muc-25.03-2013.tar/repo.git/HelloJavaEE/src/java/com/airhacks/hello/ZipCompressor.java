package com.airhacks.hello;

/**
 *
 * @author adam-bien.com
 */
@Compression(Compression.Level.LOW)
public class ZipCompressor implements Compressor {

    @Override
    public void compress() {
        System.out.println("Zipping");
    }
}
