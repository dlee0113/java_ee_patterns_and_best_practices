/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks.hello;

/**
 *
 * @author adam-bien.com
 */
@Compression(Compression.Level.HIGH)
public class SevenZipCompressor implements Compressor {

    @Override
    public void compress() {
        System.out.println("Zipping seven times!");
    }
}
