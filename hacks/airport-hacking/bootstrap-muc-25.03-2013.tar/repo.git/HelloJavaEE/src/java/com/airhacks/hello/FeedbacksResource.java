package com.airhacks.hello;

import java.net.URI;
import javax.ejb.Stateless;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author adam-bien.com
 */
@Stateless
@Path("feedbacks")
@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
public class FeedbacksResource {

    @GET
    public Feedback doesntMatter(@Context HttpServletRequest hsr) {
        return new Feedback("duke", "ok");
    }

    @GET
    @Path("{id}")
    public Feedback byId(@PathParam("id") int id) {
        return new Feedback("duke " + id, "seems to work");
    }

    @POST
    public Response save(Feedback feedback) {
        System.out.println("Got feedback " + feedback);
        URI uri = URI.create("/42");
        return Response.created(uri).header("X-some-info", "here is it").build();
    }
}
