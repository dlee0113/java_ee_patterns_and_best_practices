package com.airhacks.hello;

import java.util.Set;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Model;
import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

/**
 *
 * @author adam-bien.com
 */
@Named("airhacks")
@RequestScoped
public class Index {

    @Inject
    EnterpriseHello doesntMatter;
    private Feedback feedback;
    @Inject
    Validator validator;

    @PostConstruct
    public void onInitalize() {
        System.out.println("Index");
        this.feedback = new Feedback();
    }

    public Feedback getFeedback() {
        return feedback;
    }

    public String getHello() {
        return doesntMatter.sayHello();
    }

    @PreDestroy
    public void destroy() {
        System.out.println("---IndexDestroying");
    }

    public Object save() {
        System.out.println("Feedback: " + feedback);
        this.doesntMatter.save(this.feedback);
        return null;
    }
}
