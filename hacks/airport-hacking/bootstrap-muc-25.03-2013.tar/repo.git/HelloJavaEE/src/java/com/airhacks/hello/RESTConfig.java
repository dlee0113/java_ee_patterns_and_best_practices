package com.airhacks.hello;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author adam-bien.com
 */
@ApplicationPath("resources")
public class RESTConfig extends Application {
}
