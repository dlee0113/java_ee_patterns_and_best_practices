/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks.hello;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 *
 * @author adam-bien.com
 */
public class CommentValidator implements ConstraintValidator<Comment, String> {

    private Comment annotation;

    @Override
    public void initialize(Comment annotation) {
        this.annotation = annotation;
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return (value.contains(annotation.expectedMessage()));
    }
}
