package com.airhacks.hello;

import java.util.Date;
import javax.annotation.PostConstruct;
import javax.ejb.AccessTimeout;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.DependsOn;
import javax.ejb.Lock;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
public class TimerBean {

    @PostConstruct
    public void onInit() {
        System.out.println("On init 21!");
    }

//    @Schedule(hour = "*", second = "*/2", minute = "*")
    public void execPeriodically() {
        System.out.println("Each 2 secs: " + new Date());

    }
}
