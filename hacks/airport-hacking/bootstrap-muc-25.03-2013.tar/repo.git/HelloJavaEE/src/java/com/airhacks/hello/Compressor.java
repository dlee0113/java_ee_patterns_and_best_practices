package com.airhacks.hello;

import java.io.Serializable;

/**
 *
 * @author adam-bien.com
 */
public interface Compressor extends Serializable {

    public void compress();
}
