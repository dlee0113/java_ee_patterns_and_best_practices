Hello Airhacks
Flywaydb.org
Liquibase

JSR-330 @Inject
JSR-299 CDI
JSR-316,317,318
JSR-303
JSR-250 Commons Annotations for Java

http://connectorz.adam-bien.com

Hessian Caucho

http://digester.adam-bien.com