/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package basicintegrationtest;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author adam-bien.com
 */
public class BasicIntegrationTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("BasicIntegrationTestPU");
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();

        tx.begin();
        em.merge(new Feedback());
        tx.commit();
    }
}
