/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package basicintegrationtest;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam-bien.com
 */
@Entity
@Table(name = "BLOGPOST")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Blogpost.findAll", query = "SELECT b FROM Blogpost b"),
    @NamedQuery(name = "Blogpost.findById", query = "SELECT b FROM Blogpost b WHERE b.id = :id"),
    @NamedQuery(name = "Blogpost.findByTitle", query = "SELECT b FROM Blogpost b WHERE b.title = :title")})
public class Blogpost implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ID")
    private Long id;
    @Column(name = "TITLE")
    private String title;

    public Blogpost() {
    }

    public Blogpost(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Blogpost)) {
            return false;
        }
        Blogpost other = (Blogpost) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "basicintegrationtest.Blogpost[ id=" + id + " ]";
    }
}
