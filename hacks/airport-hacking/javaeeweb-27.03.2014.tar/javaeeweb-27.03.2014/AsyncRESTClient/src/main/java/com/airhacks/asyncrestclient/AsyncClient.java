package com.airhacks.asyncrestclient;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.InvocationCallback;
import javax.ws.rs.client.WebTarget;

/**
 *
 * @author airhacks.com
 */
public class AsyncClient {

    public static void main(String[] args) {
        Client client = ClientBuilder.newClient();
        WebTarget mainTarget = client.target("http://open-dolphin.org/");
        mainTarget.request().async().get(new InvocationCallback<String>() {

            @Override
            public void completed(String rspns) {
                System.out.println("Got the data: " + rspns);
            }

            @Override
            public void failed(Throwable thrwbl) {

            }
        });
    }
}
