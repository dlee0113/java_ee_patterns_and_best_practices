igniter.fx
===========

0. Use recent JDK 8 (JavaFX is already in the classpath). You can use the build.sh to temporarily set the JAVA_HOME in the script
1. Build the project with mvn clean install
2. Start the application with java -jar ./target/[project.artifactId]-app.jar

See also: [http://afterburner.adam-bien.com](http://afterburner.adam-bien.com)