package com.airhacks.web;

import java.util.Date;
import javax.enterprise.inject.Model;

/**
 *
 * @author airhacks.com
 */
@Model
public class Index {

    public String getMessage() {
        return "Good Morning " + new Date();
    }
}
