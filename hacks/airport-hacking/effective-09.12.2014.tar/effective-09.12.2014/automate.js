#!/usr/bin/jjs -fv
$EXEC('ls -al');
print($OUT);
