package com.airhacks.xmas.business.gifts.boundary;

import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author airhacks.com
 */
public class GiftsResourceTest {

    private Client client;
    private WebTarget tut;

    @Before
    public void initClient() {
        this.client = ClientBuilder.newClient();
        this.tut = this.client.target("http://localhost:8080/gifts/resources/gifts");
    }

    @Test
    public void crud() {
        Response response = this.tut.request(MediaType.APPLICATION_JSON).get();
        assertThat(response.getStatus(), is(200));

        JsonObject steamEngine = Json.createObjectBuilder().
                add("name", "steamengine").
                add("price", 42).
                build();
        response = this.tut.request().post(Entity.json(steamEngine));
        assertThat(response.getStatus(), is(201));
        String location = response.getHeaderString("Location");
        System.out.println("location = " + location);
        assertNotNull(location);

        JsonObject createdGift = this.client.
                target(location).
                request(MediaType.APPLICATION_JSON).
                get(JsonObject.class);
        assertNotNull(createdGift);
    }

}
