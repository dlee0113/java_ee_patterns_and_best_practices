package com.airhacks;

import java.util.function.Consumer;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;

@Path("flights")
@RequestScoped
public class FlightsInfo {

    @Inject
    Event<Consumer<Object>> events;

    @GET
    public void all(@Suspended AsyncResponse response) {
        events.fire(response::resume);
    }
}
