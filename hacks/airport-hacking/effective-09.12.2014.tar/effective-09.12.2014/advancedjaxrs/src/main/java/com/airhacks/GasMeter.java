package com.airhacks;

/**
 *
 * @author airhacks.com
 */
@Gas
public class GasMeter implements Meter {

    @Override
    public String measure() {
        return "2qm";
    }

}
