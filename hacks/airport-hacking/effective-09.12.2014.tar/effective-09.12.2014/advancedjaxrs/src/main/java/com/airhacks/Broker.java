package com.airhacks;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.annotation.Resource;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.enterprise.event.Observes;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
public class Broker {

    @Inject
    FlightMonitor monitor;

    @Resource
    ManagedExecutorService mes;

    public void onNewFlightRequest(@Observes Consumer<Object> listener) {
        Supplier<String> supplier = monitor::flightStatus;
        CompletableFuture.supplyAsync(supplier, mes).
                thenAccept(listener).
                exceptionally(new Function<Throwable, Void>() {

                    @Override
                    public Void apply(Throwable t) {
                        listener.accept("" + t.toString());
                        return null;
                    }
                });
    }

}
