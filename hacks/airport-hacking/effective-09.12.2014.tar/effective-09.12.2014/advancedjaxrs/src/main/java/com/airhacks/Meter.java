package com.airhacks;

/**
 *
 * @author airhacks.com
 */
public interface Meter {

    public String measure();

}
