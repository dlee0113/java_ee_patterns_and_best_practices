package com.airhacks;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

/**
 *
 * @author airhacks.com
 */
@Stateless
@Path("measurements")
public class MeasurementsResource {

    @Inject
    Meter meter;

    @GET
    public String measurements() {
        return meter.measure();
    }

}
