package com.airhacks;

/**
 *
 * @author airhacks.com
 */
@Energy
public class PowerMeter implements Meter {

    @Override
    public String measure() {
        return "2kwh";
    }

}
