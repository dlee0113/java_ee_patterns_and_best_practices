package com.airhacks;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

/**
 *
 * @author airhacks.com
 */
@Path("exceptions")
public class ExceptionsResource {

    @GET
    public String get() {
        throw new IllegalStateException("Nice!!");
    }

}
