package com.airhacks;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author airhacks.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Gift {

    private String name;

    public Gift(String name) {
        this.name = name;
    }

    public Gift() {
    }

    @Override
    public String toString() {
        return "Gift{" + "name=" + name + '}';
    }

}
