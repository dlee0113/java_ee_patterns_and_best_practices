package com.airhacks;

/**
 *
 * @author airhacks.com
 */
public class FlightMonitor {

    public String flightStatus() {
        throw new RuntimeException("Airport closed");
        //return "sfo,muc,fra,lon,umea";
    }

}
