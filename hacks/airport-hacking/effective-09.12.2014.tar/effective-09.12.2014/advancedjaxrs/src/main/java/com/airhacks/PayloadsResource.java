package com.airhacks;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author airhacks.com
 */
@Path("payloads")
public class PayloadsResource {

    @GET
    @Produces({"airhacks/binary", MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Gift get() {
        return new Gift("lego");
    }

}
