package com.airhacks.xmas.business.gift.control;

/**
 *
 * @author airhacks.com
 */
public class Scanner {

    public boolean isNaughty() {
        return false;
    }
}
