package com.airhacks.xmas.business.gift.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

/**
 *
 * @author airhacks.com
 */
@Entity
@NamedQuery(name = Gift.all, query = "SELECT g FROM Gift g")
public class Gift {

    @Id
    @GeneratedValue
    private long id;
    private String name;
    private int price;
    public final static String FQN = "com.airhacks.xmas.business.gift.entity.Gift";
    public final static String all = FQN + ".all";

    public Gift(String name, int price) {
        this.name = name;
        this.price = price;
    }

    public Gift() {
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public long getId() {
        return id;
    }

}
