package com.airhacks.xmas.business.configuration.control;

/**
 *
 * @author airhacks.com
 */
public class InMemoryConfigurator {

    public String get(String key) {
        return "from memory " + key;
    }
}
