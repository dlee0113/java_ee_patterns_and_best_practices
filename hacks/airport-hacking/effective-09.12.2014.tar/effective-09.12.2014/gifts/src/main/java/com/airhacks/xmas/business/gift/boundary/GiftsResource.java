package com.airhacks.xmas.business.gift.boundary;

import com.airhacks.xmas.business.gift.entity.Gift;
import java.net.URI;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.ws.rs.GET;
import javax.ws.rs.OPTIONS;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

/**
 *
 * @author airhacks.com
 */
@Stateless
@Path("gifts")
public class GiftsResource {

    @Inject
    Santa santa;

    @GET
    public JsonArray all() {
        JsonObject mindstorm = Json.createObjectBuilder().add("name", "mindstorms").build();
        JsonObject raspi = Json.createObjectBuilder().add("name", "raspi").build();
        return Json.createArrayBuilder().add(mindstorm).add(raspi).build();
    }

    @OPTIONS
    public JsonArray sample() {
        JsonObject mindstorm = Json.createObjectBuilder().add("name", "[PUT NAME HERE]").build();
        JsonObject raspi = Json.createObjectBuilder().add("name", "raspi").build();
        return Json.createArrayBuilder().add(mindstorm).add(raspi).build();
    }

    @GET
    @Path("{id}")
    public JsonObject find(@PathParam("id") long id) {
        return Json.createObjectBuilder().add("id", id).build();
    }

    @POST
    public Response save(JsonObject gift, @Context UriInfo info) {
        System.out.println("gift = " + gift);
        Gift giftEntity = convert(gift);
        santa.save(giftEntity);
        URI uri = info.getAbsolutePathBuilder().path("/" + System.currentTimeMillis()).build();

        return Response.created(uri).build();
    }

    Gift convert(JsonObject object) {
        final String name = object.getString("name");
        return new Gift(name, object.getInt("price"));
    }

}
