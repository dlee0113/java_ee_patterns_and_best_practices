package com.airhacks.xmas.business.gift.boundary;

import com.airhacks.xmas.business.gift.control.Scanner;
import com.airhacks.xmas.business.gift.entity.Gift;
import javax.ejb.Stateless;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
@Stateless
public class Santa {

    @Inject
    Scanner scanner;

    @Inject
    String message;

    public Gift save(Gift gift) {
        if (scanner.isNaughty()) {
            throw new IllegalStateException("Next xmas");
        }

        if (gift.getPrice() > 100) {
            throw new IllegalArgumentException("Price too high");
        }
        System.out.println(message + gift);
        return gift;
    }

}
