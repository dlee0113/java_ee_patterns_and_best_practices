package com.airhacks.xmas.business.configuration.boundary;

import com.airhacks.xmas.business.configuration.control.InMemoryConfigurator;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
public class Configurator {

    @Inject
    InMemoryConfigurator imc;

    @Produces
    public String expose(InjectionPoint ip) {
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String clazzName = clazz.getName();
        String name = ip.getMember().getName();
        return imc.get(clazzName + "-" + name);
    }

}
