package com.airhacks.xmas.business.gift.entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author airhacks.com
 */
public class GiftIT {

    private EntityManager em;
    private EntityTransaction tx;

    @Before
    public void initEm() {
        this.em = Persistence.createEntityManagerFactory("it").createEntityManager();
        this.tx = this.em.getTransaction();
    }

    @Test
    public void crud() {
        Gift gift = new Gift("engine", 42);
        tx.begin();
        Gift created = this.em.merge(gift);
        tx.commit();

    }

}
