package com.airhacks.xmas.business.gift.boundary;

import com.airhacks.xmas.business.gift.control.Scanner;
import com.airhacks.xmas.business.gift.entity.Gift;
import org.junit.Before;
import org.junit.Test;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 *
 * @author airhacks.com
 */
public class SantaTest {

    Santa cut;

    @Before
    public void init() {
        this.cut = new Santa();
        this.cut.scanner = mock(Scanner.class);

    }

    @Test(expected = IllegalArgumentException.class)
    public void tooExpensiveGift() {
        when(this.cut.scanner.isNaughty()).thenReturn(false);
        Gift gift = new Gift("", 101);
        this.cut.save(gift);
    }

}
