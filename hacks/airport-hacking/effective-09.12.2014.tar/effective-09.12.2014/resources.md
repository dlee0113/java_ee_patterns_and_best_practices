#Resources

https://kenai.com/projects/suncloudapis/pages/HelloCloud

http://archive.oreilly.com/lpt/wlg/3005
http://www.w3.org/Protocols/rfc2616/rfc2616-sec9.html
http://ironjacamar.org
http://connectorz.adam-bien.com
https://tyrus.java.net
splunk (commercial)
logstash

Load generators tools: tsung, ab, jmeter
Loadr
lightfish.adam-bien.com
