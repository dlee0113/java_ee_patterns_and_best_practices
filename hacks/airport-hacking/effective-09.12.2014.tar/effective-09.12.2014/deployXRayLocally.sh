#!/bin/bash
#GLASSFISH_HOME=
XRAY_WAR=/Users/abien/work/workspaces/x-ray/x-ray-services/target/x-ray.war
#HSQL2_DIR=
cd $HSQL2_DIR
./start-hsqldbv2.sh &

$GLASSFISH_HOME/bin/asadmin stop-database
$GLASSFISH_HOME/bin/asadmin start-database
$GLASSFISH_HOME/bin/asadmin stop-domain x-ray
$GLASSFISH_HOME/bin/asadmin start-domain x-ray
$GLASSFISH_HOME/bin/asadmin --port 5348 deploy --force $XRAY_WAR

