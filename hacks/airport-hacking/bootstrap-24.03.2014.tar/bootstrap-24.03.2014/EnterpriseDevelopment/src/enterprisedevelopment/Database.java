package enterprisedevelopment;

/**
 *
 * @author airhacks.com
 */
public interface Database {

    String getMessage();
}
