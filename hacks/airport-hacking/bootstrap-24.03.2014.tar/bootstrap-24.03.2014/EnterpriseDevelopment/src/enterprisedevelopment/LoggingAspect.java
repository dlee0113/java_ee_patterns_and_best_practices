package enterprisedevelopment;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/**
 *
 * @author airhacks.com
 */
public class LoggingAspect implements InvocationHandler {

    private Object target;

    public LoggingAspect(Object target) {
        this.target = target;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.println("-- Method invoked: " + method);
        try {
            return method.invoke(target, args);
        } finally {
            System.out.println("-- after method: " + method);
        }
    }

}
