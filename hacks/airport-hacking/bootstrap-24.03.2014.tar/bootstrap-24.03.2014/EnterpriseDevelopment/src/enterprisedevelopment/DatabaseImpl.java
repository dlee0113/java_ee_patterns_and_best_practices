package enterprisedevelopment;

/**
 *
 * @author airhacks.com
 */
public class DatabaseImpl implements Database {

    @Override
    public String getMessage() {
        return "from database";
    }

}
