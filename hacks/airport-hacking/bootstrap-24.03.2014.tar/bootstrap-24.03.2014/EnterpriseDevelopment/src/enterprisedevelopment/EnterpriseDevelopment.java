package enterprisedevelopment;

/**
 *
 * @author airhacks.com
 */
public class EnterpriseDevelopment {

    Database another = null;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Database db = (Database) ObjectFactory.getInstance().create();
        System.out.println("Still in Kansas? " + db.getClass());
        System.out.println("From db: " + db.getMessage());

    }

}
