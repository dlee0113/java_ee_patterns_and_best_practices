package enterprisedevelopment;

import java.lang.reflect.Proxy;

/**
 *
 * @author airhacks.com
 */
public class Decorator {

    public static Object decorate(Object target) {
        Class<? extends Object> clazz = target.getClass();
        return Proxy.newProxyInstance(clazz.getClassLoader(), clazz.getInterfaces(), new LoggingAspect(target));
    }

}
