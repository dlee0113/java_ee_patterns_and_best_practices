package enterprisedevelopment;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author airhacks.com
 */
public class ObjectFactory {

    public final static ObjectFactory instance = new ObjectFactory();

    public static ObjectFactory getInstance() {
        return instance;
    }

    public Object create() {
        try {
            return Decorator.decorate(Class.forName("enterprisedevelopment.DatabaseImpl").newInstance());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException ex) {
            throw new IllegalStateException("Cannot create database", ex);
        }
    }

}
