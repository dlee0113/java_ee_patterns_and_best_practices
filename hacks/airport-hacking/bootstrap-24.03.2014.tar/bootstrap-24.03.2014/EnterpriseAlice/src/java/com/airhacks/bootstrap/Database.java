package com.airhacks.bootstrap;

/**
 *
 * @author airhacks.com
 */
public interface Database {

    String fromDb();
}
