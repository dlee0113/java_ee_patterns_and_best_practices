package com.airhacks.bootstrap;

import javax.enterprise.inject.Alternative;
import javax.inject.Named;

/**
 *
 * @author airhacks.com
 */
@Coolness(Coolness.Factor.HIGH)
public class DatabaseImpl2 implements Database {

    @Override
    public String fromDb() {
        return "from NewSLQ";
    }

}
