package com.airhacks.bootstrap;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 *
 * @author airhacks.com
 */
@Entity
public class Location {

    @Id
    @GeneratedValue
    private long id;

    private String coordinates;

    public Location(String coordinates) {
        this.coordinates = coordinates;
    }

    public Location() {
    }

    public long getId() {
        return id;
    }

}
