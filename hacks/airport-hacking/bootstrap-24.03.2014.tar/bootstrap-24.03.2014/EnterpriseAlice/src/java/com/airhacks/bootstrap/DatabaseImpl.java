package com.airhacks.bootstrap;

/**
 *
 * @author airhacks.com
 */
@Coolness(Coolness.Factor.LOW)
public class DatabaseImpl implements Database {

    @Override
    public String fromDb() {
        return "from NoSQL";
    }

}
