package com.airhacks.bootstrap;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Model;
import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.constraints.Size;

/**
 *
 * @author airhacks.com
 */
@Named
@RequestScoped
//@Model
public class Index {

    @Inject
    LocationService ls;

    @Size(min = 2, max = 5)
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object save() {

        System.out.println("Message: " + message);
        this.message = this.ls.location();
        return null;
    }

}
