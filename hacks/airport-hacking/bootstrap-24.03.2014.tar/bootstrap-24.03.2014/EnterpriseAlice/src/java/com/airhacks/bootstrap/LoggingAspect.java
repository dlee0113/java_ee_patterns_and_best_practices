package com.airhacks.bootstrap;

import java.lang.reflect.Method;
import javax.interceptor.AroundConstruct;
import javax.interceptor.AroundInvoke;
import javax.interceptor.AroundTimeout;
import javax.interceptor.InvocationContext;

/**
 *
 * @author airhacks.com
 */
public class LoggingAspect {

    //@AroundTimeout
    //@AroundConstruct
    @AroundInvoke
    public Object doesNotMatter(InvocationContext ic) throws Exception {
        Method method = ic.getMethod();
        System.out.println("Method: " + method);
        return ic.proceed();
    }

}
