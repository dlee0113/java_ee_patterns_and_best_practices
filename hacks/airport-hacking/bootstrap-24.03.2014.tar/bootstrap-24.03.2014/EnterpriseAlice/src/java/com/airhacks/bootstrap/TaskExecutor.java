package com.airhacks.bootstrap;

import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.enterprise.concurrent.ManagedExecutorService;

/**
 *
 * @author airhacks.com
 */
@Stateless
public class TaskExecutor {

    @Resource
    ManagedExecutorService mes;

    public Future<Long> execute(Callable<Long> taks) {
        return mes.submit(taks);
    }
}
