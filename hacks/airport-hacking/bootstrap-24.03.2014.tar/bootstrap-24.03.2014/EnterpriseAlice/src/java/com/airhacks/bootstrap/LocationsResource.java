package com.airhacks.bootstrap;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

/**
 *
 * @author airhacks.com
 */
@Stateless
@Path("locations")
public class LocationsResource {

    @Inject
    LocationService ls;

    @GET
    public String location() {
        List<Future<Long>> results = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            results.add(ls.saveOrUpdate(new Location("kansas " + i)));
        }
        String output = "";
        for (Future<Long> result : results) {
            try {
                output += String.valueOf(result.get());
            } catch (InterruptedException | ExecutionException ex) {
                Logger.getLogger(LocationsResource.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return output + " " + ls.location() + " " + ls.getClass().getName();
    }
}
