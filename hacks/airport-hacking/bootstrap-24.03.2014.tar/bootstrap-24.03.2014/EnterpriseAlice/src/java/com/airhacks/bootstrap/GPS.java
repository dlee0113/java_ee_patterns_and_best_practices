package com.airhacks.bootstrap;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.interceptor.Interceptors;

/**
 *
 * @author airhacks.com
 */
@RequestScoped
@Interceptors(LoggingAspect.class)
public class GPS {

    @PostConstruct
    public void init() {
        System.out.println("Creating POJO (GPS)");
    }

    public String coordinates() {
        return "42,42";
    }
}
