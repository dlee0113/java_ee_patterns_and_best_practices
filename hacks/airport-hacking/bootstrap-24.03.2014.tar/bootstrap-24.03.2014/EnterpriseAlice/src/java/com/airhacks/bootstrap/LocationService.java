package com.airhacks.bootstrap;

import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.inject.Named;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author airhacks.com
 */
@Stateless
@Interceptors(LoggingAspect.class)
public class LocationService {

    @Inject
    GPS gps;

    @Inject
    @Any
    Instance<Database> dbs;

    @PersistenceContext
    EntityManager em;

    @Inject
    Event<Location> events;

    @Resource
    SessionContext sc;

    @Inject
    TaskExecutor te;

    @PostConstruct
    public void onInitialize() {
        System.out.println("How many instances???");
    }

    public String location() {
        for (Database database : dbs) {
            System.out.println("-- found db: " + database);
        }
        return " kansas from EJB " + System.currentTimeMillis() + " " + gps.coordinates();
    }

    @Asynchronous
    public Future<Long> saveOrUpdate(Location location) {
        Location retVal = this.em.merge(location);
        events.fire(location);
        try {
            Thread.sleep(1000);
            //sc.setRollbackOnly();
        } catch (InterruptedException ex) {
            Logger.getLogger(LocationService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new AsyncResult<>(retVal.getId());
    }

    public Future<Long> saveOrUpdateWithThreads(Location location) {
        Callable<Long> callable = new Callable<Long>() {

            @Override
            public Long call() throws Exception {
                return em.merge(location).getId();
            }

        };
        return te.execute(callable);
    }
}
