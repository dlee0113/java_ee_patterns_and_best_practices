package com.airhacks.bootstrap;

import javax.annotation.Resource;
import javax.ejb.Asynchronous;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author airhacks.com
 */
public class LocationListener {

    public void onSuccess(@Observes(during = TransactionPhase.AFTER_SUCCESS) Location location) {
        System.out.println("+++++++++++++Location: " + location);
    }

    public void notImportant(@Observes(during = TransactionPhase.AFTER_FAILURE) Location location) {
        System.out.println("------------Location: " + location);
    }

}
