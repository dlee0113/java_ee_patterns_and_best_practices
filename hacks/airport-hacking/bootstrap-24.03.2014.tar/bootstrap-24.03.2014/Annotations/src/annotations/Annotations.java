package annotations;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 *
 * @author airhacks.com
 */
public class Annotations {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        final Class aliceClazz = Class.forName("annotations.Alice");
        /**
         * Method[] declaredMethods = Alice.class.getDeclaredMethods(); for
         * (Method method : declaredMethods) {
         * method.isAnnotationPresent(Kansas.class); System.out.println("Method:
         * " + method); }
         *
         */
        Field[] fields = aliceClazz.getDeclaredFields();
        for (Field field : fields) {
            Kansas annotation = field.getAnnotation(Kansas.class);
            if (annotation != null) {
                System.out.println(field + "We are no more in Kansas " + annotation.value());
                Class<?> typeInjectedToAlice = field.getType();
                Object countryInstance = typeInjectedToAlice.newInstance();
                Object aliceInstance = aliceClazz.newInstance();
                field.setAccessible(true);
                field.set(aliceInstance, countryInstance);
                System.out.println("Alice: " + aliceInstance);
            } else {
                System.out.println(field + "We are in MUC");
            }
        }
    }

}
