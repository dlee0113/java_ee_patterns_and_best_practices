package annotations;

/**
 *
 * @author airhacks.com
 */
public class Alice {

    @Kansas("we are not in kansas any more")
    private Country country;

    String location;

    @Kansas
    public void run() {

    }

    @Override
    public String toString() {
        return "Alice{" + "country=" + country + ", location=" + location + '}';
    }

}
