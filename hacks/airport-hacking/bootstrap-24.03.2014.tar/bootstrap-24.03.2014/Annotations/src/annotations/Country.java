package annotations;

/**
 *
 * @author airhacks.com
 */
public class Country {

}
