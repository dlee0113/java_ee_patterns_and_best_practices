#JavaSerializer

KRYO

        <dependency>
            <groupId>com.esotericsoftware.kryo</groupId>
            <artifactId>kryo</artifactId>
            <version>2.22</version>
        </dependency>

#SOAP Security

http://hackmageddon.com/2011/10/23/xml-encryption-cracked/



#REST Documentation tool

Enunciate

#REST sample

http://docs.jboss.org/resteasy/hornetq-rest/1.0-beta-1/userguide/html_single/#d0e157

https://kenai.com/projects/suncloudapis/pages/HelloCloud



POST
xmas/v1/searches/

<results>
 <next uri="xmas/v1/searches?from=0&to=2"/>
</results>


GET
xmas/v1/wishes/?search=hugo

<wishes>
<name>duke</name>


http://localhost:8080/xmas/[v1]or[resources]/wishes/duke/

POST / PUT


POST
xmas/v1/wishes/duke/books

<wish>
</wish>


#REST sub-resource locator
xmas/v1/wishes/duke/books




#links between resources


<profile>
<address href="http://gooole"/>
	</profile>


http://oauth.net
http://jpasecurity.sourceforge.net
http://www.adam-bien.com/roller/abien/entry/java_ee_authentication_and_authorization
http://www.adam-bien.com/roller/abien/entry/a_single_line_of_code
http://www.adam-bien.com/roller/abien/entry/client_side_http_basic_access

#JPA

select new com.airhacks.WishDTO(w.name) from Wish w

flywaydb




