/*
 */
package com.airhacks.xmas.business.wishes.control;

import com.airhacks.xmas.business.wishes.entity.Wish;

/**
 *
 * @author adam-bien.com
 */
public class BudgetController {

    public boolean isInBudget(Wish wish) {
        return false;
    }

}
