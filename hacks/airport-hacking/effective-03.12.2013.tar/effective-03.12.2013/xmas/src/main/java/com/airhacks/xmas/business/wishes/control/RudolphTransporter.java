/*
 */
package com.airhacks.xmas.business.wishes.control;

import com.airhacks.xmas.business.wishes.entity.Wish;

/**
 *
 * @author adam-bien.com
 */
public class RudolphTransporter {

    public void makeItHappen(Wish wish) {
        System.out.println("--- I care about: " + wish);
    }

}
