/*
 */
package com.airhacks.xmas;

/**
 *
 * @author adam-bien.com
 */
public interface WishList {

    boolean createWish(String wish);

}
