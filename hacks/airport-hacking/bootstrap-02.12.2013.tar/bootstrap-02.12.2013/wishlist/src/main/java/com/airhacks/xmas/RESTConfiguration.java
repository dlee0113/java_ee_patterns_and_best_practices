/*
 */
package com.airhacks.xmas;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author adam-bien.com
 */
@ApplicationPath("resources")
public class RESTConfiguration extends Application {

}
