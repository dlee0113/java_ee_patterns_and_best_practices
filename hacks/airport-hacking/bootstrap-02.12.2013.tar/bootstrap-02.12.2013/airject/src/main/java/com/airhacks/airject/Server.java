/*
 */
package com.airhacks.airject;

/**
 *
 * @author adam-bien.com
 */
public class Server {

}
