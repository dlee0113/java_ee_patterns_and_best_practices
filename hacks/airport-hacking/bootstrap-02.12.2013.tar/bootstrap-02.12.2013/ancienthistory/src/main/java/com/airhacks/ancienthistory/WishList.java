/*
 */
package com.airhacks.ancienthistory;

/**
 *
 * @author adam-bien.com
 */
public interface WishList {

    public boolean createWish(String wish);

}
