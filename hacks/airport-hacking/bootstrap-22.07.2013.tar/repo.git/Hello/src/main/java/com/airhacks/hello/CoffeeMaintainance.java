package com.airhacks.hello;

import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class CoffeeMaintainance {

    @Inject
    @Any
    Instance<CoffeeMachine> coffeeMachines;

    public void cleanAll() {
        for (CoffeeMachine coffeeMachine : coffeeMachines) {
            coffeeMachine.make();
            System.out.println("Cleaning: " + coffeeMachine);
        }
    }

}
