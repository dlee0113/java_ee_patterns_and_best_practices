package com.airhacks.hello;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class SerialMill {

    @Inject
    CoffeeMill cm;

    public void mill() {
        List<Future<String>> inProgress = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            inProgress.add(cm.mill("illy"));
        }

        for (Future<String> future : inProgress) {
            try {
                System.out.println("Result: " + future.get());
            } catch (InterruptedException | ExecutionException ex) {
                Logger.getLogger(SerialMill.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
