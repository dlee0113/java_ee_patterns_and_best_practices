package com.airhacks.hello;

import java.net.URI;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

/**
 *
 * @author adam-bien.com
 */
@Path("messages")
public class MessagesResource {

    @GET
    public JsonObject all() {
        return Json.createObjectBuilder().add("uri", "lazy").build();
    }

    @GET
    @Path("{id}")
    public AirMessage byName(@PathParam("id") String name) {
        return new AirMessage(name);
    }

    @POST
    public Response save(String message) {
        System.out.println("Got a message: " + message);
        URI uri = URI.create("/" + System.currentTimeMillis());
        return Response.created(uri).build();
    }
}
