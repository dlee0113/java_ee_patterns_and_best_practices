package com.airhacks.hello;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 *
 * @author adam-bien.com
 */
@Entity
public class Cloud {

    @Id
    @GeneratedValue
    private long id;

    private String content;

    public Cloud() {
    }

    public Cloud(String content) {
        this.content = content;
    }

}
