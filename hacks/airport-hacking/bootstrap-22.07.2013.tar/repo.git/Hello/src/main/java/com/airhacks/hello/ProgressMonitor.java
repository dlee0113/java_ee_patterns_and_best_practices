package com.airhacks.hello;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Singleton;
import javax.enterprise.event.Observes;
import javax.servlet.AsyncContext;

/**
 *
 * @author adam-bien.com
 */
@Singleton
public class ProgressMonitor {

    public void onRequest(@Observes AsyncContext ac) {
        try {
            ac.getResponse().getWriter().print("Hey from ejb");
            ac.complete();
        } catch (IOException ex) {
            Logger.getLogger(ProgressMonitor.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
