package com.airhacks.hello;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.faces.application.ProjectStage;

/**
 *
 * @author adam-bien.com
 */
public class ConfigurationProvider {

    @Produces
    public String getConfiguration(InjectionPoint ip, ProjectStage stage, CustomStage myStage) {
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String name = ip.getMember().getName();

        return myStage + " " + stage + " " + clazz.getName() + " ---> " + name + " ";
    }
}
