package com.airhacks.hello;

import java.security.Principal;
import java.util.Date;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Remove;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class MorningService {

    @PersistenceContext(unitName = "production")
    EntityManager em;

    @Resource
    SessionContext sc;

    @Inject
    Event<String> coffeeEnthusiasts;

    @Inject
    Principal principal;

    @PostConstruct
    public void onStart() {
        System.out.println("Starting Service");
    }

    public String fromService() {
        final String message = "hey " + principal.getName() + " " + new Date();
        AirMessage merged = em.merge(new AirMessage(message));
        merged.setMessage("Updated");
        //sc.setRollbackOnly();
        coffeeEnthusiasts.fire(message);
        return message;
    }

    /**
     * Gets called by @Stateful session beans for cleanup purposes Only needed
     * for non @SessionScoped (manually managed) beans.
     */
    @Remove
    public void goingHome() {
    }

    public void save(AirMessage message) {
        em.merge(message);
    }
}
