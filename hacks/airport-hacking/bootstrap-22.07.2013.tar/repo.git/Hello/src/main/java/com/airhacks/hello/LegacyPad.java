package com.airhacks.hello;

/**
 *
 * @author adam-bien.com
 */
public class LegacyPad {

    private String name;

    public LegacyPad(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "LegacyPad{" + "name=" + name + '}';
    }
}
