package com.airhacks.hello;

import javax.enterprise.inject.Produces;

/**
 *
 * @author adam-bien.com
 */
public class StageProvider {

    @Produces
    public CustomStage getStage() {
        return CustomStage.valueOf("PROD");
    }
}
