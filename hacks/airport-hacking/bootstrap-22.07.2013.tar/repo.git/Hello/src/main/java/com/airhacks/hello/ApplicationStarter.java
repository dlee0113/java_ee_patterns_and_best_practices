package com.airhacks.hello;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
public class ApplicationStarter {

    @PostConstruct
    public void onStart() {
        System.out.println("Startin!!!!!!");
    }
}
