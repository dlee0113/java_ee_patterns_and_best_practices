package com.airhacks.hello;

import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Taste(Taste.Category.POOR)
public class PadCoffeeMachine implements CoffeeMachine {

    @Inject
    LegacyPad pad;

    @Inject
    private String message;

    @Override
    public void make() {
        System.out.println(message + pad);
    }
}
