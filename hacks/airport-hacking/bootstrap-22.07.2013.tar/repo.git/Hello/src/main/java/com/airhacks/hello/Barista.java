package com.airhacks.hello;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class Barista {

    @Asynchronous
    public void onCoffeeRequest(@Observes(during = TransactionPhase.AFTER_SUCCESS) String message) {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Barista.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(" Already making coffee for: " + message);
    }

    public void onFailedRequest(@Observes(during = TransactionPhase.AFTER_FAILURE) String message) {
        System.out.println(" Failure.....: " + message);
    }
}
