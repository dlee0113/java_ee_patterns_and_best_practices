package com.airhacks.hello;

/**
 *
 * @author adam-bien.com
 */
public enum CustomStage {

    PROD, TEST;
}
