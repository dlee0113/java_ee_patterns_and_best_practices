package com.airhacks.hello;

import javax.enterprise.inject.Produces;

/**
 *
 * @author adam-bien.com
 */
public class PadFactory {

    @Produces
    public LegacyPad something() {
        return new LegacyPad("awful");
    }
}
