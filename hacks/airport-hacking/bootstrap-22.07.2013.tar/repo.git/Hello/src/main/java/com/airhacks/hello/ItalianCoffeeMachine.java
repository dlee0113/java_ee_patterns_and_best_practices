package com.airhacks.hello;

/**
 *
 * @author adam-bien.com
 */
@Taste(Taste.Category.GOOD)
public class ItalianCoffeeMachine implements CoffeeMachine {

    @Override
    public void make() {
        System.out.println("Making real coffeee");
    }
}
