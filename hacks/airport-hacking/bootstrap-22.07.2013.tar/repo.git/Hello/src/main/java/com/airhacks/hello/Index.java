package com.airhacks.hello;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.faces.application.ProjectStage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Model
public class Index {

    @Inject
    MorningService ms;

    private AirMessage message;

    @Inject
    @Taste(Taste.Category.POOR)
    CoffeeMachine cf;

    @Inject
    CoffeeMaintainance cm;

    @Inject
    SerialMill mill;

    @PostConstruct
    public void onStart() {
        System.out.println("Starting index");
        this.message = new AirMessage();
    }

    public String getMessage() {
        mill.mill();
        cf.make();
        cm.cleanAll();
        return ms.fromService();
    }

    public AirMessage getAirMessage() {
        return this.message;
    }

    public Object save() {
        System.out.println("Saving: " + message);
        ms.save(message);
        return "result";
    }

    @Produces
    public ProjectStage expose() {
        return FacesContext.getCurrentInstance().getApplication().getProjectStage();
    }
}
