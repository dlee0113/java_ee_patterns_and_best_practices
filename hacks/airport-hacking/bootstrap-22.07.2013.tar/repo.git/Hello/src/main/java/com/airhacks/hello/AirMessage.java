package com.airhacks.hello;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Version;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
@Entity
public class AirMessage {

    @Id
    @GeneratedValue
    private long id;

    @Version
    private long version;

    @Size(min = 2, max = 5)
    private String message;

    @XmlTransient
    @OneToOne(cascade = CascadeType.ALL)
    private Cloud cloud;

    public AirMessage() {
        cloud = new Cloud("no clouds today");
    }

    public AirMessage(String message) {
        this();
        this.message = message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

}
