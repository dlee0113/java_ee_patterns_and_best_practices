package com.airhacks.hello;

import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class CoffeeMill {

    @Asynchronous
    public Future<String> mill(String beans) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(CoffeeMill.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new AsyncResult<>("Done " + System.currentTimeMillis());
    }
}
