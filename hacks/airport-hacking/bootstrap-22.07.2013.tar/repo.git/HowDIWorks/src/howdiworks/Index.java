package howdiworks;

/**
 *
 * @author adam-bien.com
 */
public class Index {

    @AirInject
    private MorningService ms;

    @Override
    public String toString() {
        return "Index{" + "ms=" + ms + '}';
    }

}
