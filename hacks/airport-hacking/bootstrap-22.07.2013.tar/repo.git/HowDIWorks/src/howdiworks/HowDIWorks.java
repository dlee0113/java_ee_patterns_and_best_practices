package howdiworks;

import java.lang.reflect.Field;

/**
 *
 * @author adam-bien.com
 */
public class HowDIWorks {
    
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class<?> clazz = Class.forName("howdiworks.Index");
        Object index = clazz.newInstance();
        Field[] declaredFields = clazz.getDeclaredFields();
        for (Field field : declaredFields) {
            if (field.isAnnotationPresent(AirInject.class)) {
                Class<?> type = field.getType();
                Object newInstance = type.newInstance();
                field.setAccessible(true);
                field.set(index, newInstance);
                
                System.out.println("Output: " + index);
            }
        }
        
    }
    
}
