package howdiworks;

/**
 *
 * @author adam-bien.com
 */
public class MorningService {
}
