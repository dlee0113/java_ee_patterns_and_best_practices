package com.airhacks.vaadin;

import com.vaadin.server.VaadinRequest;
import com.vaadin.ui.Button;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.UI;

public class ExampleUI extends UI {

    @Override
    public void init(VaadinRequest request) {
        HorizontalLayout layout = new HorizontalLayout();
        setContent(layout);
        Label label = new Label("Hello Vaadin");
        Button button = new Button("Ok");
        button.addClickListener((Button.ClickEvent event) -> {
            label.setCaption("Clicked: " + event);
        });
        layout.addComponent(label);
        layout.addComponent(button);

    }

}
