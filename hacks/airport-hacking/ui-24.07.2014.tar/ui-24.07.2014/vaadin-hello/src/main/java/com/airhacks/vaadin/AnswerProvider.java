package com.airhacks.vaadin;

import javax.ejb.Stateless;

/**
 *
 * @author airhacks.com
 */
@Stateless
public class AnswerProvider {

    public String getAnswer() {
        return "42";
    }

}
