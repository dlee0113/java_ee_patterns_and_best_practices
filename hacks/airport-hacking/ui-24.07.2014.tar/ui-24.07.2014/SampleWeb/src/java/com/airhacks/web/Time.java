package com.airhacks.web;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author airhacks.com
 */
@Named
@RequestScoped
public class Time {

    public String getCurrent() {
        return "good morning";
    }

}
