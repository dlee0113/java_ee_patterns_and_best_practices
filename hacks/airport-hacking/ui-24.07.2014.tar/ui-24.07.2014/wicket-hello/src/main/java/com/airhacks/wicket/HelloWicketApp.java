package com.airhacks.wicket;

/**
 *
 * @author airhacks.com
 */
import javax.enterprise.inject.spi.BeanManager;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import org.apache.wicket.cdi.CdiConfiguration;
import org.apache.wicket.protocol.http.WebApplication;

public class HelloWicketApp extends WebApplication {

    @Override
    public void init() {
        BeanManager manager = null;
        try {
            manager = (BeanManager) new InitialContext()
                    .lookup("java:comp/BeanManager");
        } catch (NamingException e) {
        }
        new CdiConfiguration().configure(this);
    }

    @Override
    public Class getHomePage() {
        return HomePage.class;
    }
}
