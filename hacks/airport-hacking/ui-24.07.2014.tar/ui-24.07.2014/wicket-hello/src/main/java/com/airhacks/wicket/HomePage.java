package com.airhacks.wicket;

import javax.enterprise.inject.spi.Bean;
import javax.inject.Inject;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.ajax.markup.html.form.AjaxButton;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.model.Model;

/**
 *
 * @author airhacks.com
 */
public class HomePage extends WebPage {

    @Inject
    HelloService helloService;

    public HomePage() {
        Form<Bean> buttonForm = new Form<>("buttonForm");
        add(buttonForm);
        Model<String> model = Model.of("Hello Wicket");
        Label message = new Label("message", model);
        message.setOutputMarkupId(true);
        buttonForm.add(message);
        buttonForm.add(new Button("button") {
            @Override
            public void onAfterSubmit() {
                final String message = helloService.getMessage();
                System.out.println(message);
                model.setObject(message);
            }
        });
    }

}
