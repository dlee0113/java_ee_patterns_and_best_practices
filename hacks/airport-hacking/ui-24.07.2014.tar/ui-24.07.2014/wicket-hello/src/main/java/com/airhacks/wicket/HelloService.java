package com.airhacks.wicket;

import javax.ejb.Stateless;

/**
 *
 * @author airhacks.com
 */
@Stateless
public class HelloService {

    public String getMessage() {
        return "A nice framework";
    }

}
