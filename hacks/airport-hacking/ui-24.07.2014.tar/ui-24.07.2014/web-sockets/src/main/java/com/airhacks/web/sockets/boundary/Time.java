package com.airhacks.web.sockets.boundary;

import java.util.Date;
import java.util.concurrent.CopyOnWriteArraySet;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.interceptor.Interceptors;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

/**
 *
 * @author adam-bien.com
 */
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
@Interceptors(CallLogger.class)
@ServerEndpoint("/time")
public class Time {

    private Session session;

    @OnOpen
    public void onOpen(Session session) {
        this.session = session;
    }

    @OnClose
    public void onClose(Session session) {
        session = null;
    }

    @OnMessage
    public String timeRequest(String request) {
        return String.valueOf("Time: " + getCurrentTime() + " Session: " + this.session);
    }

    @Schedule(hour = "*", minute = "*", second = "*/2", persistent = false)
    public void sendTime() {
        if (session != null && session.isOpen()) {
            session.getAsyncRemote().sendText(getCurrentTime());
        }
    }

    private String getCurrentTime() {
        return new Date().toString();
    }
}
