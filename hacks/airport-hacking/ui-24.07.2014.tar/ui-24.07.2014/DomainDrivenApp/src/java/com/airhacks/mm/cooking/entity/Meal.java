package com.airhacks.mm.cooking.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author airhacks.com
 */
@Table(name = "AA_Meal")
@Entity
public class Meal {

    @Id
    private String name;
    private int age;

    public Meal() {
    }

    public Meal(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getAgeAsMessage() {
        if (age < 40) {
            return "fresh";
        } else {
            return "ancient";
        }

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

}
