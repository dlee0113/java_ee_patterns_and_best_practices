package com.airhacks.mm.cooking.presentation;

import com.airhacks.mm.cooking.boundary.MealGateway;
import com.airhacks.mm.cooking.entity.Meal;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
@Model
public class Second {

    @Inject
    MealGateway mg;

    public Meal getMeal() {
        return this.mg.getMeal();
    }

    public Object save() {
        this.mg.save();
        return null;
    }
}
