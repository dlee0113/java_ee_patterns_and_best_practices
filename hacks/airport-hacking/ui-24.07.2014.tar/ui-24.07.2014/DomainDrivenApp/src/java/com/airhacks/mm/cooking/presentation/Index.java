package com.airhacks.mm.cooking.presentation;

import com.airhacks.mm.cooking.boundary.MealGateway;
import com.airhacks.mm.cooking.entity.Meal;
import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
@Model
public class Index {

    @Inject
    MealGateway mg;

    private Meal meal;

    @PostConstruct
    public void init() {
        this.meal = new Meal();
    }

    public Meal getMeal() {
        return meal;
    }

    public Object save() {
        this.mg.save(this.meal);
        return "first";
    }

}
