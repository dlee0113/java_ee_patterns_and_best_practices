package com.airhacks.mm.cooking.presentation;

import com.airhacks.mm.cooking.boundary.MealGateway;
import com.airhacks.mm.cooking.entity.Meal;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
@Model
public class First {

    @Inject
    MealGateway mg;

    public Meal getMeal() {
        return this.mg.getMeal();
    }

    public Object undo() {
        this.mg.undo();
        return null;
    }

    public Object next() {
        return "second";
    }
}
