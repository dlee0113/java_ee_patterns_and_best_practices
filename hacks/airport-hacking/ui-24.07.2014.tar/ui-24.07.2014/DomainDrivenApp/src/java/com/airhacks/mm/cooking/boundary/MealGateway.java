package com.airhacks.mm.cooking.boundary;

import com.airhacks.mm.cooking.entity.Meal;
import javax.ejb.Stateful;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.context.SessionScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

/**
 *
 * @author airhacks.com
 */
@SessionScoped
@Stateful
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class MealGateway {

    @PersistenceContext(type = PersistenceContextType.EXTENDED)
    EntityManager em;

    private Meal meal;

    public Meal getMeal() {
        return meal;
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public void save() {
        //nothing happens here
    }

    public void undo() {
        this.em.refresh(this.meal);
    }

    public void load(String name) {
        this.meal = this.em.find(Meal.class, name);
    }

    public void save(Meal meal) {
        this.meal = this.em.merge(meal);
    }

}
