package com.airhacks.vraptor.business.messages.entity;

/**
 *
 * @author airhacks.com
 */
public class Message {

    private String content;
    private long time;

    public Message(String content) {
        this.content = content;
        this.time = System.currentTimeMillis();
    }

    public String getContent() {
        return content;
    }

    public long getTime() {
        return time;
    }

}
