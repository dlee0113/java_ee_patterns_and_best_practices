package com.airhacks.vraptor.presentation;

import br.com.caelum.vraptor.Controller;
import br.com.caelum.vraptor.Get;
import br.com.caelum.vraptor.Result;
import com.airhacks.vraptor.business.messages.boundary.Greeter;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
@Controller
public class HelloController {

    @Inject
    private Result result;

    @Inject
    Greeter greeter;

    @Get("/overview")
    public void overview() {
        result.include("message", greeter.getMessage());
    }

}
