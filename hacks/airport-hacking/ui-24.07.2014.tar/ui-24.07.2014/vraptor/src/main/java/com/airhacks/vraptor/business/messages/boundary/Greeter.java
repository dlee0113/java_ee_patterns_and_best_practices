package com.airhacks.vraptor.business.messages.boundary;

import com.airhacks.vraptor.business.messages.entity.Message;
import javax.ejb.Stateless;

/**
 *
 * @author airhacks.com
 */
@Stateless
public class Greeter {

    public Message getMessage() {
        return new Message("An enterprise hello!");
    }

}
