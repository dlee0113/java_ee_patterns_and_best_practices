package com.airhacks.welcome;

/**
 *
 * @author airhacks.com
 */
public class WelcomeAction {

    public String execute() {
        System.out.println("Works!");
        return "success";
    }

    public Message getMessage() {
        return new Message("Action Hero ! " + System.currentTimeMillis());
    }
}
