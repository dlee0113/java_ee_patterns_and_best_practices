#Resources
http://stackoverflow.com/questions/8266953/how-to-debug-jsf-el
http://sass-lang.com
http://docs.oracle.com/javaee/7/tutorial/doc/jsf-facelets009.htm
http://martinfowler.com/eaaDev/ModelViewPresenter.html
https://avatar-js.java.net
https://javaserverfaces.java.net/nonav/docs/2.2/javadocs/index.html
https://wikis.oracle.com/display/GlassFish/JavaServerFacesRI
http://www.nakedobjects.org
http://www.amazon.de/Objects-Computer-Science-Richard-Pawson/dp/0470844205
http://docs.oracle.com/cd/E17802_01/javafx/javafx/1.3/docs/api/javafx.scene/doc-files/cssref.html#circle
http://harmoniccode.blogspot.de
arquillian / graphene
phantomjs
TestFX -> "WebDriver" for JavaFX
gitblit
        <dependency>
            <groupId>org.eclipse.jgit</groupId>
            <artifactId>org.eclipse.jgit</artifactId>
            <version>3.2.0.201312181205-r</version>
        </dependency>
//websocket RI
 <dependency>
            <groupId>org.glassfish.tyrus</groupId>
            <artifactId>tyrus-client</artifactId>
            <version>1.2.1</version>
        </dependency>
        <dependency>
            <groupId>org.glassfish.tyrus</groupId>
            <artifactId>tyrus-container-grizzly</artifactId>
            <version>1.2.1</version>
        </dependency>
        
        ---- client side websocket
        
        package org.lightfish.business.appmonitoring.boundary;

import java.io.IOException;
import java.net.URI;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import javax.websocket.ClientEndpointConfig;
import javax.websocket.ContainerProvider;
import javax.websocket.DeploymentException;
import javax.websocket.Session;
import javax.websocket.WebSocketContainer;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import org.lightfish.business.MessageEndpoint;

/**
 *
 * @author adam-bien.com
 */
public class ApplicationsSocketIT {

    private MessageEndpoint endpoint;
    private CountDownLatch latch;

    @Before
    public void init() throws DeploymentException, IOException {
        this.latch = new CountDownLatch(1);
        this.endpoint = new MessageEndpoint(this.latch);
        WebSocketContainer container = ContainerProvider.getWebSocketContainer();
        ClientEndpointConfig config = ClientEndpointConfig.Builder.create().build();
        String uri = "ws://localhost:8080/lightfish/applications/lightfish";
        System.out.println("Connecting to " + uri);
        Session session = container.connectToServer(this.endpoint, config, URI.create(uri));
    }

    /**
     * Setup updates to 2 seconds before performing this test
     */
    @Test
    public void statisticsArrived() throws InterruptedException {
        assertTrue(this.latch.await(5, TimeUnit.SECONDS));
        String message = endpoint.getMessage();
        assertNotNull(message);
        System.out.println("Message: " + message);
    }

}


