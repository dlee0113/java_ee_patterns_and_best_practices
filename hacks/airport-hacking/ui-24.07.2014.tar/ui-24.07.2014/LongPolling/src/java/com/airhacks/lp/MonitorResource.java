package com.airhacks.lp;

import java.util.function.Consumer;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;

/**
 *
 * @author airhacks.com
 */
@Path("monitor")
public class MonitorResource {

    @Inject
    Event<Consumer<Object>> events;

    @GET
    public void message(@Suspended AsyncResponse response) {
        events.fire(response::resume);
    }

}
