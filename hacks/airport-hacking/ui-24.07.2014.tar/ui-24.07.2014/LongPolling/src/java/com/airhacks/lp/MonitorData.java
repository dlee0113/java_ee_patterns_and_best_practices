package com.airhacks.lp;

import java.util.Date;
import javax.ejb.Stateless;

/**
 *
 * @author airhacks.com
 */
@Stateless
public class MonitorData {

    public String getMonitoringData() {
        return "from EJB " + new Date();
    }

}
