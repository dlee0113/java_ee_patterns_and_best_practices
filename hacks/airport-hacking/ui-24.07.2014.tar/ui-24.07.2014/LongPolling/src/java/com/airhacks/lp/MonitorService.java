package com.airhacks.lp;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import javax.annotation.Resource;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.enterprise.event.Observes;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
@Singleton
public class MonitorService {

    private Consumer<Object> sink;

    @Inject
    MonitorData md;

    @Resource
    ManagedExecutorService mes;

    public void onBrowserRequest(@Observes Consumer<Object> sink) {
        this.sink = sink;
    }

    @Schedule(minute = "*", second = "*/10", hour = "*")
    public void refresh() {
        if (sink != null) {
            CompletableFuture.supplyAsync(md::getMonitoringData, mes).thenAccept(sink);
        }
    }

}
