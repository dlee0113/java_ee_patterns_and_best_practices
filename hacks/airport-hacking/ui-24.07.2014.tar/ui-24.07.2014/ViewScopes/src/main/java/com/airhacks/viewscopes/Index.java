/*
 *
 */
package com.airhacks.viewscopes;

/**
 *
 * @author adam-bien.com
 */
@Presenter
public class Index {

    public String getName() {
        return "hey from view";
    }

}
