package com.airhacks.jsf;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.validation.constraints.Size;

/**
 *
 * @author airhacks.com
 */
@Named
@RequestScoped
public class Index {

    @Size(min = 2, max = 3)
    private String time;

    public String getTime() {
        return this.time;
    }

    public void setTime(String name) {
        this.time = name;
    }

    public Object save() {
        System.out.println("Saving: " + this.time);
        return null;
    }

}
