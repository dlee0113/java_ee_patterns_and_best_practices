package com.airhacks.effectivejavaee.st;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import static org.junit.Assert.assertNotNull;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author adam-bien.com
 */
public class EventIT {

    private Client client;
    private WebTarget eventsTarget;

    @Before
    public void initClient() {
        this.client = ClientBuilder.newClient();
        this.eventsTarget = this.client.target("http://localhost:8080/EffectiveJavaEE/v1/events");
    }

    @Test
    public void allEvents() {
        String result = this.eventsTarget.request().get(String.class);
        assertNotNull(result);
        System.out.println("Result is: " + result);
    }
}
