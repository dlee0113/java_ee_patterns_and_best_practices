package com.airhacks.effectivejavaee.business.configuration;

import com.airhacks.effectivejavaee.business.cics.control.PrintingIntegration;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.ejb.Startup;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.inject.Singleton;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
@Path("configuration")
public class Configurator {

    private Map<String, String> configuration;

    @PostConstruct
    public void initialize() {
        this.configuration = new HashMap<>();
        this.configuration.put(PrintingIntegration.class.getName() + ".port", "42");
    }

    @GET
    public String all() {
        return this.configuration.toString();
    }

    @Produces
    public Integer getInt(InjectionPoint ip) {
        String key = getConfigurationKey(ip);
        String value = getValueForKey(key);
        return Integer.parseInt(value);
    }

    String getConfigurationKey(InjectionPoint ip) {
        Class<?> declaringClass = ip.getMember().getDeclaringClass();
        String name = ip.getMember().getName();
        return declaringClass.getName() + "." + name;

    }

    private String getValueForKey(String key) {
        return this.configuration.get(key);
    }

}
