package com.airhacks.effectivejavaee.business.events.boundary;

import com.airhacks.effectivejavaee.business.events.entity.AirEvent;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

/**
 *
 * @author adam-bien.com
 */
@Produces({"airhacks/custom", MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
@Stateless
@Path("events")
public class EventsResource {

    @Inject
    Events events;

    @GET
    public List<AirEvent> events() {
        List<AirEvent> result = events.getEvents();
        result.add(new AirEvent("manual hacking", "and fun"));
        return result;
    }

    @PUT
    public Response createOrUpdate(AirEvent airEvent, @Context UriInfo info) {
        events.create(airEvent);
        URI uri = URI.create(info.getAbsolutePath() + "/" + URLEncoder.encode(airEvent.getName()));
        return Response.created(uri).build();
    }

    @GET
    @Path("{id}")
    public AirEvent find(@PathParam("id") String eventName) {
        return events.find(URLDecoder.decode(eventName));
    }
}
