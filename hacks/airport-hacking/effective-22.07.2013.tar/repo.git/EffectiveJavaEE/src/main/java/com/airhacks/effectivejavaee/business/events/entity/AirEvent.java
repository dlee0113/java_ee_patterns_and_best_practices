package com.airhacks.effectivejavaee.business.events.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
@Entity
@NamedQueries({
    @NamedQuery(name = AirEvent.all, query = "SELECT a FROM AirEvent a"),
    @NamedQuery(name = AirEvent.subset, query = "SELECT new com.airhacks.effectivejavaee.business.events.entity.AirSubset(a.name) FROM AirEvent a")
})
public class AirEvent {

    @Id
    private String name;

    private static final String PREFIX = "com.airhacks.effectivejavaee.business.events.entity.AirEvent.";

    public final static String all = PREFIX + "all";
    public final static String subset = PREFIX + "subset";

    private String description;

    public AirEvent() {
    }

    public AirEvent(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
