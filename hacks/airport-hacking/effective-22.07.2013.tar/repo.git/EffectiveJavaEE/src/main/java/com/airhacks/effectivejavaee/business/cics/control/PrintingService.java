package com.airhacks.effectivejavaee.business.cics.control;

/**
 *
 * @author adam-bien.com
 */
public class PrintingService {

    private int port;
    private boolean connected;

    public PrintingService(int port) {
        this.port = port;
    }

    public void connect() {
        this.connected = true;
    }

    public void print(String message) {
        if (!connected) {
            throw new IllegalStateException("Connect first!");
        }
        System.out.println("Printing: " + message);
    }

    @Override
    public String toString() {
        return "PrintingService{" + "port=" + port + ", connected=" + connected + '}';
    }

}
