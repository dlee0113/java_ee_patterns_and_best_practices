package com.airhacks.effectivejavaee.business.events.control;

import com.airhacks.effectivejavaee.business.events.entity.AirEvent;

/**
 *
 * @author adam-bien.com
 */
public class EventValidator {

    public boolean isValid(AirEvent event) {
        return true;
    }
}
