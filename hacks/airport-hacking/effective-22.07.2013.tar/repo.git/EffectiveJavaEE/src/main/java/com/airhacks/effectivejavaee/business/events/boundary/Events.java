package com.airhacks.effectivejavaee.business.events.boundary;

import com.airhacks.effectivejavaee.business.cics.control.PrintingService;
import com.airhacks.effectivejavaee.business.events.control.EventValidator;
import com.airhacks.effectivejavaee.business.events.entity.AirEvent;
import java.util.List;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author adam-bien.com
 */
@Stateless
public class Events {
    
    @PersistenceContext
    private EntityManager em;
    
    @Inject
    private EventValidator validator;
    
    @Inject
    private PrintingService ps;
    
    @Inject
    Event<AirEvent> monitoring;
    
    public List<AirEvent> getEvents() {
        return this.em.createNamedQuery(AirEvent.all).getResultList();
    }
    
    public void create(AirEvent event) {
        if (!validator.isValid(event)) {
            throw new IllegalArgumentException("AirEvent " + event + " is not valid!");
        }
        ps.print(event.toString());
        System.out.println("Printing: " + ps);
        em.merge(event);
        monitoring.fire(event);
    }
    
    public AirEvent find(String eventName) {
        return em.find(AirEvent.class, eventName);
    }
}
