package com.airhacks.effectivejavaee.presentation;

import com.airhacks.effectivejavaee.business.events.boundary.Events;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Model
public class Index {

    @Inject
    Events events;

    public String getEvents() {
        return events.getEvents().toString();
    }
}
