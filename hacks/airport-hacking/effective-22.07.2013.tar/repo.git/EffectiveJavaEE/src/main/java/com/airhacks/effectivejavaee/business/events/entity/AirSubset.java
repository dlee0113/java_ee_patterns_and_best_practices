package com.airhacks.effectivejavaee.business.events.entity;

/**
 *
 * @author adam-bien.com
 */
public class AirSubset {

    private String name;

    public AirSubset(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
