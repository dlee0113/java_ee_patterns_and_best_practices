package com.airhacks.effectivejavaee.business.cics.control;

import javax.enterprise.inject.Produces;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class PrintingIntegration {

    @Inject
    private int port;

    @Produces
    public PrintingService create() {
        PrintingService ps = new PrintingService(port);
        ps.connect();
        return ps;
    }
}
