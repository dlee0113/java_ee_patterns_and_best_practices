package com.airhacks.effectivejavaee.business;

import com.airhacks.effectivejavaee.business.events.entity.AirEvent;
import java.util.concurrent.atomic.AtomicLong;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.ScheduleExpression;
import javax.ejb.Singleton;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.enterprise.event.Observes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

/**
 *
 * @author adam-bien.com
 */
@Path("statistics")
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class EventMonitor {

    private final static AtomicLong eventCount = new AtomicLong();

    private final static AtomicLong lastCount = new AtomicLong();

    @Resource
    private TimerService ts;
    private Timer timer;

    @PostConstruct
    public void onInit() {
        ScheduleExpression se = new ScheduleExpression();
        se.hour("*").minute("*").second("*/1");
        this.timer = ts.createCalendarTimer(se);
    }

    public void onRegistration(@Observes AirEvent event) {
        eventCount.incrementAndGet();
    }

    @Timeout
    public void computeStats() {
        System.out.println("---computing " + eventCount.get());
    }

    @GET
    @Path("eventsPerSecond")
    public String getEventsPerSecond() {
        return String.valueOf(eventCount.get());
    }
}
