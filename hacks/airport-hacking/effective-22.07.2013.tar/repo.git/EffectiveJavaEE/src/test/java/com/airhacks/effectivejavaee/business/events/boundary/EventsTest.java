package com.airhacks.effectivejavaee.business.events.boundary;

import com.airhacks.effectivejavaee.business.cics.control.PrintingService;
import com.airhacks.effectivejavaee.business.events.control.EventValidator;
import com.airhacks.effectivejavaee.business.events.entity.AirEvent;
import javax.enterprise.event.Event;
import javax.persistence.EntityManager;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.runners.MockitoJUnitRunner;

/**
 *
 * @author adam-bien.com
 */
@RunWith(MockitoJUnitRunner.class)
public class EventsTest {

    @InjectMocks
    Events cut;

    @Mock
    EntityManager em;

    @Mock
    EventValidator validator;

    @Mock
    PrintingService ps;

    @Mock
    Event<AirEvent> events;

    @Test(expected = IllegalArgumentException.class)
    public void creationWithInvalidState() {
        AirEvent event = new AirEvent();
        when(this.validator.isValid(Mockito.any(AirEvent.class))).thenReturn(false);
        cut.create(event);
    }

    @Test
    public void creationWithValidState() {
        AirEvent event = new AirEvent();
        when(this.validator.isValid(event)).thenReturn(true);
        cut.create(event);
        verify(this.em, times(1)).merge(event);
    }

}
