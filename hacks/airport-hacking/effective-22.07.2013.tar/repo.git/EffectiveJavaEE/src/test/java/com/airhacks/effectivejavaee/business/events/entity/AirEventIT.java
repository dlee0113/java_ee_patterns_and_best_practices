package com.airhacks.effectivejavaee.business.events.entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author adam-bien.com
 */
public class AirEventIT {

    private EntityManager em;
    private EntityTransaction tx;

    @Before
    public void initEM() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("it");
        this.em = emf.createEntityManager();
        this.tx = this.em.getTransaction();
    }

    @Test
    public void crud() {
        this.tx.begin();
        AirEvent expected = this.em.merge(new AirEvent("javaee", "rocks"));
        this.tx.commit();

        this.em.clear();
        AirEvent actual = this.em.find(AirEvent.class, expected.getName());

        assertThat(actual.getName(), is(expected.getName()));

    }

}
