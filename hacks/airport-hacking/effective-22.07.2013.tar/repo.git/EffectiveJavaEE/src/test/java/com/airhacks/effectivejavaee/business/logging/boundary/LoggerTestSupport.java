package com.airhacks.effectivejavaee.business.logging.boundary;

import java.util.logging.Logger;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class LoggerTestSupport {

    @Inject
    private Logger log;

    public Logger getLog() {
        return log;
    }

}
