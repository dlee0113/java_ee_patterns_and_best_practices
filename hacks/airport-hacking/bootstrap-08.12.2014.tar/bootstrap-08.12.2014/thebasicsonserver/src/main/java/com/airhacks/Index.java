package com.airhacks;

import javax.enterprise.inject.Model;
import javax.inject.Inject;
import javax.validation.constraints.Size;

/**
 *
 * @author airhacks.com
 */
@Model
public class Index {

    @Inject
    Messenger messenger;

    @Size(min = 2, max = 5)
    private String duration;

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getMessage() {
        return messenger.hello();
    }

    public Object start() {
        System.out.println("Duration: " + duration);
        messenger.startProcess();
        return null;
    }

}
