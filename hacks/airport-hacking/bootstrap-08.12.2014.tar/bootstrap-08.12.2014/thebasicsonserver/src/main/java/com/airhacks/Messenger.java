package com.airhacks;

import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.Asynchronous;
import javax.ejb.ScheduleExpression;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.sql.DataSource;

/**
 *
 * @author airhacks.com
 */
@Singleton
@Startup
public class Messenger {

    @Resource
    DataSource ds;

    @Resource
    TimerService ts;
    private Timer timer;

    @PostConstruct
    public void init() {
        System.out.println("I'm created = " + this + " with " + ds);
        ScheduleExpression se = new ScheduleExpression();
        se.minute("*").second("*/2").hour("*");
        this.timer = ts.createCalendarTimer(se);
    }

    @PreDestroy
    public void destroy() {
        System.out.println("Freing resources!");
    }

    @Timeout
    public void maintainCache() {
        System.out.println("Cache maintained: " + new Date());
    }

    public String hello() {
        return "hello attendees! " + new Date();
    }

    @Asynchronous
    public void startProcess() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Messenger.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Started !");
    }

}
