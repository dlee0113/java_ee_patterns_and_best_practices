package com.airhacks;

/**
 *
 * @author airhacks.com
 */
public class Flight {

    private String nbr;
    private int capacity;

    public Flight(String nbr, int capacity) {
        this.nbr = nbr;
        this.capacity = capacity;
    }

    public String getNbr() {
        return nbr;
    }

    public int getCapacity() {
        return capacity;
    }

}
