package com.airhacks;

import java.util.ArrayList;
import java.util.List;
import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import org.junit.Test;

/**
 *
 * @author airhacks.com
 */
public class NewStuffTest {

    @Test
    public void capacity() {
        List<Flight> flights = new ArrayList<>();
        flights.add(new Flight("lh", 100));
        flights.add(new Flight("lh", 300));
        flights.add(new Flight("ab", 200));

        double averageLoad = flights.parallelStream().
                filter(f -> "lh".equals(f.getNbr())).
                mapToInt((f) -> f.getCapacity()).average().orElse(0);

        System.out.println("averageLoad = " + averageLoad);
    }

    @Test
    public void aLittleDucks() throws ScriptException {

        Runnable run = dynamic();
        run.run();
    }

    public void anotherVoidMethod() {
        System.out.println("Executing asynchronously");
    }

    public Runnable dynamic() throws ScriptException {

        ScriptEngineManager sem = new ScriptEngineManager();
        ScriptEngine js = sem.getEngineByName("javascript");
        Invocable invocable = (Invocable) js;
        js.eval("function run(){ print('javascript is running!');}");
        return invocable.getInterface(Runnable.class);

    }

}
