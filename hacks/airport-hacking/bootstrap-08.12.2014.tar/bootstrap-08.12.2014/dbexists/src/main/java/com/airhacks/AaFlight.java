package com.airhacks;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author airhacks.com
 */
@Entity
@Table(name = "AA_FLIGHT")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "AaFlight.findAll", query = "SELECT a FROM AaFlight a"),
    @NamedQuery(name = "AaFlight.findById", query = "SELECT a FROM AaFlight a WHERE a.id = :id"),
    @NamedQuery(name = "AaFlight.findByFlightnumber", query = "SELECT a FROM AaFlight a WHERE a.flightnumber = :flightnumber")})
public class AaFlight implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Size(max = 255)
    @Column(name = "FLIGHTNUMBER")
    private String flightnumber;

    public AaFlight() {
    }

    public AaFlight(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFlightnumber() {
        return flightnumber;
    }

    public void setFlightnumber(String flightnumber) {
        this.flightnumber = flightnumber;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AaFlight)) {
            return false;
        }
        AaFlight other = (AaFlight) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.airhacks.AaFlight[ id=" + id + " ]";
    }

}
