package com.airhacks;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author airhacks.com
 */
@Stateless
public class AaFlightFacade extends AbstractFacade<AaFlight> {
    @PersistenceContext(unitName = "com.airhacks_dbexists_war_1.0-SNAPSHOTPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AaFlightFacade() {
        super(AaFlight.class);
    }

}
