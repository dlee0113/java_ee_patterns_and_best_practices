package thebasics;

/**
 *
 * @author airhacks.com
 */
public class UserInterface {

    @Airhacks
    private Service service;

    private String message;

    @Override
    public String toString() {
        return "UserInterface{" + "service=" + service + '}';
    }

}
