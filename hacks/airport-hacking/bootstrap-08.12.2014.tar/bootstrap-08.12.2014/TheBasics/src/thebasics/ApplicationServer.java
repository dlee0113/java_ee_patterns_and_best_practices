package thebasics;

import java.lang.reflect.Field;

/**
 *
 * @author airhacks.com
 */
public class ApplicationServer {

    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class<?> clazz = Class.forName("thebasics.UserInterface");
        Object instance = clazz.newInstance();
        System.out.println(clazz.getName());

        Field[] declaredFields = clazz.getDeclaredFields();
        for (Field field : declaredFields) {
            System.out.println("field = " + field);
            if (field.isAnnotationPresent(Airhacks.class)) {
                System.out.println("Is annotated = " + field);
                Class<?> type = field.getType();
                System.out.println("type = " + type);
                field.setAccessible(true);
                Object serviceInstance = type.newInstance();
                field.set(instance, serviceInstance);
                System.out.println("instance = " + instance);

            } else {
                System.out.println("is not annotated = " + field);
            }
        }
    }

}
