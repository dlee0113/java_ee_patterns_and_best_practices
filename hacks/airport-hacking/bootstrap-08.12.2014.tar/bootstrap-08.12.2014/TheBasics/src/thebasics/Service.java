package thebasics;

/**
 *
 * @author airhacks.com
 */
public class Service {

}
