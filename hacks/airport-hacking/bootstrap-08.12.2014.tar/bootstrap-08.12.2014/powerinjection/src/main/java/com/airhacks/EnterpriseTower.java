package com.airhacks;

/**
 *
 * @author airhacks.com
 */
@Airfield(Airfield.Size.BIG)
public class EnterpriseTower implements Tower {

    @Override
    public String flights() {
        return " ivory tower with interface";
    }

}
