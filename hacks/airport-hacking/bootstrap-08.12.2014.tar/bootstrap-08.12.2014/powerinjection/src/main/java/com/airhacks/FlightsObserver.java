package com.airhacks;

import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author airhacks.com
 */
public class FlightsObserver {

    public void onsuccess(@Observes(during = TransactionPhase.AFTER_SUCCESS) String flight) {
        System.out.println("++++ flight = " + flight);
    }

    public void onfailure(@Observes(during = TransactionPhase.AFTER_FAILURE) String flight) {
        System.out.println("----- flight = " + flight);
    }

}
