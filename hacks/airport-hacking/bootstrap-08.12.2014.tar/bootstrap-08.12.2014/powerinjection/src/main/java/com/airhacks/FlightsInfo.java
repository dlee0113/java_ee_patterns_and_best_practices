package com.airhacks;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author airhacks.com
 */
@Stateless
public class FlightsInfo {

    @Inject
    @Airfield(Airfield.Size.BIG)
    Tower tower;

    @Inject
    LegacyMessenger lm;

    @Inject
    Event<String> events;

    @Resource
    SessionContext sc;

    @PersistenceContext
    EntityManager em;

    public String allFlights() {
        String flights = tower.flights();
        events.fire(flights);
        Flight attachedFlight = em.merge(new Flight(flights));
        attachedFlight.setCapacity(42);
        return flights;

    }

}
