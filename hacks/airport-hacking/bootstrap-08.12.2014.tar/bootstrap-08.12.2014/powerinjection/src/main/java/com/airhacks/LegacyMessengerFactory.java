package com.airhacks;

import javax.enterprise.inject.Produces;

/**
 *
 * @author airhacks.com
 */
public class LegacyMessengerFactory {

    @Produces
    public LegacyMessenger doesnotmatter() {
        LegacyMessenger lm = new LegacyMessenger("Duke");
        lm.init();
        return lm;
    }

}
