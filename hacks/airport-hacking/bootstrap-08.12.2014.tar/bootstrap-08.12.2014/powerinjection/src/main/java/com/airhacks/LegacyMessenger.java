package com.airhacks;

/**
 *
 * @author airhacks.com
 */
public class LegacyMessenger {

    private String prefix;

    public LegacyMessenger(String prefix) {
        this.prefix = prefix;
    }

    public void init() {
        this.prefix += " Enterprise";
    }

    public String getPrefix() {
        return "Hello " + prefix;
    }

}
