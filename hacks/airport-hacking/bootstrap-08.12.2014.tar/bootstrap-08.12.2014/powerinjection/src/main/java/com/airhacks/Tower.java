package com.airhacks;

/**
 *
 * @author airhacks.com
 */
public interface Tower {

    public String flights();

}
