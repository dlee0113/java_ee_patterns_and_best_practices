package com.airhacks;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

/**
 *
 * @author airhacks.com
 */
@Stateless
@Path("flights")
public class FlightsResource {

    @Inject
    FlightsInfo info;

    @GET
    public Flight all() {
        return new Flight("lh-42");//info.allFlights();
    }

    @POST
    public void save(String flight) {
        System.out.println("flight = " + flight);
    }

    @GET
    @Path("{flightNbr}-{name}")
    public JsonObject byId(@PathParam("flightNbr") long nbr, @PathParam("name") String name) {
        return Json.createObjectBuilder().
                add("flightNbr", nbr).add("name", name).build();
    }

    @DELETE
    @Path("{flightNbr}-{name}")
    public void remove(@PathParam("flightNbr") long nbr, @PathParam("name") String name) {
        System.out.println("to kill name:" + nbr + name);
    }

}
