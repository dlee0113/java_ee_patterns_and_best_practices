package com.airhacks;

/**
 *
 * @author airhacks.com
 */
@Airfield(Airfield.Size.SMALL)
public class FieldTower implements Tower {

    @Override
    public String flights() {
        return "village";
    }

}
