package com.airhacks;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author airhacks.com
 */
@Table(name = "AA_FLIGHT")
@Entity

@NamedQueries({
    @NamedQuery(name = "all", query = "SELECT f FROM Flight f"),
    @NamedQuery(name = "capacity", query = "SELECT f FROM Flight f WHERE f.capacity"
            + "= :capacity")
})
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
//@Inheritance(strategy = )
public class Flight {

    @Id
    @GeneratedValue
    private long id;
    private String flightNumber;
    private int capacity;

    @Version
    private long version;

    @OneToOne
    private Passenger passenger;

    public Flight(String flightNumber) {
        this.flightNumber = flightNumber;
        this.passenger = new Passenger("duke");
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public Flight() {
    }

}
