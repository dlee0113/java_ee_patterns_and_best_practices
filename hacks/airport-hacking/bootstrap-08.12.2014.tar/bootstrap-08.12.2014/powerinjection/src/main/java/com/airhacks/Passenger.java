package com.airhacks;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author airhacks.com
 */
@Entity
@Table(name = "AA_passenger")
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Passenger {

    @Id
    private String firstName;

    public Passenger(String firstName) {
        this.firstName = firstName;
    }

    public Passenger() {
    }

}
