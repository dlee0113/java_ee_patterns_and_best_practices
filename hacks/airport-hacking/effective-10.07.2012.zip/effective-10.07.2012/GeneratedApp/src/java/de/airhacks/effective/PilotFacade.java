/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.effective;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
@Stateless
public class PilotFacade extends AbstractFacade<Pilot> {
    @PersistenceContext(unitName = "GeneratedAppPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PilotFacade() {
        super(Pilot.class);
    }
    
}
