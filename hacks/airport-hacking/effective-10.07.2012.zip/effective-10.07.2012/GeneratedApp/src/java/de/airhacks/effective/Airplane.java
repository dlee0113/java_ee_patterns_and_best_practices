/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.effective;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
@Entity
@Table(name = "AIRPLANE")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Airplane.findAll", query = "SELECT a FROM Airplane a"),
    @NamedQuery(name = "Airplane.findByFlightnumber", query = "SELECT a FROM Airplane a WHERE a.flightnumber = :flightnumber"),
    @NamedQuery(name = "Airplane.findByDescription", query = "SELECT a FROM Airplane a WHERE a.description = :description")})
public class Airplane implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "FLIGHTNUMBER")
    private Long flightnumber;
    @Size(max = 255)
    @Column(name = "DESCRIPTION")
    private String description;
    @JoinColumn(name = "PILOT_NAME", referencedColumnName = "NAME")
    @ManyToOne
    private Pilot pilotName;

    public Airplane() {
    }

    public Airplane(Long flightnumber) {
        this.flightnumber = flightnumber;
    }

    public Long getFlightnumber() {
        return flightnumber;
    }

    public void setFlightnumber(Long flightnumber) {
        this.flightnumber = flightnumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Pilot getPilotName() {
        return pilotName;
    }

    public void setPilotName(Pilot pilotName) {
        this.pilotName = pilotName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (flightnumber != null ? flightnumber.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Airplane)) {
            return false;
        }
        Airplane other = (Airplane) object;
        if ((this.flightnumber == null && other.flightnumber != null) || (this.flightnumber != null && !this.flightnumber.equals(other.flightnumber))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "de.airhacks.effective.Airplane[ flightnumber=" + flightnumber + " ]";
    }
    
}
