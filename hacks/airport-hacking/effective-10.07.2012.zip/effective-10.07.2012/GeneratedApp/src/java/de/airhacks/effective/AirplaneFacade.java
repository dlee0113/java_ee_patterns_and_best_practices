/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.effective;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
@Stateless
public class AirplaneFacade extends AbstractFacade<Airplane> {
    @PersistenceContext(unitName = "GeneratedAppPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AirplaneFacade() {
        super(Airplane.class);
    }
    
}
