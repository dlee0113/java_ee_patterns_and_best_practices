#!/bin/bash
#GLASSFISH_HOME=/data/opt/glassfish3.1.2
DRIVERS_DIR=.
$GLASSFISH_HOME/bin/asadmin stop-domain x-ray
$GLASSFISH_HOME/bin/asadmin delete-domain x-ray
$GLASSFISH_HOME/bin/asadmin create-domain --portbase 5300 --nopassword=true x-ray
echo Domain created, copying JARs
cp $DRIVERS_DIR/jdbc-drivers/hsql2/* $GLASSFISH_HOME/glassfish/domains/x-ray/lib/ext
$GLASSFISH_HOME/bin/asadmin start-domain x-ray
#$GLASSFISH_HOME/bin/asadmin delete-jvm-options -Xmx512m --port 5348
$GLASSFISH_HOME/bin/asadmin create-jvm-options -Xmx4096m --port 5348
$GLASSFISH_HOME/bin/asadmin create-jdbc-connection-pool  --port 5348 --datasourceclassname org.hsqldb.jdbc.JDBCDataSource --restype javax.sql.ConnectionPoolDataSource --property "User=XRAY:Password=XRAY:Database=jdbc\\:hsqldb\\:hsql\\://localhost\\:9093/x-ray" hsqldb
$GLASSFISH_HOME/bin/asadmin create-jdbc-resource --port 5348 --connectionpoolid hsqldb jdbc/hitscounter
$GLASSFISH_HOME/bin/asadmin change-admin-password --domain_name x-ray
$GLASSFISH_HOME/bin/asadmin enable-secure-admin --port 5348

