/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.launchr.business.order;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class PizzaValidator implements ConstraintValidator<Taste, String> {
    private Taste taste;
    
    @Override
    public void initialize(Taste taste) {
        this.taste = taste;
    }
    
    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return (value != null && value.startsWith(this.taste.value()[0]));
    }
}
