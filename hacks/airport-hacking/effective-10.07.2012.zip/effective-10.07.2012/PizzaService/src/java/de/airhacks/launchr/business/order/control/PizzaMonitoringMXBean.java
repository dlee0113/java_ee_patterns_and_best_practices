/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.launchr.business.order.control;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public interface PizzaMonitoringMXBean {
    
    public long getReadyPizzas();
    
    public void reset();
}
