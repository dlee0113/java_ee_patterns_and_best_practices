package de.airhacks.launchr.business.order.control;

import de.airhacks.launchr.business.order.entity.Pizza;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class PizzaProgressMonitor {

    public void onReadyPizza(@Observes(during= TransactionPhase.AFTER_SUCCESS) Pizza pizza){
        System.out.println(":-)) Pizza is done: " + pizza);
    }

    public void complainSink(@Observes(during= TransactionPhase.AFTER_FAILURE) Pizza pizza){
        System.out.println(":-(( " + pizza);
    }
}
