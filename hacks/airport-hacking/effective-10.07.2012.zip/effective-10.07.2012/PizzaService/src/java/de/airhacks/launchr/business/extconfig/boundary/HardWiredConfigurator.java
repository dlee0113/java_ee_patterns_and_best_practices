/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.launchr.business.extconfig.boundary;

import de.airhacks.launchr.business.configuration.boundary.Configurator;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.Specializes;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.faces.application.ProjectStage;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class HardWiredConfigurator extends Configurator{

    @Override @Produces @Specializes
    public int getInt(InjectionPoint ip, ProjectStage ps) {
        return 6;
    }
    
}
