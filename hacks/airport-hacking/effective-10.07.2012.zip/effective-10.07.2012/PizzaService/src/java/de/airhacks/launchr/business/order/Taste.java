/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.launchr.business.order;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
@Documented
@Constraint(validatedBy = PizzaValidator.class)
@Target({ElementType.METHOD, ElementType.FIELD, ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface Taste {
    String[] value();
    String message() default "Go eat dueruem!";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
