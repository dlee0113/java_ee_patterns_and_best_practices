package de.airhacks.launchr.business.order.control;

import de.airhacks.launchr.business.order.entity.Pizza;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
@Stateless
public class Cook {

    @Resource
    SessionContext sc;
    
    @Inject
    Event<Pizza> notificator;
    
    @Asynchronous
    public Future<Pizza> cook(Pizza pizza){
        try {
            //used for communication with future
            //---> future.cancel()
            sc.wasCancelCalled();
            Thread.sleep(2000);
            pizza.setDone(true);
            notificator.fire(pizza);
        } catch (InterruptedException ex) {
            Logger.getLogger(Cook.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new AsyncResult<Pizza>(pizza);
    }
}   
