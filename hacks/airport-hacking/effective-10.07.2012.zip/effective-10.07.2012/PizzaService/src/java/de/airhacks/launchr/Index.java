package de.airhacks.launchr;

import de.airhacks.launchr.BackingBean;
import de.airhacks.launchr.business.order.boundary.LaunchService;
import de.airhacks.launchr.business.order.entity.Pizza;
import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.faces.application.ProjectStage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;


@BackingBean
public class Index {
 
    @Inject
    LaunchService ls;
    private Pizza pizza;
    
    @PostConstruct
    public void init(){
        this.pizza = new Pizza();
    }

    public Pizza getPizza() {
        return pizza;
    }
    
    public Object order(){
        this.ls.order(pizza);
        return null;
    }
    
    @Produces
    public ProjectStage expose(){
        return FacesContext.getCurrentInstance().getApplication().getProjectStage();
    }
}
