/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.launchr.business.configuration.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.faces.application.ProjectStage;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class Configurator {
    

    @Produces
    public int getInt(InjectionPoint ip,ProjectStage ps){
        String clazz = ip.getMember().getDeclaringClass().getName();
        String fieldName = ip.getMember().getName();
        System.out.println("!!!!! Configuring: " + clazz + "." + fieldName + " for stage: " + ps.name());
        return 5;
    }
}
