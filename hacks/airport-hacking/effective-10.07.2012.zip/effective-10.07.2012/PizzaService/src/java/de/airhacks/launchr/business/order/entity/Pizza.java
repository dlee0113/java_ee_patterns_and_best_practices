/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.launchr.business.order.entity;

import de.airhacks.launchr.business.order.Taste;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
@Table(name="AIR_PIZZA")
@Entity
public class Pizza {
    
    @Id
    @GeneratedValue
    private long id;
    
    @Min(1)
    @Max(43)
    @Column(name="a_size")
    private int size;
    
    @Taste({"calzione","vegetable?"})
    @Size(min=3,max=20)
    private String name;

    private boolean done;
    
    public Pizza() {
    }

    public Pizza(int size, String name) {
        this.size = size;
        this.name = name;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Pizza{" + "size=" + size + ", name=" + name + '}';
    }

    public boolean isDone() {
        return done;
    }

    public void setDone(boolean done) {
        this.done = done;
    }
    
    
    
    
    
}
