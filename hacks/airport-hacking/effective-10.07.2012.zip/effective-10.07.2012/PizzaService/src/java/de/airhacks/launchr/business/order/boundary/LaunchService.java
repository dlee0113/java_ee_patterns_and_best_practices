package de.airhacks.launchr.business.order.boundary;

import de.airhacks.launchr.business.configuration.boundary.Stage;
import de.airhacks.launchr.business.order.control.Cook;
import de.airhacks.launchr.business.order.entity.Pizza;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class LaunchService {
    
    @Inject @Stage(Stage.Level.PRODUCTION)
    EntityManager em;
    
    @Inject
    Cook cook;
    
    @Resource
    SessionContext sc;
    
    @Inject
    private int nrOfAttendees;
    
    public void order(Pizza pizza){
        em.persist(pizza);
        List<Future<Pizza>> pizzaRequests = new ArrayList<Future<Pizza>>();
        System.out.println("Iterating: " + nrOfAttendees + " times !");
        for (int i = 0; i < nrOfAttendees; i++) {
            pizzaRequests.add(cook.cook(pizza));
        }
        for (Future<Pizza> future : pizzaRequests) {
            try {
                Pizza ready = future.get();
            } catch (Exception ex) {
                Logger.getLogger(LaunchService.class.getName()).log(Level.SEVERE, null, ex);
                sc.setRollbackOnly();
            } 

        }
    }
}
