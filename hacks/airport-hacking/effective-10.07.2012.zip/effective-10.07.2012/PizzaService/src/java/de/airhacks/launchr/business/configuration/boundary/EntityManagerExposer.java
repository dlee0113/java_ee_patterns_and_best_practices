/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.launchr.business.configuration.boundary;

import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class EntityManagerExposer {
    
    @PersistenceContext(unitName="prod")
    EntityManager prod;

    @PersistenceContext(unitName="test")
    EntityManager test;
    
    @Produces @Stage(Stage.Level.PRODUCTION)
    public EntityManager exposesProduction(){
        return prod;
    }

    @Produces @Stage(Stage.Level.TEST)
    public EntityManager exposesTest(){
        //or System.getProperty("stage")...
        return test;
    }
    
}
