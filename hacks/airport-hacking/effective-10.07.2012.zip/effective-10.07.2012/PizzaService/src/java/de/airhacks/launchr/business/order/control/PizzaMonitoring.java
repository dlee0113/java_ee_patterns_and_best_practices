package de.airhacks.launchr.business.order.control;

import de.airhacks.launchr.business.order.entity.Pizza;
import java.lang.management.ManagementFactory;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.LocalBean;
import javax.ejb.LocalHome;
import javax.ejb.Singleton;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanRegistrationException;
import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

@LocalBean
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class PizzaMonitoring implements PizzaMonitoringMXBean{

    AtomicLong counter;
    private MBeanServer jmxServer;
    private ObjectName objectName;
    
    @PostConstruct
    public void onInit(){
        this.counter = new AtomicLong();
        this.jmxServer = ManagementFactory.getPlatformMBeanServer();
        try {
            objectName = new ObjectName("PizzaMonitor:type=" + this.getClass().getName());
            //SessionContext#getBusinessObject would be better here
            this.jmxServer.registerMBean(this, objectName);
        } catch (Exception ex) {
            throw new IllegalStateException("Name is wrong",ex);
        } 
    }
    
    @PreDestroy
    public void onShutdown(){
        try {
            this.jmxServer.unregisterMBean(objectName);
        } catch (InstanceNotFoundException ex) {
            Logger.getLogger(PizzaMonitoring.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MBeanRegistrationException ex) {
            Logger.getLogger(PizzaMonitoring.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void onReadyPizza(@Observes(during= TransactionPhase.AFTER_SUCCESS) Pizza pizza){
        this.counter.incrementAndGet();
    }

    
    @Override
    public long getReadyPizzas() {
        return this.counter.get();
    }

    @Override
    public void reset() {
        this.counter.set(0);
    }

}
