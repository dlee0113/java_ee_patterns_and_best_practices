/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.launchr.business.configuration.boundary;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.inject.Qualifier;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
@Qualifier
@Target({ElementType.FIELD, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Stage {
 
    Level value();
    
    enum Level{
        PRODUCTION,TEST
    }
}
