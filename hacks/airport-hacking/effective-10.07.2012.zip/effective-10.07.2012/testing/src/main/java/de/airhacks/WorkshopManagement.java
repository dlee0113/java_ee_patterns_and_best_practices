/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks;

import javax.inject.Inject;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class WorkshopManagement {
   
    @Inject
    AttendeeRegistration ar;
    
    
    public boolean registered(){
        return "works".equals(ar.register());
    }
    
    
}
