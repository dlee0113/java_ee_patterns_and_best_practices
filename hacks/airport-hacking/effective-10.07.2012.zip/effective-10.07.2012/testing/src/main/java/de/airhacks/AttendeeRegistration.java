/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks;

import javax.enterprise.inject.Instance;
import javax.inject.Inject;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class AttendeeRegistration {
    
    @Inject
    Instance<Certificate> certificates;
    
    public String register(){
        return "works";
    }
    
    public boolean willAttend(){
        return !certificates.isUnsatisfied();
    }
}
