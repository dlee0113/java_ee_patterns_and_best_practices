/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class BootstrapCertificate implements Certificate{

    @Override
    public void sign() {
        System.out.println("Thanks!");
    }
    
}
