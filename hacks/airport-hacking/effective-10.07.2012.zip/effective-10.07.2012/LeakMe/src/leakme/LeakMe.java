/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package leakme;

import de.airhacks.donttrythat.MainLeakager;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class LeakMe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        MainLeakager leakager = new MainLeakager();
        while(true){
            leakager.add();
            Thread.sleep(10);
        }
    }
}
