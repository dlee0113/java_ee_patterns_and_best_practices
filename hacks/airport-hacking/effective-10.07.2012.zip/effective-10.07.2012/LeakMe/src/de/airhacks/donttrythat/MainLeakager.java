/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.donttrythat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class MainLeakager {
    
    private List<Date> dates;

    public MainLeakager() {
        this.dates = new ArrayList<Date>();
    }
    
    public void add(){
         dates.add(new Date());
    }
    
    
}
