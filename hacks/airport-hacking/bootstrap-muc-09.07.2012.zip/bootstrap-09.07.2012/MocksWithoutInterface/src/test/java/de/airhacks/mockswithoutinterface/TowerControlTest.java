/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.mockswithoutinterface;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import static org.mockito.Mockito.*;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class TowerControlTest {
    TowerControl tc;
    @Before
    public void inject(){
        tc = new TowerControl();
        tc.df = mock(DonerFactory.class);
    }
    @Test(expected=IllegalStateException.class)
    public void orderWithoutTaste() {
        when(tc.df.tastesGood()).thenReturn(false);
        tc.order();
    }
}
