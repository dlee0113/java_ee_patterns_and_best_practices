package de.airhacks.mockswithoutinterface;

import javax.inject.Inject;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class TowerControl {
    
    @Inject
    DonerFactory df;
    
    public void order(){
        if(!df.tastesGood())
            throw new IllegalStateException("No launch today!");
    }
}
