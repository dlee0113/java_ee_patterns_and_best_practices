/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks.injection;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
class Service {
    
}
