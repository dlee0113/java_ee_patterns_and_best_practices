package com.airhacks.injection;

/**
 *
 * @author Adam Bien, adam-bien.com
 */

public class Dialog {
    @AirJect
    private Service service;
    
    private String notAnnotatedString;
}
