/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package injector;

import com.airhacks.injection.AirJect;
import java.lang.reflect.Field;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class Injector {

    public static void main(String[] args) throws Exception {
        //0. Searching for beans.xml
        //1. Iterating over files and loading as classes
        Class clazz = Class.forName("com.airhacks.injection.Dialog");
        Object injectionTarget = clazz.newInstance();
                
        Field[] declaredFields = clazz.getDeclaredFields();
        for (Field field : declaredFields) {
            if(field.isAnnotationPresent(AirJect.class)){
                System.out.println("Annotated: " + field);
                field.setAccessible(true);
                //homework
                //field.set(args, args);
            }else{
                System.out.println("Not annotated: " + field);
            }
            
        }
    }
}
