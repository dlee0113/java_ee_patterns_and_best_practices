/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.tower;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
@Checks(Checks.Level.UNSECURE)
public class SecurityImpl2 implements Security{

    @Override
    public void check() {
        System.out.println("Unsecured!");
    }
    
}
