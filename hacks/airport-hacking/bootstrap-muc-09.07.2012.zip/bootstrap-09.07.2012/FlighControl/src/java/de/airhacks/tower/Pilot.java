/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.tower;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
@Entity
public class Pilot {
    @Id
    private String name;

    public Pilot() {
    }

    public Pilot(String name) {
        this.name = name;
    }
    
}
