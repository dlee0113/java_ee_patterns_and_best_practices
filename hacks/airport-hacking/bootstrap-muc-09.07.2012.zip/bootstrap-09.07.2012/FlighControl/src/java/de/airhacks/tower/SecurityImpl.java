package de.airhacks.tower;

@Checks(Checks.Level.SECURE)
public class SecurityImpl implements Security{
    
    @Override
    public void check(){
        System.out.println("Checked!");
    }
}
