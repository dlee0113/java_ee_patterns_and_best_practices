/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.tower;

import javax.enterprise.inject.Produces;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class DoenerFactory {
    
    @Produces
    public AirportOliva create(){
        return new AirportOliva("chicken");
    }
}
