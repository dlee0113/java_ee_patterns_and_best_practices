package de.airhacks.tower;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public class PushBackVehicle {

    @PersistenceContext
    EntityManager em;

    public void pushBack() {
        final AirPlane airPlane = new AirPlane("flying dukes are pushing back");
        em.persist(airPlane);
        airPlane.setDescription("I'm lazy");
        System.out.println("Pushing is done!");
    }
}
