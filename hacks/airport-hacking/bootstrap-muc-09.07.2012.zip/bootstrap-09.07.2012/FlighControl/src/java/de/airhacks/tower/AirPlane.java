/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.tower;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.Size;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
@Entity
public class AirPlane {
    
    @Id
    @GeneratedValue
    private long flightNumber;
    @Size(min=2,message="Stupid?")
    private String description;
    
    @OneToOne(cascade= CascadeType.ALL)
    private Pilot pilot;

    public AirPlane(String description) {
        this.description = description;
        this.pilot = new Pilot("duke");
    }
    public AirPlane() {
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
    
    

    public long getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(long flightNumber) {
        this.flightNumber = flightNumber;
    }

    public Pilot getPilot() {
        return pilot;
    }

    public void setPilot(Pilot pilot) {
        this.pilot = pilot;
    }
    

    
    
    
}
