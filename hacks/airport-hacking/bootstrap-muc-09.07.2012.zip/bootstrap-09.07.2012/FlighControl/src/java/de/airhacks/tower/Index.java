package de.airhacks.tower;

import java.util.Set;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Model;
import javax.inject.Inject;
import javax.inject.Named;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

@Named
@RequestScoped
public class Index {
    
    @Inject
    TowerControl tc;
    
    @Inject
    Validator validator;

    
    AirPlane airPlane;
    
    @PostConstruct
    public void initialize(){
        this.airPlane = new AirPlane();
    }

    public AirPlane getAirPlane() {
        return airPlane;
    }
    
    public String getGreeting(){
        return tc.getMessage();
    }
    
    public Object save(){
        Set<ConstraintViolation<AirPlane>> validate = this.validator.validate(this.airPlane, new Class[]{});
        System.out.println("Airplane: " + this.airPlane);
        
        return null;
    }
}
