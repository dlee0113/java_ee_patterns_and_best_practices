package de.airhacks.tower;

import java.net.URI;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("meals")
@Stateless
@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
public class LaunchResource {
    
    @GET
    public Meal meals(@Context HttpHeaders headers){
        return new Meal("dueruem", 42);
    }
    
    @GET
    @Path("{id}-{name}")
    public Meal meal(@PathParam("id") int id,@PathParam("name") String name){
        return new Meal(name, id);
    }
   
    @POST
    @Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    public Response order(Meal meal){
        System.out.println("Meal: " + meal);
        URI create = URI.create("/"+System.currentTimeMillis());
        return Response.created(create).header("hey", "joe").build();
    }
}
