package de.airhacks.tower;

import java.util.Date;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.validation.Valid;
import javax.validation.Validator;

@Interceptors(PilotUnion.class)
@Stateless
public class TowerControl {

    
    TowerControl that;
    
    @Resource
    SessionContext sc;
    
    @Inject
    PushBackVehicle pbv;
    
    @Inject @Any 
    Instance<Security> checks;
    
    @Inject
    AirportOliva df;
    
    
    //either @PostConstruct or @Inject that
    @PostConstruct
    public void fetchProxy(){
        that = sc.getBusinessObject(TowerControl.class);
    }
    
    public String getMessage(){
        that.notifyPilots();
        pbv.pushBack();
        for (Security security : checks) {
            System.out.println("--- " + security);
        }
        this.df.order();
        return "hello: " + new Date();
    }
    
    @TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
    public void notifyPilots(){
        System.out.println("---notifying");
    }
}
