package de.airhacks.tower;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Meal {
    
    private String name;
    private int amount;

    public Meal(String name, int amount) {
        this.name = name;
        this.amount = amount;
    }

    public Meal() {
    }

    @Override
    public String toString() {
        return "Meal{" + "name=" + name + ", amount=" + amount + '}';
    }
}
