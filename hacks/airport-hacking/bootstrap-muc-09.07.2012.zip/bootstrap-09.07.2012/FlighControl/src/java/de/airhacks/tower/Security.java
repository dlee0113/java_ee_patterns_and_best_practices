/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package de.airhacks.tower;

/**
 *
 * @author Adam Bien, adam-bien.com
 */
public interface Security {
    public void check();
}
