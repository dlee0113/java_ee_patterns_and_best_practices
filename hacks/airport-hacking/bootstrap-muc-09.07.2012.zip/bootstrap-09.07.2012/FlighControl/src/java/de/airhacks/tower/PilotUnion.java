package de.airhacks.tower;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class PilotUnion {

    @AroundInvoke
    public Object auditOverwork(InvocationContext ic) throws Exception{
        System.out.println("-+++-- " + ic.getMethod());
        return ic.proceed();
    }

}
