package de.airhacks.tower;

public class AirportOliva {

    private String meat;

    public AirportOliva(String meat) {
        this.meat = meat;
    }

    public void order(){
        System.out.println("Here is your doener with: " + this.meat);
    }
    
    @Override
    public String toString() {
        return "DoenerFactory{" + "meat=" + meat + '}';
    }
    
    
}
