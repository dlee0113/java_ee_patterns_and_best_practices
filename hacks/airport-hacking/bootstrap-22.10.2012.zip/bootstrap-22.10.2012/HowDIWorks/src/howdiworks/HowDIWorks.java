package howdiworks;

import java.lang.reflect.Field;

public class HowDIWorks {
    public static void main(String[] args) throws Exception {
        Class<?> forName = Class.forName("howdiworks.MyBean");
        Field[] declaredFields = forName.getDeclaredFields();
        for (Field field : declaredFields) {
            MyInject annotation = field.getAnnotation(MyInject.class);
            if(annotation != null){
                System.out.println("###### " + field.getName());
                //field.setAccessible(true);
                //field.set(forName.newInstance(), "hello");
            }
        }
    }
}
