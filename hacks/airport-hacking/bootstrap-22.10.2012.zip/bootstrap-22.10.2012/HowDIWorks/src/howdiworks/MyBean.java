/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package howdiworks;

/**
 *
 * @author abien
 */
public class MyBean {
    
    @MyInject
    private String hello;
}
