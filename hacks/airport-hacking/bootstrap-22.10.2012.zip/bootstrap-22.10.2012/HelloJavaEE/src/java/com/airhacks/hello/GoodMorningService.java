package com.airhacks.hello;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
@Interceptors(Audit.class)
public class GoodMorningService {
    @PersistenceContext
    EntityManager em;

    @PostConstruct
    public void onInit(){
        System.out.println("EJB created");
    }
    
    public String greetings(){
            String message = "lightweight enterprise!";
            em.persist(new AirhackOne(message));
            return message;
    }
    //tx.commit
}
