package com.airhacks.hello;

import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;


@Named("hugo")
@RequestScoped
public class Index {
    
    @Inject
    GoodMorningService gms;
    
    private AirhackOne airhackOne;
    
    @PostConstruct
    public void onCreate(){
        System.out.println("Backing Bean created!");
        this.airhackOne = new AirhackOne();
    }

    public AirhackOne getAirhackOne() {
        return airhackOne;
    }
    
    public String getMessage(){
        return gms.greetings();
    }
    
    public Object ok(){
        System.out.println("--- " + airhackOne);
        return null;
    }
}
