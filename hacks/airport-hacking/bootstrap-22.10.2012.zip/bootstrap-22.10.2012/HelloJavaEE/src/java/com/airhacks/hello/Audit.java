package com.airhacks.hello;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class Audit {

    @AroundInvoke
    public Object trace(InvocationContext ic) throws Exception{
        System.out.println("------ " + ic.getMethod());
        return ic.proceed();
    }
    
}
