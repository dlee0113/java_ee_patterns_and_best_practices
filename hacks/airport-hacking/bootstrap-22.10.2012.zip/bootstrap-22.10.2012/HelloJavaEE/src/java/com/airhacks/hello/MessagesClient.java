/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks.hello;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author abien
 */
public class MessagesClient {
 
    
    public static void main(String[] args) {
        Client create = Client.create();
        WebResource resource = create.resource("http://localhost:8080/HelloJavaEE/resources/messages/");
        AirhackOne airhack = resource.accept(MediaType.APPLICATION_XML).get(AirhackOne.class);
        System.out.println("Airhack: " + airhack);
    }
}
