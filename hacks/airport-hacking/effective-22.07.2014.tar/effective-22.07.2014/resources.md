#Resources

http://en.wikipedia.org/wiki/HATEOAS
http://petstore.swagger.wordnik.com/#!/pet/updatePet
http://enunciate.codehaus.org
https://kenai.com/projects/suncloudapis/pages/HelloCloud
https://stripe.com/docs/examples
https://docs.docker.com/reference/api/docker_remote_api_v1.10/#33-cors-requests
http://en.wikipedia.org/wiki/Cryptographic_nonce
http://docs.jboss.org/resteasy/hornetq-rest/1.0-beta-1/userguide/html_single/
mvn archetype:generate -Dfilter=com.airhacks:
//execution of integration tests:
mvn failsafe:integration-test

http://www.robert-franz.com/2013/03/26/junit-rule-entity-manager/
htttpster
metawidget.org
nakedobjects / isis

jmeter -n (noUI) -c
connectorz.adam-bien.com
ironjacammar
c-jdbc
hessian (resin)
proto buffer (google)
thrift

x-ray github adam bien
ping / floyd
watchdock
ExceptionMapper
kryo 
