package com.airhacks.mealsandmore.business.menu.boundary;

import com.airhacks.mealsandmore.business.menu.entity.Meal;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.json.JsonObject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

/**
 *
 * @author airhacks.com
 */
@Stateless
@Path("meals")
public class MealsResource {

    @Inject
    MealCatalog mc;

    @GET
    @Path("{name}")
    public Meal meal(@PathParam("name") String name) {
        return mc.find(name);
    }

    @POST
    public void add(JsonObject input) {
        Meal meal = new Meal(input.getString("name"), input.getInt("price"));
        this.mc.save(meal);
    }

}
