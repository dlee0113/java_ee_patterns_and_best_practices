package com.airhacks.mealsandmore.business.menu.control;

/**
 *
 * @author airhacks.com
 */
public class Pricing {

    public int getPrice(String name) {
        return 21;
    }

}
