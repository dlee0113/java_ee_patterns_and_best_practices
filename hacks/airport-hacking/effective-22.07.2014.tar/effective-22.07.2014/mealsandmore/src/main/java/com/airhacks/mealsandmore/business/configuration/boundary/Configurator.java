package com.airhacks.mealsandmore.business.configuration.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author airhacks.com
 */
public class Configurator {

    @Produces
    public String configure(InjectionPoint ip) {
        String fqn = ip.getMember().getDeclaringClass().getName();
        String fieldName = ip.getMember().getName();
        String key = fqn + "." + fieldName;
        String value = key; //todo: resolve with EntityManager,Properties
        return value;
    }

}
