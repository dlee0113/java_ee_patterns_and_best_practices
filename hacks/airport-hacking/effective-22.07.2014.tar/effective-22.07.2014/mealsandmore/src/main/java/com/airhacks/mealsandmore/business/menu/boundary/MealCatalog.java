package com.airhacks.mealsandmore.business.menu.boundary;

import com.airhacks.mealsandmore.business.menu.control.Pricing;
import com.airhacks.mealsandmore.business.menu.entity.Meal;
import java.util.function.Consumer;
import javax.ejb.Stateless;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author airhacks.com
 */
@Stateless
public class MealCatalog {

    @Inject
    Pricing pricing;

    @Inject
    Consumer<String> LOG;

    @Inject
    Instance<String> name;

    @PersistenceContext
    EntityManager em;

    public Meal find(String name) {
        final int price = pricing.getPrice(name);
        if (price > 100) {
            LOG.accept("Have a nice day: " + name);
            throw new IllegalArgumentException("Doener is too expensive");
        }
        return new Meal(name, price);
    }

    public void save(Meal meal) {
        if (meal.isValid()) {
            this.em.merge(meal);
        }
    }

}
