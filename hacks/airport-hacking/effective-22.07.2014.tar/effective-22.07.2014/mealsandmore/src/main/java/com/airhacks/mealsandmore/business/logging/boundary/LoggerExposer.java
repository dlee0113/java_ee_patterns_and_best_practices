package com.airhacks.mealsandmore.business.logging.boundary;

import java.util.function.Consumer;
import java.util.logging.Logger;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author airhacks.com
 */
public class LoggerExposer {

    @Produces
    public Consumer<String> expose(InjectionPoint ip) {
        return Logger.getLogger(ip.getMember().getDeclaringClass().getName())::info;
    }

}
