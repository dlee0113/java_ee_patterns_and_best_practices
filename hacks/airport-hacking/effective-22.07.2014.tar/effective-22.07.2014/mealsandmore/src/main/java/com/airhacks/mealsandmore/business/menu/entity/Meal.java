package com.airhacks.mealsandmore.business.menu.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author airhacks.com
 */
@Table(name = "amm_meal")
@Entity
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Meal {

    @Id
    private String name;
    private int price;

    public Meal(String name, int price) {
        this.name = name;
        this.price = price;
    }

    public Meal() {
    }

    public boolean isValid() {
        return price < 100;
    }

}
