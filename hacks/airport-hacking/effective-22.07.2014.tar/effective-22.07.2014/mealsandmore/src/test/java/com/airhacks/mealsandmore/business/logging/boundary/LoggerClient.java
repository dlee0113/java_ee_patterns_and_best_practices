package com.airhacks.mealsandmore.business.logging.boundary;

import java.util.logging.Logger;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
public class LoggerClient {

    @Inject
    Logger logger;

    public Logger getLogger() {
        return logger;
    }

}
