package com.airhacks.mealsandmore.business.menu.entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author airhacks.com
 */
public class MealIT {

    private EntityManager em;
    private EntityTransaction tx;

    @Before
    public void injectEM() {
        this.em = Persistence.createEntityManagerFactory("it").createEntityManager();
        this.tx = this.em.getTransaction();
    }

    @Test
    public void crud() {
        this.tx.begin();
        this.em.merge(new Meal("duke", 42));
        this.tx.commit();
    }

}
