package com.airhacks.mealsandmore.business.menu.boundary;

import com.airhacks.mealsandmore.business.menu.control.Pricing;
import com.airhacks.mealsandmore.business.menu.entity.Meal;
import java.util.function.Consumer;
import javax.persistence.EntityManager;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

/**
 *
 * @author airhacks.com
 */
public class MealCatalogTest {

    MealCatalog cut;

    @Before
    public void inject() {
        this.cut = new MealCatalog();
        //spy expects a real object, but you can mock out "inconvenient methods"
        //this.cut.pricing = spy(new Pricing());
        this.cut.pricing = mock(Pricing.class);
        this.cut.em = mock(EntityManager.class);
        this.cut.LOG = mock(Consumer.class);
    }

    @Test(expected = IllegalArgumentException.class)
    public void findTooExpensive() {
        final String id = "doener";
        when(this.cut.pricing.getPrice(id)).thenReturn(101);
        this.cut.find(id);
    }

    @Test
    public void find() {
        final String id = "doener";
        when(this.cut.pricing.getPrice(id)).thenReturn(42);
        this.cut.find(id);
    }

    @Test
    public void saveInvalid() {
        final Meal meal = new Meal("expensive", 200);
        this.cut.save(meal);
        Mockito.verify(this.cut.em, never()).merge(meal);
    }

    @Test
    public void save() {
        final Meal meal = new Meal("ok", 99);
        this.cut.save(meal);
        Mockito.verify(this.cut.em, times(1)).merge(meal);
    }

}
