package com.airhacks.mealsandmore.business.menu.boundary;

import javax.json.JsonObject;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import static org.hamcrest.CoreMatchers.is;
import org.junit.Assert;
import static org.junit.Assert.assertNotNull;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author airhacks.com
 */
public class MealsResourceIT {

    private WebTarget tut;

    @Before
    public void initClient() {
        Client client = ClientBuilder.newClient();
        this.tut = client.target("http://localhost:8080/mealsandmore/v1/meals/");
    }

    @Test
    public void getMeal() {
        Response response = this.tut.path("doener").request(MediaType.APPLICATION_JSON).get();
        Assert.assertThat(response.getStatus(), is(200));
        JsonObject meal = response.readEntity(JsonObject.class);
        assertNotNull(meal);
        assertNotNull(meal.get("name"));
        System.out.println("--- " + meal);
    }

}
