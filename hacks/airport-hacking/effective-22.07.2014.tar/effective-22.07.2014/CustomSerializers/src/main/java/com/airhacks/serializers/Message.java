package com.airhacks.serializers;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author airhacks.com
 */
@XmlAccessorType
@XmlRootElement
public class Message {

    private String message;

    public Message(String message) {
        this.message = message;
    }

    public Message() {
    }

    @Override
    public String toString() {
        return "Extremely custom" + this.message;
    }

}
