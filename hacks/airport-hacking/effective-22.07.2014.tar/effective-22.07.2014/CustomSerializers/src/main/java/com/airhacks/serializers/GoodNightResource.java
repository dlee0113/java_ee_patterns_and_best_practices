package com.airhacks.serializers;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("greetings")
public class GoodNightResource {

    @GET
    @Produces({"airhacks/efficient", MediaType.APPLICATION_JSON})
    public Message greeting() {
        return new Message("gute nacht");
    }
}
