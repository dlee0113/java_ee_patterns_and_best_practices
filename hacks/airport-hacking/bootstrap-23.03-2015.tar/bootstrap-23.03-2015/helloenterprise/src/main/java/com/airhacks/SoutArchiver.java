package com.airhacks;

/**
 *
 * @author airhacks.com
 */
@Persistence(Persistence.Type.TRANSIENT)
public class SoutArchiver implements Archiver {

    @Override
    public void archive() {
        System.out.println("Archiving to sout");
    }

}
