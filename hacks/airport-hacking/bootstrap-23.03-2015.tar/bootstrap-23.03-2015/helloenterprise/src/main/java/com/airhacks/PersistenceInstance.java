package com.airhacks;

import java.lang.annotation.Annotation;

/**
 *
 * @author airhacks.com
 */
public class PersistenceInstance implements Persistence {

    private Type type;

    public PersistenceInstance(Type type) {
        this.type = type;
    }

    @Override
    public Type value() {
        return this.type;
    }

    @Override
    public Class<? extends Annotation> annotationType() {
        return Persistence.class;
    }

}
