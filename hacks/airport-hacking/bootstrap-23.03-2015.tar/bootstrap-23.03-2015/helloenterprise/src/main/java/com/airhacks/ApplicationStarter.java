package com.airhacks;

import java.util.Date;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.ScheduleExpression;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
@Startup
@Singleton
public class ApplicationStarter {

    @Resource
    TimerService ts;

    private Timer timer;

    @Inject
    String message;

    @PostConstruct
    public void onStart() {
        System.out.println("Starter started! ");
        ScheduleExpression se = new ScheduleExpression();
        se.second("*/5").hour("*").minute("*");
        //this.timer = ts.createCalendarTimer(se);

    }

    @Timeout
    public void onConfigurableTimer() {
        System.out.println("Configurable timer " + new Date() + " " + message);
    }

}
