package com.airhacks;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class WorkshopStore {

    @PersistenceContext
    EntityManager em;

    public void store(String name) {
        this.em.merge(new Workshop(name));
    }

    public List<Workshop> all() {
        return em.createNamedQuery(Workshop.findAll, Workshop.class).
                getResultList();
    }

}
