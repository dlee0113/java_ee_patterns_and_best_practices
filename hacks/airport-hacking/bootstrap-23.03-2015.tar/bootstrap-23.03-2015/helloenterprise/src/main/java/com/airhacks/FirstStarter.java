package com.airhacks;

import java.util.Date;
import javax.annotation.PostConstruct;
import javax.ejb.DependsOn;
import javax.ejb.Singleton;
import javax.ejb.Startup;

/**
 *
 * @author airhacks.com
 */
@Startup
@Singleton
@DependsOn({"ApplicationStarter"})
public class FirstStarter {

    @PostConstruct
    public void init() {
        System.out.println("First one!");
    }

    // @Schedule(minute = "*", second = "*/2", hour = "*", persistent = false)
    public void callMe() {
        System.out.println("--- async " + new Date());
    }

}
