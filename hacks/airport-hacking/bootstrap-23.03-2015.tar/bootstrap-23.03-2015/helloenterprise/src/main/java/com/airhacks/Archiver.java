package com.airhacks;

/**
 *
 * @author airhacks.com
 */
public interface Archiver {

    public void archive();

}
