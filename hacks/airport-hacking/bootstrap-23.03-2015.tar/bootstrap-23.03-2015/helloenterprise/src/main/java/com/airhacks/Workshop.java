package com.airhacks;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author airhacks.com
 */
@Entity
@XmlRootElement
@Table(name = "AA_WORKSHOP")
@XmlAccessorType(XmlAccessType.FIELD)
@NamedQuery(name = Workshop.findAll, query = "SELECT w FROM Workshop w")
public class Workshop {

    @XmlTransient
    @Id
    @GeneratedValue
    private long id;

    public static final String findAll = "com.airhacks.Workshop.all";

    @Size(min = 2)
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Workshop(String name) {
        this.name = name;
    }

    public Workshop() {
    }

}
