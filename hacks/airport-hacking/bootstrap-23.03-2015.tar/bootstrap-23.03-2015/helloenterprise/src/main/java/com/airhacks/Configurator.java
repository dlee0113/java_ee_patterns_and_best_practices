package com.airhacks;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author airhacks.com
 */
public class Configurator {

    @Produces
    public String configure(InjectionPoint ip) {
        Class<?> targetClass = ip.getMember().getDeclaringClass();
        String fieldName = ip.getMember().getName();
        return targetClass.getName() + "." + fieldName + " resolved in DB";
    }

}
