package com.airhacks;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author airhacks.com
 */
public class Spy {

    @AroundInvoke
    public Object listens(InvocationContext ic) throws Exception {
        System.out.println("m = " + ic.getMethod());
        return ic.proceed();
    }

}
