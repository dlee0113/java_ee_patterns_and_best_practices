package com.airhacks;

import java.net.URI;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.constraints.Size;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

/**
 *
 * @author airhacks.com
 */
@Stateless
@Path("workshops")
public class WorkshopsResource {

    @Inject
    WorkshopsRegistration registration;

    @Inject
    WorkshopStore store;

    @GET
    public List<Workshop> all(@Context UriInfo info) {
        return this.store.all();
    }

    @GET
    @Path("{id}")
    public Response all(@PathParam("id") long id) {
        Workshop workshop = new Workshop("from DB" + id);
        return Response.ok(workshop).header("x-additional-info", "created at midnight").build();
    }

    @POST
    public Response save(@Context UriInfo info, @Size(min = 3) String message) {
        System.out.println("------post message = " + message);
        store.store(message);
        URI uri = info.getAbsolutePathBuilder().
                path("/" + System.currentTimeMillis()).
                build();
        return Response.created(uri).build();
    }

}
