package com.airhacks;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author airhacks.com
 */
@Named
@RequestScoped
public class Index {

    private Workshop workshop;

    @Inject
    WorkshopStore store;

    @PostConstruct
    public void init() {
        this.workshop = new Workshop();
    }

    public Workshop getWorkshop() {
        return workshop;
    }

    public void setWorkshop(Workshop workshop) {
        this.workshop = workshop;
    }

    public Object save() {
        this.store.store(workshop.getName());
        return null;
    }

}
