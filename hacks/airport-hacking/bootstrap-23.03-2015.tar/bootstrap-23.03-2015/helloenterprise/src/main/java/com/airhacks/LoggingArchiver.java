package com.airhacks;

import javax.decorator.Decorator;
import javax.decorator.Delegate;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
@Decorator
public abstract class LoggingArchiver implements Archiver {

    @Inject
    @Delegate
    Archiver archiver;

    @Override
    public void archive() {
        this.archiver.archive();
    }

}
