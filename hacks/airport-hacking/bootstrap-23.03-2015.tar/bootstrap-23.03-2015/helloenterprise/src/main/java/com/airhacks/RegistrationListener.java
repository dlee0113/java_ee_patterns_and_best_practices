package com.airhacks;

import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;
import javax.interceptor.Interceptors;

/**
 *
 * @author airhacks.com
 */
@Interceptors({Spy.class})
public class RegistrationListener {

    public void onNewRequest(@Observes(during = TransactionPhase.AFTER_SUCCESS) String message) {
        System.out.println("+++message = " + message);
    }

    public void onFailure(@Observes(during = TransactionPhase.AFTER_FAILURE) String badMessage) {
        System.out.println("badMessage = " + badMessage);
    }

}
