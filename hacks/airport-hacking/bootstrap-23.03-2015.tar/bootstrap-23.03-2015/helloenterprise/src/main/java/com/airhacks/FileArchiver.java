package com.airhacks;

/**
 *
 * @author airhacks.com
 */
@Persistence(Persistence.Type.PERSISTENT)
public class FileArchiver implements Archiver {

    @Override
    public void archive() {
        System.out.println("Archiving to file");
    }

}
