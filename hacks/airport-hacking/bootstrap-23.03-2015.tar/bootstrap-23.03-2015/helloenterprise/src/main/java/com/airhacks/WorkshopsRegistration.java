package com.airhacks;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Asynchronous;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Any;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.Interceptors;

/**
 *
 * @author airhacks.com
 */
@Stateless
@Interceptors({Spy.class})
public class WorkshopsRegistration {

    @Inject
    Event<String> listeners;

    @Resource
    SessionContext sc;

    @Inject
    @Persistence(Persistence.Type.PERSISTENT)
    Archiver archive;

    @Inject
    @Any
    Instance<Archiver> all;

    @PostConstruct
    public void init() {
        System.out.println("Creating a workshop registration");
        //dynamic injection
        // this.all.select(new PersistenceInstance(Persistence.Type.valueOf("TRANSIENT"))).get();
    }

    public String all() {
        final String message = "airhacks " + System.currentTimeMillis();
        listeners.fire(message);
        archive.archive();
        sc.setRollbackOnly();
        return message;
    }

    @Asynchronous
    public void auditRegistration(String registration) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(WorkshopsRegistration.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("registration = " + registration);
    }

}
