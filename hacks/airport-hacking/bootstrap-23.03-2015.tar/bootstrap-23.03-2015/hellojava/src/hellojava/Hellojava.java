package hellojava;

import java.lang.reflect.Field;

public class Hellojava {

    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class clazz = Class.forName("hellojava.Airplanef");
        Object instance = clazz.newInstance();
        Field[] declaredFields = clazz.getDeclaredFields();
        for (Field field : declaredFields) {
            if (field.isAnnotationPresent(Airport.class)) {
                System.out.println("field is annotated = " + field);
                field.setAccessible(true);
                field.set(instance, "LH42");
                System.out.println("Airport: " + instance);
            } else {
                System.out.println("field is not annotated= " + field);
            }
        }
    }

}
