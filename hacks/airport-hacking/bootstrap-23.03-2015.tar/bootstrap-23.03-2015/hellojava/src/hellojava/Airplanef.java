package hellojava;

@Airport
public class Airplanef {

    @Airport
    private String flight;

    String something;

    @Override
    public String toString() {
        return "Airplanef{" + "flight=" + flight + ", something=" + something + '}';
    }

}
