package com.airhacks;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Before;
import org.junit.Ignore;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

@Ignore
public class WorkshopRegistrationServiceTest {

    WorkshopRegistrationService cut;
    
    @Before
    public void inject(){
        this.cut = new WorkshopRegistrationService();
//        this.cut.attendeeValidator = mock(AttendeeValidator.class);
    }
    
    @Test
    public void attendeeAccepted() {
        final String name = "hugo";
  //      when(this.cut.attendeeValidator.isAcccepted(name)).thenReturn(true);
        this.cut.register(name);
    }
    
    @Test(expected = IllegalArgumentException.class)
    public void attendeeDiscarded(){
        this.cut.register("duke");
    }
}
