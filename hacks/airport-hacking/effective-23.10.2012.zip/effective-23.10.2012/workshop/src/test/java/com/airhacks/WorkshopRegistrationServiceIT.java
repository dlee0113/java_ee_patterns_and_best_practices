package com.airhacks;

import javax.ejb.EJBException;
import javax.inject.Inject;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ArchivePaths;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

@RunWith(Arquillian.class)
public class WorkshopRegistrationServiceIT {

    @Inject
    WorkshopRegistrationService cut;
    
    @Inject
    PluginHelper helper;
    
    @Deployment
    public static JavaArchive deployment(){
        return ShrinkWrap.create(JavaArchive.class).
                addClasses(WorkshopRegistrationService.class,AttendeeValidator.class,BrokenValidator.class,PluginHelper.class).
                addAsManifestResource(EmptyAsset.INSTANCE,
                        ArchivePaths.create("beans.xml"));
    }
    
    
    @Test(expected = EJBException.class)
    public void registrationWithoutValidation(){
        cut.register("duke");
    }
    
    @Test
    public void pluginIsProperlyDeployed(){
     assertTrue(helper.isPluginDeployed());
     assertTrue(helper.isPluginUnique());
    }
}
