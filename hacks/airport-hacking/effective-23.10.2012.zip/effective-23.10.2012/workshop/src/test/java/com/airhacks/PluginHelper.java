package com.airhacks;

import javax.enterprise.inject.Instance;
import javax.inject.Inject;

/**
 *
 * @author abien
 */
public class PluginHelper {
    
    @Inject
    Instance<AttendeeValidator> validators;
    
    
    public boolean isPluginDeployed(){
        return !validators.isUnsatisfied();
    }

    public boolean isPluginUnique(){
        return !validators.isAmbiguous();
    }
    
}
