package com.airhacks;

import java.io.IOException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Schedule;
import javax.ejb.ScheduleExpression;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.enterprise.event.Event;
import javax.enterprise.event.Observes;
import javax.inject.Inject;
import javax.servlet.AsyncContext;


@Startup
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class RegistrationController {
    @Resource
    TimerService service;
    private Timer timer;

    @Inject
    private String seconds;
    private String name;
    private AsyncContext ac;
    
    @Inject
    Event<String> listeners;
    
    @PostConstruct
    public void onInit(){
        ScheduleExpression se = new ScheduleExpression();
        se.minute("*").second(seconds).hour("*");
        this.timer = service.createCalendarTimer(se);
    }
    
    
    @Timeout
    public void notifyAboutArrival(){
        this.name = "---- " + new Date();
        System.out.println(name);
        this.listeners.fire(name);
        
      try {
          if(ac != null){
            ac.getResponse().getWriter().print(this.name);
            ac.complete();
            //AsyncContext is not reusable!!!
          }
        } catch (IOException ex) {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    
    public void onNewBrowser(@Observes AsyncContext ac){
            this.ac = ac;
    }
}
