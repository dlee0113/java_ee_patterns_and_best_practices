/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks;

import javax.enterprise.inject.Produces;

/**
 *
 * @author abien
 */
public class OrganizationProvider {
    
    @Produces
    public Organization organization(){
        return Organization.AUSTRIAN;
    }
}
