package com.airhacks;

import java.security.Principal;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.Interceptors;

@Stateless
@Interceptors(SecurityGate.class)
public class WorkshopRegistrationService {
   
    @Inject
    Instance<AttendeeValidator>  attendeeValidator;
    
    @Inject @LoggedIn
    AirPrincipal principal;
    
    @Inject
    Logger logger;
   
    public void register(String name){
        for (AttendeeValidator validator : attendeeValidator) {
            if(!validator.isAcccepted(name)){
                throw new IllegalStateException("Not accepted by " + validator);
            }
        }
        //register
    }
    
    @Allowed(Organization.AUSTRIAN)
    public String isPermitted(){
        logger.info("Should work");
         return principal.toString();
    }
    
}
