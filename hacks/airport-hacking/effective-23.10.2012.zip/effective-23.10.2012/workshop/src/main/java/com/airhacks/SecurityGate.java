package com.airhacks;

import java.lang.reflect.Method;
import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class SecurityGate {

    @Inject @LoggedIn
    AirPrincipal principal;

    @AroundInvoke
    public Object guard(InvocationContext ic) throws Exception {
        Method method = ic.getMethod();
        Allowed annotation = method.getAnnotation(Allowed.class);
        if (annotation != null) {
            if (annotation.value().equals(principal.getOrganization())) {
                return ic.proceed();
            } else {
                return "go away!";
            }

        }
        return ic.proceed();
    }
}
