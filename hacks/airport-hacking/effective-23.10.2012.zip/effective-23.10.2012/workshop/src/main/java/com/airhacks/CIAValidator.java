package com.airhacks;

public class CIAValidator implements AttendeeValidator{

    @Override
    public boolean isAcccepted(String name) {
        return false;
    }
    
}
