package com.airhacks;

public interface AttendeeValidator {

    
    public boolean isAcccepted(String name);
    
}
