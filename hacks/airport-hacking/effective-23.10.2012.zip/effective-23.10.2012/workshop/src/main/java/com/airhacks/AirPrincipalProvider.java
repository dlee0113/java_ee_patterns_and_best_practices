package com.airhacks;

import java.security.Principal;
import javax.enterprise.context.SessionScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;

public class AirPrincipalProvider {

    @Inject
    Principal principal;
    
    @Inject
    AirPrincipal airPrincipal;
    
    @Produces @LoggedIn
    public AirPrincipal provide(Organization o){
        String name = principal.getName();
        airPrincipal.setName(name);
        airPrincipal.setOrganization(o);
        return airPrincipal;
    }
}
