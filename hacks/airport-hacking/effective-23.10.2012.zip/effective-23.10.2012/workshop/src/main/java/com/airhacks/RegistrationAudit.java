package com.airhacks;

import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;
import javax.validation.constraints.AssertFalse;

@Stateless
public class RegistrationAudit {
    

    @Asynchronous
    public void onNewRegistration(@Observes(during = TransactionPhase.AFTER_SUCCESS) String name){
        System.out.println("+++++ Received event! " + name);
    }

    public void onFailedRegistration(@Observes(during = TransactionPhase.AFTER_FAILURE) String name){
    
    }

}
