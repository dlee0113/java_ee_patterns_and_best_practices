package com.airhacks;

/**
 *
 * @author abien
 */
public class PaymentValidator implements AttendeeValidator{

    @Override
    public boolean isAcccepted(String name) {
        return true;
    }
    
}
