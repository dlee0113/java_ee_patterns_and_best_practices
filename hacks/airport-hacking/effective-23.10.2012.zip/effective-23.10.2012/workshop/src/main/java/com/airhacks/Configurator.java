/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author abien
 */
public class Configurator {
    
    
    @Produces
    public String getString(InjectionPoint ip){
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String name = ip.getMember().getName();
        System.out.println("+++++ " + clazz.getName() + "."+name);
        return "*/2";
    }
    
}
