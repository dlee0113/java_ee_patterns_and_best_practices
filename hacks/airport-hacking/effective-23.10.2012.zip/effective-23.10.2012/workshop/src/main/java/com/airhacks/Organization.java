/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks;

/**
 *
 * @author abien
 */
public enum Organization {
    
    AUSTRIAN,GERMAN
}
