package com.airhacks;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;

@SessionScoped
public class AirPrincipal implements Serializable {

    private String name;
    private Organization organization;
    private List<String> permission;

    public AirPrincipal() {
    }

    
    
    public AirPrincipal(String name, Organization organization) {
        this.name = name;
        this.organization = organization;
        this.permission = new ArrayList<>();
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    
    public String getName() {
        return name;
    }

    public Organization getOrganization() {
        return organization;
    }

    
    

    @Override
    public String toString() {
        return "AirPrincipal{" + "name=" + name + ", permission=" + permission + '}';
    }
    
    
    
}
