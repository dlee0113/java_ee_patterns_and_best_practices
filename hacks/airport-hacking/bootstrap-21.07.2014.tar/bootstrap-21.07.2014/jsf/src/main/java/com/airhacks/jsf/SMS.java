package com.airhacks.jsf;

import javax.persistence.Entity;

/**
 *
 * @author airhacks.com
 */
@Entity
public class SMS extends Message {

}
