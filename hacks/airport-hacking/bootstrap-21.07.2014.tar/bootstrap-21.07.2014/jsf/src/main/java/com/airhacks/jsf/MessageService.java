package com.airhacks.jsf;

import java.sql.Connection;
import java.util.List;
import java.util.Set;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.validation.constraints.NotNull;

/**
 *
 * @author airhacks.com
 */
@LightweightEJB
public class MessageService {

    @Inject
    Connection custom;

    @PersistenceContext
    EntityManager em;

    @Inject
    Validator validator;

    public String crazyComplicatedBusinessLogic() {
        return "hello " + System.currentTimeMillis();
    }

    public void saveMessage(@NotNull String message) {
        final Message candidate = new Message(message);
        Set<ConstraintViolation<Message>> violations = validator.validate(candidate);
        if (!violations.isEmpty()) {
            throw new IllegalArgumentException("Message not valid");
        }
        Message merged = em.merge(candidate);
        this.em.flush();
        this.em.refresh(merged);
        System.out.println(" Got message: " + message + " with connection: " + custom);
    }

    public List<Message> messages() {
        return this.em.createNamedQuery("all", Message.class).getResultList();
    }

    public List<Message> byName(String name) {
        return this.em.createNamedQuery("byName", Message.class).
                setParameter("content", name).
                getResultList();
    }

}
