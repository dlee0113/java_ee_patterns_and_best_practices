package com.airhacks.jsf;

import javax.persistence.Entity;

/**
 *
 * @author airhacks.com
 */
@Entity
public class MMS extends Message {

}
