package com.airhacks.jsf;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.validation.constraints.Size;

/**
 *
 * @author airhacks.com
 */
@Table(name = "air_message")
@Entity
@NamedQueries({
    @NamedQuery(name = "all", query = "SELECT m FROM Message m"),
    @NamedQuery(name = "byName", query = "SELECT m FROM Message m where m.content like :content"),})

public class Message {

    @Id
    @GeneratedValue
    private long id;

    @Size(min = 3, max = 10)
    private String content;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<Part> parts;

    @Version
    private long somefield;

    public Message(String content) {
        this.content = content;
    }

    public Message() {
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}
