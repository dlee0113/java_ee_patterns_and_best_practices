package com.airhacks.jsf;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;

/**
 *
 * @author airhacks.com
 */
@Startup
@Singleton
//o@DependsOn("anotherSingleton")
public class Initializer {

    @PersistenceUnit
    EntityManagerFactory emf;

    @PostConstruct
    public void initDDL() {
        //this.emf.addNamedQuery(null, null);
        //this method is executed on start
        //Persistence.generateSchema("prod", null);
    }

}
