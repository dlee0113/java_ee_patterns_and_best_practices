package com.airhacks.jsf;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 *
 * @author airhacks.com
 */
@Entity
public class Part {

    @Id
    @GeneratedValue
    private long id;

    private String content;

    public Part(String content) {
        this.content = content;
    }

    public Part() {
    }

}
