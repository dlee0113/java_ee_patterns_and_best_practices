package com.airhacks.jsf;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
@Model
public class Index {

    @Inject
    MessageService ms;

    private Message message;

    @PostConstruct
    public void onCreate() {
        this.message = new Message();
    }

    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }

    public Object save() {
        this.ms.saveMessage(this.message.getContent());
        return "theend";
    }

}
