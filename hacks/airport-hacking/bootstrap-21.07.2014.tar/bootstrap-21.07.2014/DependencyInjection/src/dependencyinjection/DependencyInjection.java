package dependencyinjection;

/**
 *
 * @author airhacks.com
 */
public class DependencyInjection {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        UI ui = new UI();
        System.out.println("UI: " + ui);
    }

}
