package dependencyinjection;

/**
 *
 * @author airhacks.com
 */
public interface DB {

}
