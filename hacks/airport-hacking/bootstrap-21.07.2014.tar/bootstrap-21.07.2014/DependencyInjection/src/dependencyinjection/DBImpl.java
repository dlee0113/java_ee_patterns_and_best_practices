package dependencyinjection;

/**
 *
 * @author airhacks.com
 */
public class DBImpl implements DB {

}
