package dependencyinjection;

/**
 *
 * @author airhacks.com
 */
public class ObjectFactory {

    public static Object create() throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        return Class.forName("dependencyinjection.DBImpl").newInstance();
    }

}
