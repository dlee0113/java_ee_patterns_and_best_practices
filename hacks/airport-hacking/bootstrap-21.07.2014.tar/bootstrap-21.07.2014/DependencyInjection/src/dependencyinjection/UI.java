package dependencyinjection;

/**
 *
 * @author airhacks.com
 */
public class UI {

    DB db;

    public UI() throws Exception {
    }

    @Override
    public String toString() {
        return "UI{" + "db=" + db + '}';
    }

}
