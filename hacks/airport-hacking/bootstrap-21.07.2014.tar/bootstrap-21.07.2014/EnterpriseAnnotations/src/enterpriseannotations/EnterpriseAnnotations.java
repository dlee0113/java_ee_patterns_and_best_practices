package enterpriseannotations;

import java.lang.reflect.Field;

/**
 *
 * @author airhacks.com
 */
public class EnterpriseAnnotations {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class<?> eeComponent = Class.forName("enterpriseannotations.UI");
        Object receivingInstance = eeComponent.newInstance();
        Field[] declaredFields = eeComponent.getDeclaredFields();
        for (Field field : declaredFields) {
            System.out.println("--- " + field);
            Airhack airhack = field.getAnnotation(Airhack.class);
            if (airhack != null) {
                System.out.println("Injecting stuff here: " + field);
                Class<?> classInjected = field.getType();
                Object instanceInjected = classInjected.newInstance();
                field.setAccessible(true);
                field.set(receivingInstance, instanceInjected);
                System.out.println("--- : " + receivingInstance + " with name: " + airhack.name());
            } else {
                System.out.println("Ignoring field: " + field);
            }
        }
    }

}
