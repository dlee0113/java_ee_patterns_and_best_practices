package enterpriseannotations;

/**
 *
 * @author airhacks.com
 */
public class UI {

    @Airhack(name = "duke")
    private DB db;

    String pleaseIgnore;

    @Override
    public String toString() {
        return "UI{" + "db=" + db + ", pleaseIgnore=" + pleaseIgnore + '}';
    }

}
