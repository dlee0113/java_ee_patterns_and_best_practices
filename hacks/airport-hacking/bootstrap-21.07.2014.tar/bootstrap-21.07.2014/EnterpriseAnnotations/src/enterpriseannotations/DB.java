package enterpriseannotations;

/**
 *
 * @author airhacks.com
 */
public class DB {

}
