package com.airhacks.di;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

/**
 *
 * @author airhacks.com
 */
@Stateless
@Path("meals")
public class MealsResource {

    @Inject
    SmokeyJoe sj;

    @GET
    @Path("{id}-{name}")
    public Response meals(@PathParam("id") int id, @PathParam("name") String name) {
        return Response.status(200).
                header("meta", "data").
                header("name", name).
                entity(new Meal(sj.getMeal(), id)).build();
    }

    @GET
    public JsonArray method(@Context HttpServletResponse response) {
        //Collection<Meal> meals = new ArrayList<>();
        /* nice to have -> lambdas
         List<JsonObject> collect = meals.stream().
         map(m -> Json.createObjectBuilder().
         add("name", m.getName()).build()).collect(Collectors.toList());
         */
        return Json.createArrayBuilder().add("pizza").add("doener").build();
    }

    @POST
    public void save(JsonObject meal) {
        System.out.println(" Got meal: " + meal);
    }

}
