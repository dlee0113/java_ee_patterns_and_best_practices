package com.airhacks.di;

import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author airhacks.com
 */
public class MealListener {

    public void onCookRequest(@Observes(during = TransactionPhase.AFTER_SUCCESS) String meal) {
        System.out.println("--- got meal: " + meal);
    }
}
