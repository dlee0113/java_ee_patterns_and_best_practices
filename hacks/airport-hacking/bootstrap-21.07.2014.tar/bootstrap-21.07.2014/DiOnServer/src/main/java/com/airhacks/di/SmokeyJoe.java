package com.airhacks.di;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.interceptor.Interceptors;

/**
 *
 * @author airhacks.com
 */
@RequestScoped
@Interceptors({Auditor.class})
public class SmokeyJoe {

    @Inject
    Cook cook;

    @PostConstruct
    public void onCreation() {
        System.out.println("-- created SmokeJoe!");
    }

    public String getMeal() {
        cook.cook();
        return "flying burger";
    }
}
