package com.airhacks.di;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author airhacks.com
 */
public class Auditor {

    @AroundInvoke
    public Object audit(InvocationContext ic) throws Exception {
        System.out.println("############# " + ic.getMethod());
        long start = System.nanoTime();
        try {
            return ic.proceed();
        } catch (Exception ex) {
            System.err.println("Exception occurred: " + ex.getMessage());
            return "an exception happened";
        } finally {
            System.out.println("After " + (System.nanoTime() - start));
        }
    }

}
