package com.airhacks.di;

import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Singleton;
import javax.enterprise.event.Event;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
@Singleton
public class Cook {

    @Inject
    Event<String> mealListeners;

    //ConcurrentHashMap<String, String> cache;
    @PostConstruct
    public void onCreation() {
        System.out.println("-- created Cook!");
    }

    public void cook() {
        mealListeners.fire("Meal is ready");
        System.out.println("--- ready!");
        //throw new RuntimeException("Kitchen exploded!");
    }

    public void heat() {
        System.out.println("Heating: ");
    }
}
