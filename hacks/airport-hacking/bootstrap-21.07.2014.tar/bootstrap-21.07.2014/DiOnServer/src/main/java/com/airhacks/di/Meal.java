package com.airhacks.di;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author airhacks.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Meal {

    @XmlAttribute
    private String name;
    private int size;

    public Meal(String name, int size) {
        this.name = name;
        this.size = size;
    }

    public Meal() {
    }

    public String getName() {
        return name;
    }

}
