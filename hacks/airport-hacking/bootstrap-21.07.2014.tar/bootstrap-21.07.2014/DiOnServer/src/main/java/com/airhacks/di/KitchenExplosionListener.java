package com.airhacks.di;

import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author airhacks.com
 */
public class KitchenExplosionListener {

    public void onExplosion(@Observes(during = TransactionPhase.AFTER_FAILURE) String meal) {
        System.out.println("!!!!!!!!!!!!Exploded: " + meal);
    }

}
