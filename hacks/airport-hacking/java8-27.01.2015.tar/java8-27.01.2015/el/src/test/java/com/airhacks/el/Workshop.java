package com.airhacks.el;

/**
 *
 * @author adam-bien.com
 */
public class Workshop {

    private String title;

    public Workshop(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

}
