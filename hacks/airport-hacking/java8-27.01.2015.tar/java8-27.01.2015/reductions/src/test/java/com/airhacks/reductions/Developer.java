package com.airhacks.reductions;

/**
 *
 * @author airhacks.com
 */
public class Developer {

    private String language;
    private int age;

    public Developer(String language, int age) {
        this.language = language;
        this.age = age;
    }

    public String getLanguage() {
        return language;
    }

    public int getAge() {
        return age;
    }

}
