package com.airhacks;

/**
 *
 * @author airhacks.com
 */
public enum Stage {

    DEVELOPMENT, INTEGRATION, PRODUCTION;
}
