package com.airhacks;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author airhacks.com
 */
@ApplicationPath("resources")
public class JAXRSConfigurator extends Application {

}
