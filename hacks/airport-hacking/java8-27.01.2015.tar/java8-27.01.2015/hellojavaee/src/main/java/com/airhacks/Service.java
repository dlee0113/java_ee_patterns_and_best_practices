package com.airhacks;

/**
 *
 * @author airhacks.com
 */
public interface Service {

    void serveMe();

    boolean isActive();
}
