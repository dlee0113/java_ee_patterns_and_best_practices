package com.airhacks;

/**
 *
 * @author airhacks.com
 */
public class MessageProducer {

    public static String getMessage() {
        return " fast : " + System.currentTimeMillis();
    }

}
