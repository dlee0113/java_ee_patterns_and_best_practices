#!/usr/bin/jjs -fv

var host = "localhost";
$EXEC('curl http://${host}:8080/hellojavaee/resources/developers');
var result = $OUT;
print(result);



var developers = JSON.parse(result);
print(developers);
for each(dev in developers){
	print(dev.age);
}