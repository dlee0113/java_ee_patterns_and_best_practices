/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mydependencyinjection;

import java.lang.reflect.Field;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class ApplicationServer {

    public static void main(String[] args) throws Exception {
        Class<?> component = Class.forName("mydependencyinjection.RegistrationService");
        Field[] declaredFields = component.getDeclaredFields();
        for (Field field : declaredFields) {
            final InjectMe annotation = field.getAnnotation(InjectMe.class);
            
            if(annotation != null){
                System.out.println("Found: " + field + " Value: " + annotation.value());
            }
        }
    }
}
