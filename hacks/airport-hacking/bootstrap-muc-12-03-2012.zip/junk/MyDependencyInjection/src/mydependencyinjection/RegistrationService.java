/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mydependencyinjection;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class RegistrationService {
    
    @InjectMe("at midnight")
    Payment payment;
}
