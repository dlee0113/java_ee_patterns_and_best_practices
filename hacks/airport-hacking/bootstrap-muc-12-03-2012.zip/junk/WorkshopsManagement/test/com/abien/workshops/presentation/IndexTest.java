/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.workshops.presentation;

import com.abien.workshops.business.registrations.boundary.RegistrationService;
import org.junit.AfterClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import static org.mockito.Mockito.*;

/**
 * Look at arquillian (jboss) for Unit tests
 * @author adam bien, adam-bien.com
 */
public class IndexTest {
    
    private Index cut;
    @Before
    public void init(){
        this.cut = new Index();
        this.cut.rs = mock(RegistrationService.class);
    }
    

    @Test
    public void getRegistration() {
        this.cut.greetings();
        System.out.println("--- " + this.cut.rs);
    }
}
