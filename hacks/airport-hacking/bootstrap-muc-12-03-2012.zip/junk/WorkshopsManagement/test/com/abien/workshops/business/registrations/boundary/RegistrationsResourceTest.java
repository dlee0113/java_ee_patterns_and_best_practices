/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.workshops.business.registrations.boundary;

import com.abien.workshops.business.registrations.entity.Workshop;
import com.sun.jersey.api.client.Client;
import org.junit.AfterClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.BeforeClass;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class RegistrationsResourceTest {
    

    @Test
    public void getRegistrations() {
        Client client = Client.create();
        Workshop workshop = client.
   resource("http://localhost:8080/WorkshopsManagement/resources/registrations/42").get(Workshop.class);
        assertNotNull(workshop);
        System.out.println("w: " + workshop);
    }   
}
