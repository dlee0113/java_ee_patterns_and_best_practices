/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.workshops.business.registrations.boundary;

import com.abien.workshops.business.registrations.control.GreetingsVerifier;
import javax.persistence.EntityManager;
import org.junit.AfterClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import static org.mockito.Mockito.*;

/**
 * Homework: powermock
 * @author adam bien, adam-bien.com
 */
public class RegistrationServiceTest {

    private RegistrationService cut;

    @Before
    public void initDI(){
        this.cut = new RegistrationService();
        this.cut.em = mock(EntityManager.class);
        this.cut.greetingsVerifier = mock(GreetingsVerifier.class);
    }
    
    @Test
    public void getGreetings() {
        this.cut.getGreetings();
        verify(this.cut.em,times(1)).persist(anyObject());
    }

    @Test(expected=IllegalStateException.class)
    public void getGreetingsWithInvalidMessage() {
        when(this.cut.greetingsVerifier.verify()).thenThrow(new IllegalStateException());
        this.cut.getGreetings();
        verify(this.cut.em,times(1)).persist(anyObject());
    }
}
