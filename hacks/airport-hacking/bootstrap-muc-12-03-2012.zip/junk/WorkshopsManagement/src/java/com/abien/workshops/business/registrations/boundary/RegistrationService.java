package com.abien.workshops.business.registrations.boundary;

import com.abien.workshops.business.dataaccess.boundary.Cache;
import com.abien.workshops.business.registrations.control.GreetingsVerifier;
import com.abien.workshops.business.registrations.entity.Workshop;
import java.security.Principal;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.annotation.security.RolesAllowed;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Stateless
@Interceptors(AuditAspect.class)
public class RegistrationService {
    
    @Resource
    SessionContext sc;
    
    @Inject
    private String message;

    @Inject @Cache(Cache.Level.HIGH)
    EntityManager em;
    
    @Inject
    GreetingsVerifier greetingsVerifier;
    
    @Inject
    Event<Workshop> events;
    
    @PostConstruct
    public void onNewRequest(){
        System.out.println("-Creating EJB: -- " + this.getClass().getName());
    }
    
    public String getGreetings(){
        greetingsVerifier.verify();
        Principal callerPrincipal = sc.getCallerPrincipal();
        System.out.println("--- " + callerPrincipal);
        return message;
    }
    
    @Asynchronous
    public Future<String> register(Workshop workshop){ 
        em.persist(workshop);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(RegistrationService.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.events.fire(workshop);
        return new AsyncResult<String>("42");
    }
    
}
