/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.workshops.business.registrations.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class GreetingsVerifier {
        
    public boolean verify(){
        return false;
    }
}
