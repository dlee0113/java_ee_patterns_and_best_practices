package com.abien.workshops.business.dataaccess.boundary;

import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class DataAccessor {

    
    @PersistenceContext
    EntityManager em;
    
    
    @Produces @Cache(Cache.Level.HIGH)
    public EntityManager hugoWorksAsWell(){
        return this.em;
    }
    
    @Produces @Cache(Cache.Level.LOW)
    public EntityManager doesntWork(){
        return this.em;
    }
}
