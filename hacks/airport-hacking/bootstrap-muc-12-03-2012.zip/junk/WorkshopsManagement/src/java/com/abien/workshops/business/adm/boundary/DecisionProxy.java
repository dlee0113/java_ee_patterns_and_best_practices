/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.workshops.business.adm.boundary;

import java.security.Principal;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class DecisionProxy {
    
    @Inject
    Principal principal;
    
    @Produces
    public Decision decide(){
        //go via REST to backend and ask with prinicipal
        return new Decision();
    }
}
