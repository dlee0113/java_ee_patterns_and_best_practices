package com.abien.workshops.business.adm.boundary;

import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class DecisionManagementInterceptor {
    @Inject
    Instance<Decision> decision;
    
    public Object checkSecurity(InvocationContext ic) throws Exception{
        Decision get = decision.get();
        return null;
    }
}
