/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.workshops.business.adm.boundary;

import javax.enterprise.inject.Alternative;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Alternative
public class Decision {
    
}
