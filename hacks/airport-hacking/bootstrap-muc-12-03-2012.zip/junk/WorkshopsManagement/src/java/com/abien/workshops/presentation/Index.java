package com.abien.workshops.presentation;

import com.abien.workshops.business.registrations.boundary.RegistrationService;
import com.abien.workshops.business.registrations.entity.Workshop;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author adam bien, adam-bien.com
 */
@BackingBean
public class Index {
    
    @Inject
    RegistrationService rs;
    
    private Workshop workshop;

    @PostConstruct
    public void onNewRequest(){
        this.workshop = new Workshop();
        System.out.println("-Creating: -- " + this.getClass().getName());
    }

    public Workshop getWorkshop() {
        return workshop;
    }
    
    public String greetings(){
        return rs.getGreetings();
    }
    
    public Object save(){
        System.out.println("--- " + workshop);
        Future<String> register = rs.register(workshop);
        try {
            System.out.println("Result: " + register.get());
        } catch (InterruptedException ex) {
            Logger.getLogger(Index.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ExecutionException ex) {
            Logger.getLogger(Index.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
}
