package com.abien.workshops.business.payment.control;

import com.abien.workshops.business.registrations.entity.Workshop;
import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.annotation.PostConstruct;
import javax.ejb.*;
import javax.enterprise.event.Observes;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Startup
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class PaymentProcessor {
    
    private CopyOnWriteArrayList<Workshop> workshops;
    
    @PostConstruct
    public void onStart(){
        System.out.println("Starting payent");
        this.workshops = new CopyOnWriteArrayList<Workshop>();
    }

    public void newWorkshop(@Observes Workshop workshop){
        this.workshops.add(workshop);
    }
    
    @Schedule(minute="*",second="*/2",hour="*")
    public void charge(){
        System.out.println(" " + workshops);
        workshops.clear();
    }
}
