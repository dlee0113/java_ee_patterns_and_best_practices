/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.abien.workshops.business.payment.boundary;

import com.abien.workshops.business.registrations.entity.Workshop;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class RegistrationListener {
    
    
    public void onNewRegistration(@Observes(during= TransactionPhase.AFTER_SUCCESS) Workshop workshop){
        System.out.println("Charging for workshop: " + workshop);
    }
    
}
