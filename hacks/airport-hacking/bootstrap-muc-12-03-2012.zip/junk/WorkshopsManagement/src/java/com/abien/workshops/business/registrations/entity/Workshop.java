package com.abien.workshops.business.registrations.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author adam bien, adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="ws")
@Table(name="HACK_WORKSHOP")
@Entity
public class Workshop {
    
    @Id
    @GeneratedValue
    @XmlTransient
    private long registrationNbr;
    
    @XmlAttribute
    @Size(min=2,max=5)
    private String firstName;

    public Workshop(String firstName) {
        this.firstName = firstName;
    }

    public Workshop() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    
    @Override
    public String toString() {
        return "Workshop{" + "registrationNbr=" + registrationNbr + ", firstName=" + firstName + '}';
    }
    
    
    
}
