package com.abien.workshops.business.registrations.boundary;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class AuditAspect {

    @AroundInvoke
    public Object logMethodCall(InvocationContext ic) throws Exception{
        System.out.println("--- " + ic.getMethod());
        try{
            return ic.proceed();
        }finally{
            System.out.println("---After the invocation");
        }
    }
}
