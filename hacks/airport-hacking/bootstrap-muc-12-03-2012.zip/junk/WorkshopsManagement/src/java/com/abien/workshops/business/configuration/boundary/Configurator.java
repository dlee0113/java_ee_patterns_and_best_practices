package com.abien.workshops.business.configuration.boundary;

import java.lang.reflect.Member;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class Configurator {


    @Produces
    public String getString(InjectionPoint ip){
        Member member = ip.getMember();
        return "duke " + member.getDeclaringClass().getName() + "."+member.getName();
    }
    
}
