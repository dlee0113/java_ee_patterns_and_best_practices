package com.abien.workshops.business.registrations.boundary;

import com.abien.workshops.business.registrations.entity.Workshop;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Stateless
@Path("registrations")
public class RegistrationsResource {
    
    @Inject
    Validator validator;
    
    @GET
    @Produces({MediaType.APPLICATION_XML})
    public List<Workshop> hello(){
        List<Workshop> workshops = new ArrayList<Workshop>();
        workshops.add(new Workshop("duke"));
        return workshops;
    }
    
    @GET
    @Path("{id}")
    public Workshop workshop(@PathParam("id") long id,@Context HttpHeaders headers){
        return new Workshop("with id: " + id + headers.getRequestHeaders());
    }
    
    //@Path("attendees")
    /*
    public AttendeesResource attendees(){
        //
        return null; //important: sub-resource locator
    }
    * 
    */
    
    @POST
    @Consumes(MediaType.APPLICATION_XML)
    public Response create(Workshop workshop){
        Set<ConstraintViolation<Workshop>> validate = this.validator.validate(workshop,new Class[]{} );
        Response response;
        if(!validate.isEmpty()){
        response =  Response.status(Response.Status.BAD_REQUEST).header("X-Error", "Wrong workshop").build();
        }
        System.out.println("Workshop: " + workshop);
        URI uri = URI.create(""+workshop.getFirstName());//should be an ID
        return Response.created(uri).build();
    }
}
