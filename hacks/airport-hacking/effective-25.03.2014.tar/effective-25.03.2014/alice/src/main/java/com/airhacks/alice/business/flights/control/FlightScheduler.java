package com.airhacks.alice.business.flights.control;

import com.airhacks.alice.business.flights.entity.Flight;

/**
 *
 * @author airhacks.com
 */
public class FlightScheduler {

    public void schedule(Flight flight) {
        System.out.println("Scheduled: " + flight);
    }

}
