package com.airhacks.alice.business.authorization.boundary;

import com.airhacks.alice.business.authorization.entity.Airhacker;
import java.security.Principal;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
public class PrincipalProvider {

    @Inject
    Principal principal;

    @Produces
    public Airhacker expose() {
        String name = principal.getName();
        //access the DB
        return new Airhacker(principal);

    }
}
