package com.airhacks.alice.business.authorization.entity;

import java.security.Principal;
import javax.enterprise.inject.Vetoed;

/**
 *
 * @author airhacks.com
 */
@Vetoed
public class Airhacker {

    private Principal principal;

    public Airhacker(Principal principal) {
        this.principal = principal;
    }

    @Override
    public String toString() {
        return "Airhacker{ and permissions from my db" + "principal=" + principal + '}';
    }

}
