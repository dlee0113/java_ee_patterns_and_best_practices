package com.airhacks.alice.business.flights.boundary;

import com.airhacks.alice.business.flights.entity.Flight;
import javax.ws.rs.container.AsyncResponse;

/**
 *
 * @author airhacks.com
 */
public class FlightRequest {

    private AsyncResponse ar;

    public FlightRequest(AsyncResponse ar) {
        this.ar = ar;
    }

    public void result(Flight flight) {
        ar.resume(flight);
    }

}
