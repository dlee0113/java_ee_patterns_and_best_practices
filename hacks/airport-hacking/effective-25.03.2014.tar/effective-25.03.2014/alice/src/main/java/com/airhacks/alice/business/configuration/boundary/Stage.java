package com.airhacks.alice.business.configuration.boundary;

/**
 *
 * @author airhacks.com
 */
enum Stage {

    DEVELOPMENT, INTEGRATION, PRODUCTION;
}
