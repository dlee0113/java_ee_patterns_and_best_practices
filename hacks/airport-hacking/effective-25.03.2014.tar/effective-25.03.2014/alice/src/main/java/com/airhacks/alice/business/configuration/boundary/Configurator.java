package com.airhacks.alice.business.configuration.boundary;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author airhacks.com
 */
public class Configurator {

    @Produces
    @Configurable
    public String configure(InjectionPoint ip, Stage stage) {
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String name = ip.getMember().getName();
        String fqn = clazz.getName();
        return stage + " " + fqn + "." + name;
    }

}
