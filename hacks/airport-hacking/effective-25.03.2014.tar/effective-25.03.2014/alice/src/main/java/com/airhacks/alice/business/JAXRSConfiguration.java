package com.airhacks.alice.business;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author airhacks.com
 */
@ApplicationPath("v1")
public class JAXRSConfiguration extends Application {

}
