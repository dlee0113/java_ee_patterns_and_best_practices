package com.airhacks.alice.business.flights.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author airhacks.com
 */
@Entity
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Flight {

    @Id
    private String number;
    private int capacity;

    @XmlTransient
    private String secret;

    public Flight(String number, int capacity) {
        this.number = number;
        this.capacity = capacity;
    }

    public Flight() {
    }

}
