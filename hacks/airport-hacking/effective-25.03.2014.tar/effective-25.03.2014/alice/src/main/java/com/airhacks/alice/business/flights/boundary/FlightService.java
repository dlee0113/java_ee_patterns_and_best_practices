package com.airhacks.alice.business.flights.boundary;

import com.airhacks.alice.business.authorization.entity.Airhacker;
import com.airhacks.alice.business.configuration.boundary.Configurable;
import com.airhacks.alice.business.flights.control.FlightScheduler;
import com.airhacks.alice.business.flights.control.FlightValidator;
import com.airhacks.alice.business.flights.entity.Flight;
import java.security.Principal;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.enterprise.event.Observes;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
@Stateless
public class FlightService {

    @Inject
    private FlightValidator fv;

    @Inject
    private FlightScheduler fs;

    @Inject
    @Configurable
    private String flightMessage;

    @Inject
    private Airhacker principal;

    /**
     *
     * Usually you would gather the requests here - not process them.
     *
     */
    public void recent(@Observes FlightRequest nbr) {
        System.out.println("Here is the message: " + flightMessage + " accessed by: " + this.principal);
        nbr.result(new Flight(flightMessage, 21));
    }

    public void schedule(Flight flight) {
        if (!this.fv.isValid(flight)) {
            throw new IllegalArgumentException("Not valid!");
        }
        this.fs.schedule(flight);
    }

}
