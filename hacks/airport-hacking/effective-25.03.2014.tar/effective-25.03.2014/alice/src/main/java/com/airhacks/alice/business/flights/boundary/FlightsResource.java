package com.airhacks.alice.business.flights.boundary;

import java.net.URI;
import java.util.concurrent.TimeUnit;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;
import javax.ws.rs.container.TimeoutHandler;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

/**
 *
 * @author airhacks.com
 */
@Stateless
@Path("flights")
public class FlightsResource {

    @Inject
    FlightService fs;

    @Inject
    Event<FlightRequest> flightRequestListeners;

    @GET
    @Produces({"crazy/fast", MediaType.APPLICATION_XML})
    public void flights(@Suspended AsyncResponse response) {
        response.setTimeout(10, TimeUnit.SECONDS);
        response.setTimeoutHandler(new TimeoutHandler() {

            public void handleTimeout(AsyncResponse asyncResponse) {
                Response resp = Response.status(204).build();
                asyncResponse.resume(resp);
            }
        });
        flightRequestListeners.fire(new FlightRequest(response));
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public JsonArray flights() {
        JsonObject flight = Json.createObjectBuilder().add("nbr", 42).build();
        return Json.createArrayBuilder().add(flight).build();
    }

    @GET
    @Path("{id}-{name}")
    @Produces({MediaType.APPLICATION_JSON})
    public JsonObject whoCaresAboutNames(@PathParam("id") long id, @PathParam("name") String name) {
        return Json.createObjectBuilder().
                add("flight", "kamikaze").add("id", id).add("name", name).build();
    }

    @POST
    public Response create(JsonObject flight, @Context UriInfo info) {
        System.out.println("Flight created: " + flight);
        URI uri = info.getAbsolutePathBuilder().path("/" + System.currentTimeMillis()).build();
        return Response.created(uri).build();
    }

    @DELETE
    @Path("{id}")
    public void delete(@PathParam("id") long id) {
        System.out.println("Id: " + id);
    }

}
