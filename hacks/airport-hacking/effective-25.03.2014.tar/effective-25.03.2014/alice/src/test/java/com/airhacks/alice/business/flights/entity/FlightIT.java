package com.airhacks.alice.business.flights.entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author airhacks.com
 */
public class FlightIT {

    private EntityManager em;
    private EntityTransaction tx;

    @Before
    public void initEM() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("it");
        this.em = emf.createEntityManager();
        this.tx = this.em.getTransaction();
    }

    @Test
    public void crud() {
        this.tx.begin();
        this.em.merge(new Flight("java", 42));
        this.tx.commit();
    }

}
