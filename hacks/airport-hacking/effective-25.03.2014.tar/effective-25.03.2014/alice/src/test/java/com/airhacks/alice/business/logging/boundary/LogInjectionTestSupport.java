package com.airhacks.alice.business.logging.boundary;

import java.util.logging.Logger;
import javax.inject.Inject;

/**
 *
 * @author airhacks.com
 */
public class LogInjectionTestSupport {

    @Inject
    Logger logger;

    public Logger getLogger() {
        return logger;
    }

}
