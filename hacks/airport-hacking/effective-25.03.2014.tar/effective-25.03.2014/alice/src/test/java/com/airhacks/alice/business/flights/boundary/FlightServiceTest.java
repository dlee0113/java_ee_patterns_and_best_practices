package com.airhacks.alice.business.flights.boundary;

import com.airhacks.alice.business.flights.control.FlightScheduler;
import com.airhacks.alice.business.flights.control.FlightValidator;
import com.airhacks.alice.business.flights.entity.Flight;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.mockito.runners.MockitoJUnitRunner;

/**
 *
 * @author airhacks.com
 */
@RunWith(MockitoJUnitRunner.class)
public class FlightServiceTest {

    @InjectMocks
    FlightService cut;
    @Mock
    FlightScheduler fs;
    @Mock
    FlightValidator fv;

    @Test(expected = IllegalArgumentException.class)
    public void failedFlight() {
        final Flight flight = new Flight();
        when(this.fv.isValid(flight)).thenReturn(false);
        this.cut.schedule(flight);
    }

    @Test
    public void successfulSchedule() {
        final Flight flight = new Flight();
        when(this.fv.isValid(flight)).thenReturn(true);
        this.cut.schedule(flight);
        verify(this.fs, times(1)).schedule(flight);

    }

}
