package com.airhacks.alice.business.logging.boundary;

import java.util.logging.Logger;
import javax.inject.Inject;
import static org.hamcrest.CoreMatchers.is;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.container.test.api.OperateOnDeployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 *
 * @author airhacks.com
 */
@RunWith(Arquillian.class)
public class LoggingManagerIT {

    @Inject
    LogInjectionTestSupport cut;

    @Deployment(name = "plain")
    public static WebArchive create() {
        return ShrinkWrap.create(WebArchive.class).
                addClasses(LogInjectionTestSupport.class, LoggingManager.class).
                addAsWebInfResource(EmptyAsset.INSTANCE, "beans.xml");
    }

    @OperateOnDeployment("plain")
    @Test
    public void loggerProperlyConfigured() {
        String expected = cut.getClass().getName();
        Logger logger = this.cut.getLogger();
        String actual = logger.getName();
        assertThat(actual, is(expected));
    }

}
