dozer (dto mapping tool)
.net-iiop

Perform integration test: mvn failsafe:integration-test
API documentation: http://enunciate.codehaus.org

Homework: Graphene / Drone / Selenium (look at Vaadin Java EE 6 integration at github.com)