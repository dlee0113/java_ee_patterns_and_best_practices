package com.airhacks.airfeed.business.monitoring.boundary;

import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Singleton;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;

/**
 *
 * @author adam-bien.com
 */
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class Monitor {

    public void onNewMonitoringEvent(@Observes(during = TransactionPhase.AFTER_SUCCESS) @Emergency(Emergency.Level.CRITICAL) String message) {
        System.out.println("Observing: " + message);
    }
}
