package com.airhacks.airfeed.presentation;

import com.airhacks.airfeed.business.feedback.boundary.FeedbackStore;
import com.airhacks.airfeed.business.feedback.entity.Feedback;
import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

@Model
public class Index {
    
    private Feedback feedback;
    @Inject
    FeedbackStore fs;
    
    @PostConstruct
    public void init() {
        this.feedback = new Feedback();
    }
    
    public Feedback getFeedback() {
        return feedback;
    }
    
    public Object save() {
        this.fs.store(feedback);
        return null;
    }
}
