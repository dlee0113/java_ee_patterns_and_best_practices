package com.airhacks.airfeed.business.feedback.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author adam-bien.com
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
@NamedQuery(name = Feedback.findAll, query = "SELECT f FROM Feedback f")
@Table(name = "T_FEEDBACK")
@Entity
public class Feedback {

    private static final String PREFIX = "com.airhacks.airfeed.business.feedback.entity.Feedback.";
    public static final String findAll = PREFIX + "findAll";
    @Id
    @GeneratedValue
    private long id;
    @Column(name = "C_NAME")
    private String name;
    @Size(min = 3, max = 256)
    private String comment;

    public Feedback() {
    }

    public Feedback(String name, String comment) {
        this.name = name;
        this.comment = comment;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    @Override
    public String toString() {
        return "Feedback{" + "name=" + name + ", comment=" + comment + '}';
    }
}
