package com.airhacks.airfeed.business.feedback.control;

/**
 *
 * @author adam-bien.com
 */
public class SpamFilter {

    public boolean isSpam(String comment) {
        return comment.contains("http://");
    }
}
