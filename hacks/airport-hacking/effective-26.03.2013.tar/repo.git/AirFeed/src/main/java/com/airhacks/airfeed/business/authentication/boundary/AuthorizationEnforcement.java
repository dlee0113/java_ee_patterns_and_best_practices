package com.airhacks.airfeed.business.authentication.boundary;

import com.airhacks.airfeed.business.authentication.entity.AirhacksPrincipal;
import java.lang.reflect.Method;
import java.util.logging.Logger;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam-bien.com
 */
public class AuthorizationEnforcement {
    
    @Inject
    Instance<AirhacksPrincipal> airhacksPrincipal;
    @Inject
    Logger logger;
    
    @AroundInvoke
    public Object checkSecurity(InvocationContext ic) throws Exception {
        Method method = ic.getMethod();
        logger.info("Checking method: " + method.getName());
        PermittedFor annotation = method.getAnnotation(PermittedFor.class);
        if (annotation != null) {
            System.out.println("Checking: " + method + " and principal " + airhacksPrincipal.get());
            //throw new SecurityException
        }
        
        return ic.proceed();
        
    }
}
