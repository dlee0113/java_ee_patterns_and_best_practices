package com.airhacks.airfeed.business.feedback.boundary;

import com.airhacks.airfeed.business.feedback.entity.Feedback;
import java.net.URI;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 *
 * @author adam-bien.com
 */
@Stateless
@Path("feedbacks")
@Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
@Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
public class FeedbacksResource {

    @Inject
    FeedbackStore store;

    @GET
    public List<Feedback> all() {
        return store.all();
    }

    @GET
    @Path("{id}")
    public Feedback find(@PathParam("id") long id) {
        return store.find(id);
    }

    @POST
    public Response save(Feedback feedback) {
        store.store(feedback);
        long id = feedback.getId();
        URI uri = URI.create(String.valueOf(id));
        return Response.created(uri).build();
    }
}
