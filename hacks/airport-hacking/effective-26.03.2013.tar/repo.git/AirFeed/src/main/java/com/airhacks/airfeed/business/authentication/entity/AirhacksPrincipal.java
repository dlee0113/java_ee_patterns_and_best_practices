/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks.airfeed.business.authentication.entity;

import com.airhacks.airfeed.business.feedback.entity.Feedback;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author adam-bien.com
 */
public class AirhacksPrincipal {
    
    private String name;
    private List<String> permissions;
    
    public AirhacksPrincipal(String name) {
        this.permissions = new ArrayList<>();
        this.name = name;
    }
    
    public void add(String permission) {
        this.permissions.add(permission);
    }
    
    @Override
    public String toString() {
        return "AirhacksPrincipal{" + "name=" + name + ", permissions=" + permissions + '}';
    }
}
