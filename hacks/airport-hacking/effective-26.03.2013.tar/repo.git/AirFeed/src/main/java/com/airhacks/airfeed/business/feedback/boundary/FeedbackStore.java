package com.airhacks.airfeed.business.feedback.boundary;

import com.airhacks.airfeed.business.authentication.boundary.AuthorizationEnforcement;
import com.airhacks.airfeed.business.authentication.boundary.PermittedFor;
import com.airhacks.airfeed.business.authentication.entity.AirhacksPrincipal;
import com.airhacks.airfeed.business.feedback.control.SpamFilter;
import com.airhacks.airfeed.business.feedback.entity.Feedback;
import com.airhacks.airfeed.business.monitoring.boundary.Emergency;
import java.security.Principal;
import java.util.List;
import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
@Interceptors(AuthorizationEnforcement.class)
public class FeedbackStore {

    @PersistenceContext
    private EntityManager em;
    @Inject
    private SpamFilter filter;
    @Inject
    private AirhacksPrincipal principal;
    @Inject
    @Emergency(Emergency.Level.CRITICAL)
    private Event<String> monitoringSink;

    @PermittedFor("attendee")
    public void store(Feedback feedback) {
        System.out.println("Principal:  " + principal);
        boolean spam = filter.isSpam(feedback.getComment());
        if (spam) {
            throw new IllegalArgumentException("Please don't spam me");
        }
        this.em.persist(feedback);
        this.em.flush();
        this.em.refresh(feedback);
        this.monitoringSink.fire("Entity persisted!");
    }

    public List<Feedback> all() {
        return this.em.createNamedQuery(Feedback.findAll, Feedback.class).getResultList();
    }

    public Feedback find(long id) {
        return this.em.find(Feedback.class, id);
    }
}
