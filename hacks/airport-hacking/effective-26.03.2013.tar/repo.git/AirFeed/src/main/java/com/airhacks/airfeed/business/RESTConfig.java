package com.airhacks.airfeed.business;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author adam-bien.com
 */
@ApplicationPath("v1")
public class RESTConfig extends Application {
}
