package com.airhacks.airfeed.business.authentication.boundary;

import com.airhacks.airfeed.business.authentication.entity.AirhacksPrincipal;
import java.security.Principal;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class Authenticator {

    @Inject
    private Principal principal;

    @Produces
    public AirhacksPrincipal create() {
        final String name = principal.getName();
        AirhacksPrincipal airhacksPrincipal = new AirhacksPrincipal(name);
        System.out.println("Fetching the permissions from the store with: " + name);
        return airhacksPrincipal;
    }
}
