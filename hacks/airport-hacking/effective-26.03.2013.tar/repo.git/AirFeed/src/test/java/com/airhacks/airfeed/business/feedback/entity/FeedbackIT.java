/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks.airfeed.business.feedback.entity;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author adam-bien.com
 */
public class FeedbackIT {

    EntityTransaction tx;
    EntityManager em;

    @Before
    public void initEM() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("test");
        this.em = emf.createEntityManager();
        this.tx = this.em.getTransaction();
    }

    @Test
    public void crud() {
        List<Feedback> resultList = this.em.createNamedQuery(Feedback.findAll, Feedback.class).getResultList();
        int size = resultList.size();
        final Feedback expected = new Feedback("duke", "ok42");
        this.tx.begin();
        this.em.persist(expected);
        this.tx.commit();
        resultList = this.em.createNamedQuery(Feedback.findAll).getResultList();

        assertTrue(resultList.size() > size);

        this.em.clear();
        Feedback actual = this.em.find(Feedback.class, expected.getId());
        assertNotNull(actual);
    }
}
