package com.airhacks.airfeed.business.logging.boundary;

import java.util.logging.Logger;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class LogInjectionHelper {

    Logger logger;

    @Inject
    public LogInjectionHelper(Logger logger) {
        this.logger = logger;
    }

    public Logger getLogger() {
        return logger;
    }

    public void setLogger(Logger logger) {
        this.logger = logger;
    }
}
