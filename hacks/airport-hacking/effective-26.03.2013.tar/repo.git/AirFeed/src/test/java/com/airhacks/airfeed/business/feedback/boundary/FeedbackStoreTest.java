/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks.airfeed.business.feedback.boundary;

import com.airhacks.airfeed.business.feedback.control.SpamFilter;
import com.airhacks.airfeed.business.feedback.entity.Feedback;
import javax.persistence.EntityManager;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.*;
import org.mockito.runners.MockitoJUnitRunner;

/**
 *
 * @author adam-bien.com
 */
@RunWith(MockitoJUnitRunner.class)
public class FeedbackStoreTest {

    @InjectMocks
    FeedbackStore cut;
    @Mock
    EntityManager em;
    @Mock
    SpamFilter filter;

    @Test(expected = IllegalArgumentException.class)
    public void exceptionOnSpam() {
        when(this.filter.isSpam(anyString())).thenReturn(Boolean.TRUE);
        this.cut.store(new Feedback());
    }

    @Test
    public void storingOnValidComment() {
        final Feedback feedback = new Feedback();
        when(this.filter.isSpam(anyString())).thenReturn(Boolean.FALSE);
        this.cut.store(feedback);
        verify(this.em).persist(feedback);
    }
}
