/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks.airfeed.business.logging.boundary;

import javax.inject.Inject;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.junit.runner.RunWith;

/**
 *
 * @author adam-bien.com
 */
@RunWith(Arquillian.class)
public class LoggerProducerIT {

    @Inject
    LogInjectionHelper helper;

    @Deployment
    public static WebArchive create() {
        return ShrinkWrap.create(WebArchive.class).
                addClasses(LoggerProducer.class, LogInjectionHelper.class).
                addAsWebInfResource(EmptyAsset.INSTANCE, "beans.xml");
    }

    @Test
    public void logInjection() {
        String actual = helper.getLogger().getName();
        String expected = helper.getClass().getName();
        assertThat(actual, is(expected));
    }
}
