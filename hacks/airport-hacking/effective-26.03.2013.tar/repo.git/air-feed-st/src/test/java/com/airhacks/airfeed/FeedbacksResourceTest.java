package com.airhacks.airfeed;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.GenericType;
import com.sun.jersey.api.client.WebResource;
import java.util.List;
import javax.ws.rs.core.MediaType;
import org.junit.Before;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * @author adam-bien.com
 */
public class FeedbacksResourceTest {

    Client client;

    @Before
    public void initClient() {
        this.client = Client.create();
    }

    @Test
    public void crud() {
        final WebResource resource = this.client.resource("http://localhost:8080/AirFeed/v1/feedbacks");
        resource.post(new Feedback("duke", "gosling"));

        List<Feedback> thankYou = resource.accept(MediaType.APPLICATION_XML).get(new GenericType<List<Feedback>>() {
        });
        assertNotNull(thankYou);
        assertFalse(thankYou.isEmpty());
        System.out.println("---- " + thankYou);

    }
}
