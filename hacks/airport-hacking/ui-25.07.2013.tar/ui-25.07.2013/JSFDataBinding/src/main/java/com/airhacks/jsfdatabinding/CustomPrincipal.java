/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks.jsfdatabinding;

import java.util.List;

/**
 *
 * @author adam-bien.com
 */
public class CustomPrincipal {

    private String name;

    public CustomPrincipal(String name) {
        this.name = name;
    }

    public List<String> actions() {
        return null;
    }

    @Override
    public String toString() {
        return "CustomPrincipal{" + "name=" + name + '}';
    }
}
