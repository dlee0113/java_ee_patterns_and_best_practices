/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks.jsfdatabinding;

import java.security.Principal;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
public class CustomAuthenticator {

    @Inject
    Principal principal;

    @Produces
    public CustomPrincipal expose() {
        //fetch the entitlements from the DB at this place
        return new CustomPrincipal(principal.getName());
    }
}
