/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks.jsfdatabinding;

import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam-bien.com
 */
public class SecurityEnforcement {

    @Inject
    CustomPrincipal cp;

    @AroundInvoke
    public Object check(InvocationContext ic) throws Exception {
        return ic.proceed();
    }
}
