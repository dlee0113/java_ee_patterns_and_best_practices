/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.airhacks.jsfdatabinding;

import javax.enterprise.inject.Model;
import javax.inject.Inject;

/**
 *
 * @author adam-bien.com
 */
@Model
public class Index {

    @Inject
    private CustomPrincipal secure;

    public String getPrincipal() {
        return secure.toString();

    }
}
