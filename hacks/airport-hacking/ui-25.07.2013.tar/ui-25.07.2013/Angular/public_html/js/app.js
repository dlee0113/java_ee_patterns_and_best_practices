'use strict';
var hello = angular.module('hello', []);

