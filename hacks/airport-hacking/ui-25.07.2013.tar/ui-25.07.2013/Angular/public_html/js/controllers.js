'use strict';
hello.controller('HelloController',
        function($scope, $http) {
            $scope.message = 'joe';
            $scope.click = function() {
                $scope.message = "clicked";
            }
        }
);
