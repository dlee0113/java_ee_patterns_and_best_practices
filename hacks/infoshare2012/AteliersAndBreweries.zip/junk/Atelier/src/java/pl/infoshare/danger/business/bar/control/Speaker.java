package pl.infoshare.danger.business.bar.control;

public class Speaker {

    
    public boolean ok(){
        return true;
    }
}
