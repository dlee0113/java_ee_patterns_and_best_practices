/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.infoshare.danger.business.bar.control;

import javax.enterprise.inject.Specializes;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class Guinees extends Beer{

    public Guinees(String name, float amount) {
        super(name, amount);
    }

    
    
    
    
    
}
