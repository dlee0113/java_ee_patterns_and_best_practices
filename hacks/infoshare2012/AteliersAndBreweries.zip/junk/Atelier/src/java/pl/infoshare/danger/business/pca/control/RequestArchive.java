/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.infoshare.danger.business.pca.control;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.*;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;
import pl.infoshare.danger.business.bar.control.Beer;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Startup
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class RequestArchive {

    private CopyOnWriteArrayList<Beer> beers = new CopyOnWriteArrayList<Beer>();

    @Resource
    TimerService service;
    private Timer timer;
    
    @PostConstruct
    public void startTimers(){
        ScheduleExpression  expression = new ScheduleExpression();
        expression.minute("*").second("*/2").hour("*");
        this.timer = service.createCalendarTimer(expression);
    }
    public void onNewRequest(@Observes Beer beer) {
        beers.add(beer);
        System.out.println("Archiving an request");
    }
    
    
    public void reconfigure(){
        this.timer.cancel();
        this.startTimers();
    }
    
    
    @Timeout
    public void archiveNewRequests(){
        System.out.println("-Archiving-- " + beers);
        beers.clear();
    }
}
