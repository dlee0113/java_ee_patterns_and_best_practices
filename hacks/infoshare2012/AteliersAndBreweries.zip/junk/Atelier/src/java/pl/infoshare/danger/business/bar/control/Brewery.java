package pl.infoshare.danger.business.bar.control;

import javax.enterprise.inject.Produces;

public class Brewery {

    
    @Produces
    public Beer brew(){
        return new Guinees("guiness",2);
    }
}
