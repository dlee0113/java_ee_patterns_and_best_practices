package pl.infoshare.danger.business.bar.boundary;

import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import pl.infoshare.danger.business.bar.control.AnInterface;
import pl.infoshare.danger.business.bar.control.Beer;
import pl.infoshare.danger.business.bar.control.Speaker;

@Stateless
@Interceptors(BeerConsumptionAudit.class)
public class BarService {
    
    @Inject
    Speaker speaker;
    
    
    @Inject
    Event<Beer> event;
    
    @Inject
    Beer beer;
    
    @Inject
    Instance<AnInterface> ai;
    
    public Beer getBeer(){
        for (AnInterface anInterface : ai.select()) {
            System.out.println("---  " + anInterface.getName());
        }
        System.out.println(ai.isAmbiguous() + " " + ai.isUnsatisfied());
        event.fire(beer);
        return beer;
    }
}
