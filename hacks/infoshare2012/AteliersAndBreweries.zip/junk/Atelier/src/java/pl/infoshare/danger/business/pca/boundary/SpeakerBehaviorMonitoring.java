/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.infoshare.danger.business.pca.boundary;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.Asynchronous;
import javax.ejb.DependsOn;
import javax.ejb.Singleton;
import javax.enterprise.event.Observes;
import javax.enterprise.event.TransactionPhase;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import pl.infoshare.danger.business.bar.control.Beer;
import pl.infoshare.danger.business.pca.control.PaperProcessor;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class SpeakerBehaviorMonitoring {
    @Inject
    private Instance<String> message;

    @Inject
    PaperProcessor pp;
    
    public void onNewBeer(@Observes(during= TransactionPhase.AFTER_SUCCESS) Beer beer){
        List<Future<String>> toSign = new ArrayList<Future<String>>();
        for(int i=0;i<20;i++){
            toSign.add(pp.processRequest(beer));
        }
        for (Future<String> future : toSign) {
            try {
                System.out.println("#### " + future.get());
            } catch (Exception ex) {
                Logger.getLogger(SpeakerBehaviorMonitoring.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println(message.get() + beer);
    }

    public void onUnsuccessfulEvent(@Observes(during= TransactionPhase.AFTER_FAILURE) Beer beer){
        System.out.println("-RIP Speaker:--- " + beer);
    }
}
