/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.infoshare.danger.business.bar.control;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.Specializes;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class MicroBrewery extends Brewery{

    @Produces @Specializes
    public Beer brew() {
        return new Guinees("micro", 42);
    }
    
    
}
