/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.infoshare.danger.business.pca.control;

import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import pl.infoshare.danger.business.bar.control.Beer;

/**
 *
 * @author adam bien, adam-bien.com
 */
@Stateless
public class PaperProcessor {
    
    
    @Asynchronous
    public Future<String> processRequest(Beer beer){
        System.out.println("--- Speaker lost his contract: " + beer);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ex) {
            Logger.getLogger(PaperProcessor.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("--- Processed!");
        return new AsyncResult<String>("42");
    }
}
