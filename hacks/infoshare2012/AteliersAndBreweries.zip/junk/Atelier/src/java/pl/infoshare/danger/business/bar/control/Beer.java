package pl.infoshare.danger.business.bar.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class Beer {
    
    private String name;
    private float amount;

    public Beer(String name, float amount) {
        this.name = name;
        this.amount = amount;
    }
    
    

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Beer{" + "name=" + name + ", amount=" + amount + '}';
    }
    
    
    
    
    
}
