package pl.infoshare.danger.presentation;

import javax.enterprise.inject.Model;
import javax.inject.Inject;
import pl.infoshare.danger.business.bar.boundary.BarService;
import pl.infoshare.danger.business.bar.control.Beer;

@Model
public class Index {
    
    @Inject
    BarService barService;
    
    
    public Beer getBeer(){
        return barService.getBeer();
    }
}
