/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.infoshare.danger.business.bar.control;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class InterfaceImpl implements AnInterface{

    @Override
    public String getName() {
        return "Impl";
    }
    
}
