package pl.infoshare.danger.business.configuration;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class Configurator {


   @Produces
   public String getSomething(InjectionPoint ip){
        Class<?> clazz = ip.getMember().getDeclaringClass();
        String name = ip.getMember().getName();
        String key = clazz.getName() + "." + name;
       return " BAD speaker (configured) " + resolve(key);
   }

    private String resolve(String key) {
        return "Fetching from database an entry for: " + key;
    }
   
}
