/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.infoshare.danger.business.bar.boundary;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class BeerConsumptionAudit {
    
    @AroundInvoke
    public Object watchConsumption(InvocationContext ic) throws Exception{
        System.out.println("--- " + ic.getMethod());
        return ic.proceed();
    }
}
