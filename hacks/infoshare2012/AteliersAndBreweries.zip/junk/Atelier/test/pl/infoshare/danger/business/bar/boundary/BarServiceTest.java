/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.infoshare.danger.business.bar.boundary;

import org.junit.AfterClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import pl.infoshare.danger.business.bar.control.Speaker;

/**
 *
 * @author adam bien, adam-bien.com
 */
public class BarServiceTest {

    BarService cut;
    
    @Before
    public void inject(){
        this.cut = new BarService();
       
    }
    @Test
    public void testSomeMethod() {
    }
}
