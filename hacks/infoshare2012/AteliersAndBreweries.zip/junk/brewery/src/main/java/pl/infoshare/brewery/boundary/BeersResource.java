package pl.infoshare.brewery.boundary;

import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import pl.infoshare.brewery.entity.Beer;

@Path("beers")
@Stateless
public class BeersResource {
    
    @GET
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    public Beer getBeers(){
        return new Beer("Zywiec");
    }
}
