/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.infoshare;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author adam bien, adam-bien.com
 */
@ApplicationPath("resources")
public class RESTConfig extends Application{
    
}
